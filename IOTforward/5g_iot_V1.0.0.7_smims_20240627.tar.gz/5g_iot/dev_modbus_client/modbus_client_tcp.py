#!/usr/bin/python3
# -*- coding: utf-8 -*-
#---------------
import time
from pyModbusTCP.client import ModbusClient
from threading import Thread
import json
import socket, struct, sys, os
#---------------
str_version = 'v1.0.0,2024/05/28'
str_ver_filename = 'modbus_client_tcp_version.csv'
#---------------
class message_multicast():
	def __init__(self, multicast_group=('224.0.0.1', 19999), str_interface='0.0.0.0', max_pkg_len=16384):
		self.max_pkg_len = max_pkg_len
		self.multicast_group = multicast_group
		self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
		self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.s.bind(multicast_group)
		self.s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(multicast_group[0])+socket.inet_aton(str_interface))
		self.s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(str_interface))
		self.s.setblocking(False)

	def msg_send(self, topic, msg):
		i = len(topic)
		if i < 1 and len(msg) < 1:
			return 0
		buf = struct.pack('>B', i) + topic + msg
		sum = 0
		for i in range(len(buf)):
			sum += struct.unpack('>B', buf[i:i+1])[0]
		buf += struct.pack('>B', sum & 0xff)
		i = len(buf)
		if i > self.max_pkg_len:
			raise IOError('max_pkg_len=%d, UDP package size > max_pkg_len' % self.max_pkg_len)
		self.s.sendto(buf, self.multicast_group)
		return i

	def msg_recv(self):
		try:
			data = self.s.recv(self.max_pkg_len)
		except BlockingIOError if sys.version_info.major > 2 else socket.error:
			data = b''
		if len(data) < 4:
			return b'', b''
		sum = 0
		for i in range(len(data[:-1])):
			sum += struct.unpack('>B', data[i:i+1])[0]
		sum &= 0xff
		if struct.unpack('>B', data[-1:])[0] != sum:
			return b'', b''
		i = 1 + struct.unpack('>B', data[0:1])[0]
		topic = data[1:i]
		msg = data[i:-1]
		if len(topic) == 0 or len(msg) == 0:
			return b'', b''
		return topic, msg
#---------------
def get_timestamp_ms():
	return int(time.time()*1000)

def get_str_time():
	list_tmp = list(time.localtime(time.time()))[:6]
	return '%04d/%02d/%02d_%02d:%02d:%02d' % tuple(list_tmp[:6])

def get_str_time_format_event():
	list_tmp = list(time.localtime(time.time()))[:6]
	return '%04d-%02d-%02d %02d:%02d:%02d' % tuple(list_tmp[:6])

def get_str_date():
	list_tmp = list(time.localtime(time.time()))[:3]
	return '%04d%02d%02d' % tuple(list_tmp[:3])

def print_log(str_msg):
	global str_log_path
	#print(str_msg)
	try:
		fp = open('%slog_modbus_client_tcp_%s.txt' % (str_log_path, get_str_date()), 'a')
		fp.write(str_msg + '\n')
		fp.close()
	except:
		pass

def print_device_event(ip_addr, str_msg):
	global str_log_path
	str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)
	#print(str_tmp, end='')
	try:
		fp = open('%slogfile_%s_%s.csv' % (str_log_path, '%s:%s' % ip_addr, get_str_date()), 'a')
		fp.write(str_tmp)
		fp.close()
	except:
		pass

def print_device_log(ip_addr, str_msg):
	global str_log_path
	#print(str_msg)
	try:
		fp = open('%slog_%s_%s.txt' % (str_log_path, '%s:%s' % ip_addr, get_str_date()), 'a')
		fp.write(str_msg + '\n')
		fp.close()
	except:
		pass
#---------------
def thread_read_modbus_device(device, list_bank_addr_count, list_value):
	list_value.clear()
	for item in list_bank_addr_count:
		if item[0] == '4':
			list_tmp = device.read_holding_registers(reg_addr=item[1], reg_nb=item[2])
		elif item[0] == '3':
			list_tmp = device.read_input_registers(reg_addr=item[1], reg_nb=item[2])
		elif item[0] == '1':
			list_tmp = device.read_discrete_inputs(bit_addr=item[1], bit_nb=item[2])
		elif item[0] == '0':
			list_tmp = device.read_coils(bit_addr=item[1], bit_nb=item[2])
		else:
			break
		try:
			list_value.extend(list_tmp)
		except TypeError:
			break
#---------------
if __name__ == '__main__':
	try:
		str_ver_path = os.environ['PATH_5GIOT_VER']
		if not str_ver_path.endswith(os.sep):
			str_ver_path += os.sep
	except:
		str_ver_path = ''

	try:
		str_cfg_path = os.environ['PATH_5GIOT_CFG']
		if not str_cfg_path.endswith(os.sep):
			str_cfg_path += os.sep
	except:
		str_cfg_path = ''

	try:
		str_log_path = os.environ['PATH_5GIOT_LOG']
		if not str_log_path.endswith(os.sep):
			str_log_path += os.sep
	except:
		str_log_path = ''
	#---------------
	try:
		fp = open(str_ver_path + str_ver_filename, 'w')
		fp.write(str_version)
		fp.close()
	except:
		pass
	#----- Load csv -----
	try:
		fp = open(str_cfg_path + 'modbus_client.csv', 'r')
	except:
		exit()

	list_cfg_mapping = ['mmc_topic_data_prefix', 'mmc_group_ip', 'mmc_group_port', 'mmc_eth_interface', 'cmd_period_ms']
	list_modbus_tcp_csv_mapping = ['function_name', 'plc_ip', 'plc_port', 'slave_id', 'dpm_id', 'chamber_id']
	dict_modbus_cfg = {}

	list_csv = []
	while True:
		str_line = fp.readline()
		if len(str_line) == 0:
			break
		str_line = str_line.replace('\r','').replace('\n','').lstrip()
		i = str_line.find('#')  # 找到註解
		if i >= 0:
			str_line = str_line[:i]  # 去掉註解
		str_line = str_line.rstrip()
		list_tmp = str_line.split(',')  # 分拆參數
		for i in range(len(list_tmp)):
			list_tmp[i] = list_tmp[i].lstrip().rstrip()  # 去掉參數前後的空白
		#----------------------------------
		dict_csv = {}
		if list_tmp[0] == 'CFG_MODBUS_CLIENT_TCP':  #----------------------------------
			for i in range(len(list_cfg_mapping)):
				dict_modbus_cfg[list_cfg_mapping[i]] = list_tmp[i+1]
			dict_modbus_cfg['mmc_topic_data_prefix'] = dict_modbus_cfg['mmc_topic_data_prefix'].encode('utf-8')
			dict_modbus_cfg['mmc_group_port'] = int(dict_modbus_cfg['mmc_group_port'])
			dict_modbus_cfg['cmd_period_ms'] = int(dict_modbus_cfg['cmd_period_ms'])
			dict_modbus_cfg['mmc'] = message_multicast(multicast_group=(dict_modbus_cfg['mmc_group_ip'], dict_modbus_cfg['mmc_group_port']), str_interface=dict_modbus_cfg['mmc_eth_interface'])
			print_log('%s: Load csv CFG_MODBUS_CLIENT_TCP' % (get_str_time()))
		elif list_tmp[0] == 'MODBUS_CLIENT_TCP':  #----------------------------------
			for i in range(len(list_modbus_tcp_csv_mapping)):
				dict_csv[list_modbus_tcp_csv_mapping[i]] = list_tmp[i]
			for str_tmp in dict_csv.keys():
				if str_tmp == 'plc_port' or str_tmp == 'slave_id':
					dict_csv[str_tmp] = int(dict_csv[str_tmp])
			list_tmp = list_tmp[len(list_modbus_tcp_csv_mapping):]
			dict_csv['parameter'] = {}
			for i in range(len(list_tmp)):
				str_param_name, str_svid_param = list_tmp[i].split('=',1)
				str_param_name = str_param_name.lstrip().rstrip()  # 去掉參數前後的空白
				str_svid_param = str_svid_param.lstrip().rstrip()  # 去掉參數前後的空白
				if str_param_name in dict_csv['parameter']:
					if type(dict_csv['parameter'][str_param_name]) == list:
						dict_csv['parameter'][str_param_name].append(str_svid_param)
					else:
						dict_csv['parameter'][str_param_name] = [dict_csv['parameter'][str_param_name], str_svid_param]
				else:
					dict_csv['parameter'][str_param_name] = str_svid_param
			print_log('%s: Load csv MODBUS_CLIENT_TCP' % (get_str_time()))

			dict_csv['svid_mapping'] = {}
			dict_csv['svid_type'] = {}
			dict_csv['bitmask'] = {}
			for str_tmp in list(dict_csv['parameter'].keys()):
				str_dictkey = str_tmp
				str_type = ''
				if str_tmp.startswith('f'):
					str_type = 'f'
					str_tmp = str_tmp[1:].lstrip()
				elif str_tmp.startswith('s'):
					str_type = 's'
					str_tmp = str_tmp[1:].lstrip()

				if str_tmp.startswith('(') and str_tmp.endswith(')'):
					list_tmp = str_tmp[1:-1].split('+')
					for i in range(len(list_tmp)):
						list_tmp[i] = list_tmp[i].lstrip().rstrip()
					j = 0
					for i in range(len(list_tmp)):
						try:
							k = int(list_tmp[i])
						except ValueError:
							list_tmp.clear()
							break
						if i > 0 and k - j != 1:
							list_tmp.clear()
							break
						j = k
					if len(list_tmp) > 0:
						dict_csv['svid_mapping'][dict_csv['parameter'][str_dictkey]] = list_tmp
						dict_csv['svid_type'][dict_csv['parameter'][str_dictkey]] = str_type
				else:
					i = str_tmp.find('[')
					j = str_tmp.find(':')
					k = str_tmp.find(']')
					list_tmp = []
					if str_tmp.endswith(']') and i > 0:
						str_tmp = dict_csv['parameter'].pop(str_dictkey)
						if str_dictkey[:i] in dict_csv['parameter']:
							if type(dict_csv['parameter'][str_dictkey[:i]]) == list:
								dict_csv['parameter'][str_dictkey[:i]].append(str_tmp)
							else:
								dict_csv['parameter'][str_dictkey[:i]] = [dict_csv['parameter'][str_dictkey[:i]], str_tmp]
						else:
							dict_csv['parameter'][str_dictkey[:i]] = str_tmp
						str_svid_param = str_tmp
						str_tmp = str_dictkey[:i]
						try:
							if j > 0 and j > i + 1 and k > j + 1:
								list_tmp = [int(str_dictkey[i+1:j]), int(str_dictkey[j+1:k])]
								if list_tmp[0] < 0 or list_tmp[1] < 0:
									list_tmp.clear()
							elif j < 0:
								list_tmp = [int(str_dictkey[i+1:k])]
								if list_tmp[0] < 0:
									list_tmp.clear()
						except ValueError:
							pass
					try:
						int(str_tmp[1:])
						if len(list_tmp) > 0:
							dict_csv['bitmask'][str_svid_param] = list_tmp
						if type(dict_csv['parameter'][str_tmp]) == list:
							for str_svid_param in dict_csv['parameter'][str_tmp]:
								dict_csv['svid_mapping'][str_svid_param] = [str_tmp]
								dict_csv['svid_type'][str_svid_param] = str_type
						else:
							dict_csv['svid_mapping'][dict_csv['parameter'][str_tmp]] = [str_tmp]
							dict_csv['svid_type'][dict_csv['parameter'][str_tmp]] = str_type
					except ValueError:
						pass
			list_tmp = sum(dict_csv['svid_mapping'].values(), [])
			list_tmp.sort()
			for i in range(len(list_tmp)):
				if not list_tmp[i].isdigit():
					list_tmp.clear()
					break
			if len(list_tmp) > 0:
				i = 0
				while i < len(list_tmp) - 1:
					if list_tmp[i] == list_tmp[i+1]:
						list_tmp.pop(i)
					i += 1
				dict_csv['list_addr'] = list_tmp
				list_tmp = []
				j = 1
				str_address = dict_csv['list_addr'][0]
				for i in range(1, len(dict_csv['list_addr'])):
					str_tmp = dict_csv['list_addr'][i]
					if str_address[0] == str_tmp[0] and int(str_address[1:]) + j == int(str_tmp[1:]):
						if j >= 125:
							list_tmp.append([str_address[0], int(str_address[1:])-1, j])
							j = 1
							str_address = str_tmp
						else:
							j += 1
					else:
						list_tmp.append([str_address[0], int(str_address[1:])-1, j])
						j = 1
						str_address = str_tmp
				list_tmp.append([str_address[0], int(str_address[1:])-1, j])
				dict_csv['list_bank_addr_count'] = list_tmp
				dict_csv['list_value'] = []
				dict_csv['thread_id'] = None
			else:
				dict_csv.clear()
		#---------------
		if len(dict_csv) > 0:
			dict_csv['tx_time'] = 0
			dict_csv['rx_time'] = 0
			dict_csv['connection'] = False
			dict_csv['publish_data'] = {}
			list_csv.append(dict_csv)

	#----- Initial device -----
	for item in list_csv:
		if item['function_name'] == 'MODBUS_CLIENT_TCP':  #----------------------------------
			item['device'] = ModbusClient(host=item['plc_ip'], port=item['plc_port'], unit_id=item['slave_id'], auto_open=True)

	#----- Read device data -----
	while len(list_csv) > 0:
		for item in list_csv:
			if item['function_name'] == 'MODBUS_CLIENT_TCP':  #----------------------------------
				if get_timestamp_ms() - item['tx_time'] >= dict_modbus_cfg['cmd_period_ms'] and item['tx_time'] <= item['rx_time'] and item['thread_id'] == None:
					item['thread_id'] = Thread(target=thread_read_modbus_device, args=(item['device'], item['list_bank_addr_count'], item['list_value'],))
					item['thread_id'].start()
					item['tx_time'] = get_timestamp_ms()
					str_tmp = '%s: TX -> %s:%d' % (get_str_time(), item['plc_ip'], item['plc_port'])
					print_log(str_tmp)
					print_device_log((item['device'].host, item['device'].port), str_tmp)

				if item['thread_id'] != None and not item['thread_id'].is_alive():
					item['thread_id'] = None
					if len(item['list_addr']) == len(item['list_value']):
						item['rx_time'] = get_timestamp_ms()
						if not item['connection']:
							item['connection'] = True
							print_device_event((item['device'].host, item['device'].port), 'connected')
						str_tmp = '%s: RX <- %s:%d' % (get_str_time(), item['plc_ip'], item['plc_port'])
						print_log(str_tmp)
						print_device_log((item['device'].host, item['device'].port), str_tmp)
						item['publish_data']['227'] = 1
						for str_svid_param in item['svid_mapping']:
							str_type = item['svid_type'][str_svid_param]
							list_tmp = []
							for str_address in item['svid_mapping'][str_svid_param]:
								list_tmp.append(item['list_value'][item['list_addr'].index(str_address)])
							bytes_tmp = struct.pack('>' + 'H'*len(list_tmp), *list_tmp)
							str_tmp = ''
							if str_type == 'f':
								if len(bytes_tmp) == 4:
									str_tmp = '>f'
								elif len(bytes_tmp) == 8:
									str_tmp = '>d'
							elif str_type == 's':
								if len(bytes_tmp) == 2:
									str_tmp = '>h'
								elif len(bytes_tmp) == 4:
									str_tmp = '>i'
								elif len(bytes_tmp) == 8:
									str_tmp = '>q'
							else:
								if len(bytes_tmp) == 2:
									str_tmp = '>H'
								elif len(bytes_tmp) == 4:
									str_tmp = '>I'
								elif len(bytes_tmp) == 8:
									str_tmp = '>Q'
							value = struct.unpack(str_tmp, bytes_tmp)[0] if len(str_tmp) > 0 else None
							if value != None:
								if str_svid_param in item['bitmask']:
									list_tmp = item['bitmask'][str_svid_param]
									j = list_tmp[1] if len(list_tmp) > 1 else list_tmp[0]
									value >>= j
									i = 15 - list_tmp[0] + j
									value &= (0xffff >> i)
								item['publish_data'][str_svid_param] = value
						str_tmp = json.dumps(item['publish_data'])
						dict_modbus_cfg['mmc'].msg_send(dict_modbus_cfg['mmc_topic_data_prefix'] + item['dpm_id'].encode('utf-8') + item['chamber_id'].encode('utf-8'), str_tmp.encode('utf-8'))
						print_log('%s: MMC <- %s' % (get_str_time(), str_tmp))
						print_device_log((item['device'].host, item['device'].port), '%s: MMC <- %s' % (get_str_time(), str_tmp))
						item['publish_data'].clear()

				if not item['connection'] and get_timestamp_ms() - item['tx_time'] > 5000:
					item['rx_time'] = item['tx_time']
					str_tmp = json.dumps({'227':0})
					dict_modbus_cfg['mmc'].msg_send(dict_modbus_cfg['mmc_topic_data_prefix'] + item['dpm_id'].encode('utf-8') + item['chamber_id'].encode('utf-8'), str_tmp.encode('utf-8'))
					print_log('%s: MMC <- %s' % (get_str_time(), str_tmp))
					print_device_log((item['device'].host, item['device'].port), '%s: MMC <- %s' % (get_str_time(), str_tmp))

				if item['connection'] and get_timestamp_ms() - item['rx_time'] > 5000:
					item['connection'] = False
					print_device_event((item['device'].host, item['device'].port), 'disconnected')
		time.sleep(0.001)

#!/usr/bin/python3
# -*- coding: utf-8 -*-
#---------------
# History:
#   2024/06/05 v1.0.1:
#     uart 新增 tcp:// 模式
#---------------
import time
from threading import Thread
import json
import socket, struct, sys, os
import serial
import binascii
#---------------
str_version = 'v1.0.1,2024/06/05'
str_ver_filename = 'hostlink_fins_version.csv'
#---------------
class message_multicast():
	def __init__(self, multicast_group=('224.0.0.1', 19999), str_interface='0.0.0.0', max_pkg_len=16384):
		self.max_pkg_len = max_pkg_len
		self.multicast_group = multicast_group
		self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
		self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.s.bind(multicast_group)
		self.s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(multicast_group[0])+socket.inet_aton(str_interface))
		self.s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(str_interface))
		self.s.setblocking(False)

	def msg_send(self, topic, msg):
		i = len(topic)
		if i < 1 and len(msg) < 1:
			return 0
		buf = struct.pack('>B', i) + topic + msg
		sum = 0
		for i in range(len(buf)):
			sum += struct.unpack('>B', buf[i:i+1])[0]
		buf += struct.pack('>B', sum & 0xff)
		i = len(buf)
		if i > self.max_pkg_len:
			raise IOError('max_pkg_len=%d, UDP package size > max_pkg_len' % self.max_pkg_len)
		self.s.sendto(buf, self.multicast_group)
		return i

	def msg_recv(self):
		try:
			data = self.s.recv(self.max_pkg_len)
		except BlockingIOError if sys.version_info.major > 2 else socket.error:
			data = b''
		if len(data) < 4:
			return b'', b''
		sum = 0
		for i in range(len(data[:-1])):
			sum += struct.unpack('>B', data[i:i+1])[0]
		sum &= 0xff
		if struct.unpack('>B', data[-1:])[0] != sum:
			return b'', b''
		i = 1 + struct.unpack('>B', data[0:1])[0]
		topic = data[1:i]
		msg = data[i:-1]
		if len(topic) == 0 or len(msg) == 0:
			return b'', b''
		return topic, msg
#---------------
class hostlink_fins_dev():
	def __init__(self, unit_number):
		self._dict_MEM_AREA = {'D':b'82', 'H':'B2', 'A':'80'}
		self.hostlink_header = (b'@%02d' % unit_number) + b'FA000000000'

	def cmd_multiple_mem_area_read(self, list_mem_addr):
		fins_command = b'0104'
		fins_packet = self.hostlink_header + fins_command
		for str_mem_addr in list_mem_addr:
			try:
				i = 1 if str_mem_addr[1].isdigit() else 2
				fins_packet += self._dict_MEM_AREA[str_mem_addr[:i]]
				mem_addr = int(str_mem_addr[i:])
			except:
				return b''
			if mem_addr > 65535:
				return b''
			fins_packet += (binascii.hexlify(struct.pack('>H', mem_addr)).upper() + b'00')
		fins_packet += (self.fcs_calculator(fins_packet) + b'*\r')
		return fins_packet

	def decode_response_packet(self, packet, list_value):
		if packet[0:1] != b'@' or packet[-2:] != b'*\r':
			return []
		if self.fcs_calculator(packet[:-4]) != packet[-4:-2]:
			return []
		if packet[3:5] != b'FA' or packet[5:15] != b'0040000000' or packet[15:19] != b'0104':
			return []
		try:
			if int(packet[19:23], 16) & 0x7f3f != 0:
				return []
		except ValueError:
				return []
		for i in range(25, len(packet)-4, 6):
			try:
				#list_value.append(int(packet[i:i+4], 16))
				list_value.append(binascii.unhexlify(packet[i:i+4]))
			except ValueError:
				break

	def fcs_calculator(self, packet):
		fcs = 0
		for i in range(len(packet)):
			fcs ^= struct.unpack('B', packet[i:i+1])[0]
		return binascii.hexlify(struct.pack('B', fcs)).upper()
#---------------
class uart_tcp():
	def __init__(self, str_uri):
		if not str_uri.startswith('tcp://'):
			raise OSError('illegal scheme string')
		self.port = str_uri
		str_uri = str_uri.lstrip('tcp://')
		list_uri = str_uri.split(':')
		socket.inet_aton(list_uri[0])
		list_uri[1] = int(list_uri[1])
		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.s.connect(tuple(list_uri[:2]))
		self.s.setblocking(False)

	def write(self, data):
		self.s.send(data)

	def read(self, size=1):
		try:
			return self.s.recv(size)
		except BlockingIOError:
			return b''

	def read_all(self):
		try:
			return self.s.recv(1436)
		except BlockingIOError:
 			return b''

	def close(self):
		self.s.close()

#---------------
def get_timestamp_ms():
	return int(time.time()*1000)

def get_str_time():
	list_tmp = list(time.localtime(time.time()))[:6]
	return '%04d/%02d/%02d_%02d:%02d:%02d' % tuple(list_tmp[:6])

def get_str_time_format_event():
	list_tmp = list(time.localtime(time.time()))[:6]
	return '%04d-%02d-%02d %02d:%02d:%02d' % tuple(list_tmp[:6])

def get_str_date():
	list_tmp = list(time.localtime(time.time()))[:3]
	return '%04d%02d%02d' % tuple(list_tmp[:3])

def print_log(str_msg):
	global str_log_path
	print(str_msg)
	try:
		fp = open('%slog_hostlink_fins_%s.txt' % (str_log_path, get_str_date()), 'a')
		fp.write(str_msg + '\n')
		fp.close()
	except:
		pass

def print_device_event(str_device, str_msg):
	global str_log_path
	str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)
	#print(str_tmp, end='')
	try:
		fp = open('%slogfile_%s_%s.csv' % (str_log_path, str_device.split(os.sep)[-1], get_str_date()), 'a')
		fp.write(str_tmp)
		fp.close()
	except:
		pass

def print_device_log(str_device, str_msg):
	global str_log_path
	#print(str_msg)
	try:
		fp = open('%slog_%s_%s.txt' % (str_log_path, str_device.split(os.sep)[-1], get_str_date()), 'a')
		fp.write(str_msg + '\n')
		fp.close()
	except:
		pass
#---------------
def fins_write_cmd_read_value(fins_dev, uart, list_addr, list_value):
	tx_packet = fins_dev.cmd_multiple_mem_area_read(list_addr)
	uart.write(tx_packet)
	str_tmp = '%s: %s <- %s' % (get_str_time(), uart.port, tx_packet)
	print_log(str_tmp)
	print_device_log(uart.port, str_tmp)
	rx_packet = b''
	i = 0
	ch = b''
	while i < 1000 and ch != b'\r':
		ch = uart.read(1)
		if ch == b'':
			i += 1
			time.sleep(0.001)
			continue
		i = 0
		rx_packet += ch
	fins_dev.decode_response_packet(rx_packet, list_value)
	str_tmp = '%s: %s -> %s' % (get_str_time(), uart.port, rx_packet)
	print_log(str_tmp)
	print_device_log(uart.port, str_tmp)

def thread_read_fins_device(tuple_device, list_addr, list_value):
	list_value.clear()
	try:
		unit_number = tuple_device[5]
		if tuple_device[0].startswith('rfc2217://'):
			uart = serial.serial_for_url(tuple_device[0], timeout=0)
			uart.baudrate = tuple_device[1]
			uart.bytesize = tuple_device[2]
			uart.stopbits = tuple_device[3]
			uart.parity = tuple_device[4]
		elif tuple_device[0].startswith('tcp://'):
			uart = uart_tcp(tuple_device[0])
		else:
			uart = serial.Serial(port=tuple_device[0],baudrate=tuple_device[1],bytesize=tuple_device[2],stopbits=tuple_device[3],parity=tuple_device[4], timeout=0)
		fins_dev = hostlink_fins_dev(unit_number)
		k = 128
		j = 0
		while j+k <= len(list_addr):
			fins_write_cmd_read_value(fins_dev, uart, list_addr[j:j+k], list_value)
			j += k
		if j < len(list_addr):
			fins_write_cmd_read_value(fins_dev, uart, list_addr[j:], list_value)
		uart.close()
	except:
		pass
#---------------
if __name__ == '__main__':
	try:
		str_ver_path = os.environ['PATH_5GIOT_VER']
		if not str_ver_path.endswith(os.sep):
			str_ver_path += os.sep
	except:
		str_ver_path = ''

	try:
		str_cfg_path = os.environ['PATH_5GIOT_CFG']
		if not str_cfg_path.endswith(os.sep):
			str_cfg_path += os.sep
	except:
		str_cfg_path = ''

	try:
		str_log_path = os.environ['PATH_5GIOT_LOG']
		if not str_log_path.endswith(os.sep):
			str_log_path += os.sep
	except:
		str_log_path = ''
	#---------------
	try:
		fp = open(str_ver_path + str_ver_filename, 'w')
		fp.write(str_version)
		fp.close()
	except:
		pass
	#----- Load csv -----
	try:
		fp = open(str_cfg_path + 'hostlink_fins.csv', 'r')
	except:
		exit()

	list_cfg_mapping = ['mmc_topic_data_prefix', 'mmc_group_ip', 'mmc_group_port', 'mmc_eth_interface', 'cmd_period_ms']
	list_hostlink_fins_csv_mapping = ['function_name', 'device_path', 'baud_rate', 'data_bits', 'stop', 'parity', 'unit_number', 'big_endian', 'dpm_id', 'chamber_id']
	dict_hostlink_fins_cfg = {}

	list_csv = []
	while True:
		str_line = fp.readline()
		if len(str_line) == 0:
			break
		str_line = str_line.replace('\r','').replace('\n','').lstrip()
		i = str_line.find('#')  # 找到註解
		if i >= 0:
			str_line = str_line[:i]  # 去掉註解
		str_line = str_line.rstrip()
		list_tmp = str_line.split(',')  # 分拆參數
		for i in range(len(list_tmp)):
			list_tmp[i] = list_tmp[i].lstrip().rstrip()  # 去掉參數前後的空白
		#----------------------------------
		dict_csv = {}
		if list_tmp[0] == 'CFG_HOSTLINK_FINS':  #----------------------------------
			for i in range(len(list_cfg_mapping)):
				dict_hostlink_fins_cfg[list_cfg_mapping[i]] = list_tmp[i+1]
			dict_hostlink_fins_cfg['mmc_topic_data_prefix'] = dict_hostlink_fins_cfg['mmc_topic_data_prefix'].encode('utf-8')
			dict_hostlink_fins_cfg['mmc_group_port'] = int(dict_hostlink_fins_cfg['mmc_group_port'])
			dict_hostlink_fins_cfg['cmd_period_ms'] = int(dict_hostlink_fins_cfg['cmd_period_ms'])
			dict_hostlink_fins_cfg['mmc'] = message_multicast(multicast_group=(dict_hostlink_fins_cfg['mmc_group_ip'], dict_hostlink_fins_cfg['mmc_group_port']), str_interface=dict_hostlink_fins_cfg['mmc_eth_interface'])
			print_log('%s: Load csv CFG_HOSTLINK_FINS' % (get_str_time()))
		elif list_tmp[0] == 'HOSTLINK_FINS':  #----------------------------------
			for i in range(len(list_hostlink_fins_csv_mapping)):
				dict_csv[list_hostlink_fins_csv_mapping[i]] = list_tmp[i]
			for str_tmp in dict_csv.keys():
				if str_tmp == 'baud_rate' or str_tmp == 'data_bits' or str_tmp == 'unit_number' or str_tmp == 'big_endian':
					dict_csv[str_tmp] = int(dict_csv[str_tmp])
				elif str_tmp == 'stop':
					dict_csv[str_tmp] = float(dict_csv[str_tmp]) if dict_csv[str_tmp].find('.') >= 0 else int(dict_csv[str_tmp])
			list_tmp = list_tmp[len(list_hostlink_fins_csv_mapping):]
			dict_csv['parameter'] = {}
			for i in range(len(list_tmp)):
				str_param_name, str_svid_param = list_tmp[i].split('=',1)
				str_param_name = str_param_name.lstrip().rstrip()  # 去掉參數前後的空白
				str_svid_param = str_svid_param.lstrip().rstrip()  # 去掉參數前後的空白
				if str_param_name in dict_csv['parameter']:
					if type(dict_csv['parameter'][str_param_name]) == list:
						dict_csv['parameter'][str_param_name].append(str_svid_param)
					else:
						dict_csv['parameter'][str_param_name] = [dict_csv['parameter'][str_param_name], str_svid_param]
				else:
					dict_csv['parameter'][str_param_name] = str_svid_param
			print_log('%s: Load csv HOSTLINK_FINS' % (get_str_time()))

			dict_csv['svid_mapping'] = {}
			dict_csv['svid_type'] = {}
			dict_csv['bitmask'] = {}
			for str_tmp in list(dict_csv['parameter'].keys()):
				str_dictkey = str_tmp
				str_type = ''
				if str_tmp.startswith('f'):
					str_type = 'f'
					str_tmp = str_tmp[1:].lstrip()
				elif str_tmp.startswith('s'):
					str_type = 's'
					str_tmp = str_tmp[1:].lstrip()

				if str_tmp.startswith('(') and str_tmp.endswith(')'):
					list_tmp = str_tmp[1:-1].split('+')
					for i in range(len(list_tmp)):
						list_tmp[i] = list_tmp[i].lstrip().rstrip()
					if len(list_tmp) > 0:
						dict_csv['svid_mapping'][dict_csv['parameter'][str_dictkey]] = list_tmp
						dict_csv['svid_type'][dict_csv['parameter'][str_dictkey]] = str_type
				else:
					i = str_tmp.find('[')
					j = str_tmp.find(':')
					k = str_tmp.find(']')
					list_tmp = []
					if str_tmp.endswith(']') and i > 0:
						str_tmp = dict_csv['parameter'].pop(str_dictkey)
						if str_dictkey[:i] in dict_csv['parameter']:
							if type(dict_csv['parameter'][str_dictkey[:i]]) == list:
								dict_csv['parameter'][str_dictkey[:i]].append(str_tmp)
							else:
								dict_csv['parameter'][str_dictkey[:i]] = [dict_csv['parameter'][str_dictkey[:i]], str_tmp]
						else:
							dict_csv['parameter'][str_dictkey[:i]] = str_tmp
						str_svid_param = str_tmp
						str_tmp = str_dictkey[:i]
						try:
							if j > 0 and j > i + 1 and k > j + 1:
								list_tmp = [int(str_dictkey[i+1:j]), int(str_dictkey[j+1:k])]
								if list_tmp[0] < 0 or list_tmp[1] < 0:
									list_tmp.clear()
							elif j < 0:
								list_tmp = [int(str_dictkey[i+1:k])]
								if list_tmp[0] < 0:
									list_tmp.clear()
						except ValueError:
							pass
					try:
						int(str_tmp[1:])
						if len(list_tmp) > 0:
							dict_csv['bitmask'][str_svid_param] = list_tmp
						if type(dict_csv['parameter'][str_tmp]) == list:
							for str_svid_param in dict_csv['parameter'][str_tmp]:
								dict_csv['svid_mapping'][str_svid_param] = [str_tmp]
								dict_csv['svid_type'][str_svid_param] = str_type
						else:
							dict_csv['svid_mapping'][dict_csv['parameter'][str_tmp]] = [str_tmp]
							dict_csv['svid_type'][dict_csv['parameter'][str_tmp]] = str_type
					except ValueError:
						pass
			list_tmp = sum(dict_csv['svid_mapping'].values(), [])
			list_tmp.sort()
			if len(list_tmp) > 0:
				i = 0
				while i < len(list_tmp) - 1:
					if list_tmp[i] == list_tmp[i+1]:
						list_tmp.pop(i)
					i += 1
				dict_csv['list_addr'] = list_tmp
				dict_csv['list_value'] = []
				dict_csv['thread_id'] = None
			else:
				dict_csv.clear()
		#---------------
		if len(dict_csv) > 0:
			dict_csv['tx_time'] = 0
			dict_csv['rx_time'] = 0
			dict_csv['connection'] = False
			dict_csv['publish_data'] = {}
			list_csv.append(dict_csv)

	#----- Read device data -----
	while len(list_csv) > 0:
		for item in list_csv:
			if item['function_name'] == 'HOSTLINK_FINS':  #----------------------------------
				if get_timestamp_ms() - item['tx_time'] >= dict_hostlink_fins_cfg['cmd_period_ms'] and item['tx_time'] <= item['rx_time'] and item['thread_id'] == None:
					item['thread_id'] = Thread(target=thread_read_fins_device, args=((item['device_path'], item['baud_rate'], item['data_bits'], item['stop'], item['parity'], item['unit_number']), item['list_addr'], item['list_value'],))
					item['thread_id'].start()
					item['tx_time'] = get_timestamp_ms()

				if item['thread_id'] != None and not item['thread_id'].is_alive():
					item['thread_id'] = None
					if len(item['list_addr']) == len(item['list_value']):
						item['rx_time'] = get_timestamp_ms()
						if not item['connection']:
							item['connection'] = True
							print_device_event(item['device_path'], 'connected')
						item['publish_data']['227'] = 1
						for str_svid_param in item['svid_mapping']:
							str_type = item['svid_type'][str_svid_param]
							list_tmp = []
							for str_address in item['svid_mapping'][str_svid_param]:
								list_tmp.append(item['list_value'][item['list_addr'].index(str_address)])
							bytes_tmp = b''
							for i in range(len(list_tmp)) if item['big_endian'] > 0 else range(len(list_tmp)-1,-1,-1):
								bytes_tmp += list_tmp[i]
							str_tmp = ''
							if str_type == 'f':
								if len(bytes_tmp) == 4:
									str_tmp = '>f'
								elif len(bytes_tmp) == 8:
									str_tmp = '>d'
							elif str_type == 's':
								if len(bytes_tmp) == 2:
									str_tmp = '>h'
								elif len(bytes_tmp) == 4:
									str_tmp = '>i'
								elif len(bytes_tmp) == 8:
									str_tmp = '>q'
							else:
								if len(bytes_tmp) == 2:
									str_tmp = '>H'
								elif len(bytes_tmp) == 4:
									str_tmp = '>I'
								elif len(bytes_tmp) == 8:
									str_tmp = '>Q'
							value = struct.unpack(str_tmp, bytes_tmp)[0] if len(str_tmp) > 0 else None
							if value != None:
								if str_svid_param in item['bitmask']:
									list_tmp = item['bitmask'][str_svid_param]
									j = list_tmp[1] if len(list_tmp) > 1 else list_tmp[0]
									value >>= j
									i = 15 - list_tmp[0] + j
									value &= (0xffff >> i)
								item['publish_data'][str_svid_param] = value
						str_tmp = json.dumps(item['publish_data'])
						dict_hostlink_fins_cfg['mmc'].msg_send(dict_hostlink_fins_cfg['mmc_topic_data_prefix'] + item['dpm_id'].encode('utf-8') + item['chamber_id'].encode('utf-8'), str_tmp.encode('utf-8'))
						print_log('%s: MMC <- %s' % (get_str_time(), str_tmp))
						print_device_log(item['device_path'], '%s: MMC <- %s' % (get_str_time(), str_tmp))
						item['publish_data'].clear()

				if not item['connection'] and get_timestamp_ms() - item['tx_time'] > 5000:
					item['rx_time'] = item['tx_time']
					str_tmp = json.dumps({'227':0})
					dict_hostlink_fins_cfg['mmc'].msg_send(dict_hostlink_fins_cfg['mmc_topic_data_prefix'] + item['dpm_id'].encode('utf-8') + item['chamber_id'].encode('utf-8'), str_tmp.encode('utf-8'))
					print_log('%s: MMC <- %s' % (get_str_time(), str_tmp))
					print_device_log(item['device_path'], '%s: MMC <- %s' % (get_str_time(), str_tmp))

				if item['connection'] and get_timestamp_ms() - item['rx_time'] > 5000:
					item['connection'] = False
					print_device_event(item['device_path'], 'disconnected')
		time.sleep(0.001)

#!/usr/bin/python3
# -*- coding: utf-8 -*-
#---------------
import binascii,time
import serial

class test_dev():
	def __init__(self):
		self.packet = b'@00FA000000000010482123400825678007A*\r'
		self.ptr = 0
	def read(self, num):
		ret = self.packet[self.ptr:self.ptr+num]
		self.ptr += num
		if self.ptr >= len(self.packet):
			self.ptr = 0
		return ret
	def write(self, packet):
		time.sleep(1)

def fcs_calculator(packet):
	fcs = 0
	for ch in packet:
		fcs ^= ch
	return binascii.hexlify(fcs.to_bytes(1,'big')).upper()

print('HostLink Fins Simultor')

uart = serial.Serial(port='/dev/vcom_hostlink_dev',baudrate=9600,bytesize=serial.SEVENBITS,stopbits=serial.STOPBITS_TWO,parity=serial.PARITY_EVEN)

buf = b''
while True:
	ch = uart.read(1)
	buf += ch
	if ch != b'\r':
		continue

	if not buf.endswith(b'*\r'):
		buf = b''
		continue

	i = buf.find(b'@')
	if i < 0:
		buf = b''
		continue
	buf = buf[i:]
	print('UART -> %s' % buf.decode('utf-8'))

	if len(buf) < 22:
		buf = b''
		continue

	try:
		unit_number = int(buf[1:3], 16)
	except ValueError:
		buf = b''
		continue
	if unit_number < 0:
		buf = b''
		continue

	if buf[3:5] != b'FA':
		buf = b''
		continue
	try:
		response_wait_time = int(buf[5:6], 16)
	except ValueError:
		buf = b''
		continue
	if response_wait_time >= 10 and not ch.isupper():
		buf = b''
		continue
	# ICF
	if buf[6:8] != b'00':
		buf = b''
		continue
	# DA2
	if buf[8:10] != b'00':
		buf = b''
		continue
	# SA2
	if buf[10:12] != b'00':
		buf = b''
		continue
	# SID
	if buf[12:14] != b'00':
		buf = b''
		continue

	fins_command = buf[14:18]
	resp_packet = b'@' + buf[1:3] + b'FA0040000000' + fins_command + b'0000'

	if fins_command == b'0101':
		if len(buf) < 22+12:
			buf = b''
			continue
		dm = buf[18:20]
		try:
			plc_sa = int(buf[20:26], 16)
			plc_sz = int(buf[26:30], 16)
		except ValueError:
			buf = b''
			continue
		cmd_fcs = buf[30:32]
		for i in range(plc_sa, plc_sa + plc_sz):
			resp_packet += binascii.hexlify(i.to_bytes(2,'big')).upper()
	elif fins_command == b'0104':
		if len(buf) <= 22 or (len(buf)-22) % 8 != 0:
			buf = b''
			continue
		for i in range(18, len(buf)-4, 8):
			resp_packet += buf[i:i+6]
		cmd_fcs = buf[-4:-2]
	else:
		buf = b''
		continue

	if cmd_fcs != fcs_calculator(buf[:-4]):
		print('command fcs error:', fcs_calculator(buf[:-4]))
		continue

	buf = b''
	resp_packet += (fcs_calculator(resp_packet) + b'*\r')
	uart.write(resp_packet)
	print('UART <- ' + resp_packet.decode('utf-8'))

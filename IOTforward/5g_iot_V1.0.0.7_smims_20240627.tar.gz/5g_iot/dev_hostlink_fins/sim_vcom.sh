#!/bin/bash
sudo /usr/bin/socat -d -d pty,raw,mode=660,group=dialout,echo=0,link=/dev/vcom_hostlink pty,raw,mode=660,group=dialout,echo=0,link=/dev/vcom_hostlink_dev

#!/bin/bash
echo $(ls ../../../tmp)
current_date=$(date "+%Y-%m-%d_%H_%M")
IOT_FILE="../../../tmp/5g_iot"
IOTBAK_FILE="/opt/5g_iot_${current_date}"
#LF
if [ -d "${IOT_FILE}" ]; then
	echo "run"
    sudo python3 "/opt/5g_iot/util/service_remove.py" &
    wait $!

    echo "remove service"
    mv  "/opt/5g_iot" "$IOTBAK_FILE"
    mv "$IOT_FILE" "/opt/5g_iot"
    sudo rm -r "/opt/5g_iot/config"
    sudo mv  "$IOTBAK_FILE/config" "/opt/5g_iot/config"
    #cp "$IOTBAK_FILE/web/sqlite/5giot.db" "/opt/5g_iot/web/sqlite/5giot.db"
    sudo rm -r "/opt/5g_iot/ModbusService/config" 	 
    sudo mv "$IOTBAK_FILE/ModbusService/config" "/opt/5g_iot/ModbusService/config"
    cp "$IOTBAK_FILE/setting/comports.csv" "/opt/5g_iot/setting/comports.csv"
    
	cp "$IOTBAK_FILE/update/apache2.conf" "/etc/apache2/apache2.conf"
	cp "$IOTBAK_FILE/update/apache2.service" "/usr/lib/systemd/system/apache2.service"

    #for moxa 處理v1.0.0.1問題
    echo 5G80735905 | sudo -S systemctl disable moxa-connection-manager
    echo 5G80735905 | sudo -S dpkg -i /tmp/5g_iot/deb/moxa-system-manager_2.13.2-1+deb11_all.deb

    #for moxa diag-partner for v1.0.0.6
    echo 5G80735905 | sudo -S dpkg -i /tmp/5g_iot/deb/diag-partner_0.9.6_arm64.deb
    sudo timedatectl set-ntp no
    sudo mv /opt/5g_iot/sys_service/* /etc/systemd/system/
	
	echo "update 5giot success"
    sudo python3 /opt/5g_iot/util/service_load.py
    echo "load service"
    rm -r "$IOTBAK_FILE"
    echo "remove bak 5giot"
    sudo mv "/opt/5g_iot/util/rsyslog.conf" "/etc/rsyslog.conf"
    sudo systemctl restart rsyslog.service
	sudo mv "/opt/5g_iot/log_reboot.service" "/etc/systemd/system/log_reboot.service"
	sudo mv "/opt/5g_iot/service_status_log.service" "/etc/systemd/system/service_status_log.service"
	sudo systemctl daemon-reload
    wait $!
	sudo systemctl enable log_reboot.service
	sudo systemctl start log_reboot.service
    sudo systemctl enable service_status_log.service
	sudo systemctl start service_status_log.service
    sudo systemctl enable 5g_router_log.service
    sudo systemctl start 5g_router_log.service

else
    echo "can't find update file"
fi




#!/usr/bin/python3
# -*- coding: utf-8 -*-
#---------------------------------------------
import time
import paho.mqtt.client as mqtt
import json
#---------------------------------------------
if __name__ == '__main__':
	mqtt_client = mqtt.Client()

	str_mqtt_user = 'fivegiot'
	str_mqtt_password = 'k76gH54s'
	str_mqtt_ip = '127.0.0.1'
	int_mqtt_port = 1883
	try:
		mqtt_client.username_pw_set(str_mqtt_user, str_mqtt_password)
		mqtt_client.connect(str_mqtt_ip, int_mqtt_port, 30)
	except:
		exit()

	dict_publish = {'011':1234, '017':5678, '020':320.5}
	i = 0
	while True:
		mqtt_client.publish('GIOT-GW/FIVEGIOT/UL/1200001',json.dumps(dict_publish))
		for str_tmp in dict_publish:
			if i % 2 == 0:
				dict_publish[str_tmp] *= 2
			else:
				dict_publish[str_tmp] /= 2
		i += 1
		time.sleep(2)

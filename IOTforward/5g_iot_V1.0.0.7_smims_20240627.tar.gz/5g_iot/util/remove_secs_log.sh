#!/bin/bash

cleanup_logs() {
    sudo find /opt/5g_iot/log/ -type f -name 'log_last*' -mtime +2 -exec rm {} \;
    sudo find /opt/5g_iot/log/ -type f -name 'log_5000*' -mtime +2 -exec rm {} \;
    sudo find /opt/5g_iot/log/ -type f -name 'log_5001*' -mtime +2 -exec rm {} \;
    sudo find /tmp/log/ -type f -name 'log_last*' -mtime +2 -exec rm {} \;
    sudo find /tmp/log/ -type f -name 'log_5000*' -mtime +2 -exec rm {} \;
    sudo find /tmp/log/ -type f -name 'log_5001*' -mtime +2 -exec rm {} \;
}

move_logs() {
    local pattern="$1"
    if [ -b "/dev/mmcblk1p1" ]; then
        sudo find /tmp/log/ -type f -name "$pattern" -exec sh -c '
            for file; do
                filename=$(basename "$file")
                date_part=$(echo "$filename" | grep -oE "[0-9]{8}")
                formatted_date=$(date -d "$date_part" +%Y-%m-%d)
                sudo mv "$file" "/opt/5g_iot/log/"
            done
        ' _ {} +
    else
        sudo find /tmp/log/ -type f -name "$pattern" -exec rm {} \;

    fi
}


cleanup_logs
move_logs 'log_last*'
move_logs 'log_5000*'
move_logs 'log_5001*'



import os
import time
import json
import urllib.request
import urllib.parse
import ssl
from datetime import datetime

ssl._create_default_https_context = ssl._create_unverified_context


def os_exec(str_cmd):
    print('$ ' + str_cmd)
    str_resp = os.popen(str_cmd).read()
    return str_resp


def login(username, password, api_url):
    try:
        data = {
            "username": username,
            "password": password

        }
        data = json.dumps(data).encode('utf-8')
        headers = {'Content-Type': 'application/json'}
        req = urllib.request.Request(
            api_url+'/login', data=data, headers=headers, method='POST')
        with urllib.request.urlopen(req) as response:
            result = response.read().decode('utf-8')
            token = json.loads(result).get('data', {}).get('token')
            return token
    except Exception as e:
        print(f"Error: {e}")
        return None


def get_system_information(api_url, token):
    try:
        headers = {
            'Cookie': f"token={token}"
        }
        req = urllib.request.Request(
            api_url + "/system_information", headers=headers)
        with urllib.request.urlopen(req) as response:
            result = response.read().decode('utf-8')
            system_info = json.loads(result).get('data', {})
            return system_info
    except Exception as e:
        print(f"Error: {e}")
        return None


def get_system_modem_status(api_url, token):
    try:
        headers = {
            'Cookie': f"token={token}"
        }
        req = urllib.request.Request(
            api_url + "/modem_status", headers=headers)
        with urllib.request.urlopen(req) as response:
            result = response.read().decode('utf-8')
            system_info = json.loads(result).get('data', {})
            return system_info
    except Exception as e:
        print(f"Error: {e}")
        return None


def print_device_log(old_str, str_msg):
    file_data = ""
    try:
        file_data += old_str + str(str_msg) + '\n'
        return file_data
    except FileNotFoundError:
        pass


def write_device_log(file_data, str_log_path):
    with open(str_log_path, "w", encoding="utf-8") as fp:
        fp.write(file_data)


def diff_systemtime_information(str_log_path, formatted_date_str, formatted_date_HMS):
    try:
        with open(str_log_path, "r", encoding="utf-8") as fp:
            time_2_struct = datetime(2000, 1, 1, 0, 0, 0)
            my_string = None
            for line in fp:
                if "Sync Time:" in line:
                    my_string = line.split("Sync Time:")
                    timestamp = my_string[1].strip()
                    time_2_struct = datetime.strptime(
                        timestamp, "%Y%m%d %H:%M:%S")
                    hours = (time_1_struct -
                             time_2_struct).total_seconds() / 3600
                    delayhours = (time_2_struct -
                                  time_1_struct).total_seconds() / 3600
                    if hours >= 1:
                        os_exec(f"sudo date -s \"{formatted_date_str}\"")
                        os_exec(f"sudo date -s \"{formatted_date_HMS}\"")
                        os_exec(f"sudo hwclock -w")
                        file_data = "Sync Time:" + formatted_date_str+" "+formatted_date_HMS + '\n'
                        return file_data
                    elif delayhours >= 1:
                        os_exec(f"sudo date -s \"{formatted_date_str}\"")
                        os_exec(f"sudo date -s \"{formatted_date_HMS}\"")
                        os_exec(f"sudo hwclock -w")
                        file_data = "Sync Time:" + formatted_date_str+" "+formatted_date_HMS + '\n'
                        return file_data
                    else:
                        file_data = "Sync Time:" + timestamp + '\n'
                        return file_data

                elif "System Time:" in line:
                    time_1_struct = datetime.strptime(
                        formatted_date_str+" "+formatted_date_HMS, "%Y%m%d %H:%M:%S")
            if my_string is None:
                my_string = "Sync Time:" + formatted_date_str+" " + formatted_date_HMS+'\n'
                os_exec(f"sudo date -s \"{formatted_date_str}\"")
                os_exec(f"sudo date -s \"{formatted_date_HMS}\"")
                os_exec(f"sudo hwclock -w")
                return my_string
        return ""
    except FileNotFoundError:
        return "File not found"


api_url = "https://192.168.1.254/api/v1"
username = "admin"
password = "1qaz@WSX"
str_log_path = "/tmp/log/log_5g_router_info.txt"
update_router_version = "2.0"
while True:
    token = login(username, password, api_url)
    if token:
        print("Token:", token)
        break
    else:
        print("Failed to obtain token. Retrying in 10 seconds...")
        time.sleep(10)
while True:

    file_data = ""
    try:
        system_information = get_system_information(api_url, token)
        if system_information:
            print("System system Status:")
            router_version = system_information.get('moxa_firmware_version')
            if (float(router_version[3:6]) <= float(update_router_version)):
                break
            strtime = system_information.get('system_time')

            input_date = datetime.strptime(strtime, "%a %b %d %H:%M:%S %Y")
            formatted_date_str = input_date.strftime("%Y%m%d")
            formatted_date_HMS = input_date.strftime("%H:%M:%S")

            file_data += print_device_log("System Time:",
                                          formatted_date_str+" "+formatted_date_HMS)

            file_data += diff_systemtime_information(
                str_log_path, formatted_date_str, formatted_date_HMS)
        else:
            print("Failed to obtain token.")

        time.sleep(1)

        system_modem_status = get_system_modem_status(api_url, token)

        if system_modem_status:
            print("System Modem Status:")
            operation_mode = system_modem_status.get('operation_mode')

            file_data += print_device_log("operation_mode:", operation_mode)
            lte_rsrp = system_modem_status.get('lte_info', {}).get('rsrp')
            file_data += print_device_log("lte_rsrp:", lte_rsrp)
            nr_rsrp = system_modem_status.get('nr_info', {}).get('rsrp')
            file_data += print_device_log("nr_rsrp:", nr_rsrp)
        else:
            print("Failed to obtain modem status.")

        if file_data:
            write_device_log(file_data, str_log_path)
    except Exception as e:
        print(f"Error: {e}")
        print("Token expired. Retrying...")
        time.sleep(9)
        token = login(username, password, api_url)

    time.sleep(9)

#!/bin/bash
if [ "$1" = "" ]; then
	mosquitto_sub -h 127.0.0.1 -p 1883 -u "fivegiot" -P "k76gH54s" -v -t "#"
else
	mosquitto_sub -h 127.0.0.1 -p 1883 -u "fivegiot" -P "k76gH54s" -v -t "$1"
fi

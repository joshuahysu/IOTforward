import subprocess
import time
from datetime import datetime

SERVICES = [
    "5giot_modbusserverservice.service",
    "5giot_dpm_ebara.service",
    "5giot_dpm_edwards.service",
    "5giot_dpm_ksy_mu_ts.service",
    "5giot_dpm_ksy_sde_sdt_sdx_sdh.service",
    "5giot_fins2mqtt.service",
    "5giot_secsgem.service"
]
LOG_FILE = "/opt/5g_iot/log/service_status_log_{}.txt"
switch = True
previous_status = {service: "unknown" for service in SERVICES}


def check_service_status(service):
    try:
        result = subprocess.run(["systemctl", "is-active", "--quiet", service])
        return result.returncode
    except Exception as e:
        print(f"Error checking status of {service}: {e}")
        return None


def log_status(service, status):
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    current_date = datetime.now().strftime("%Y-%m-%d")
    LOG_FILE_Path = LOG_FILE.format(current_date)
    try:
        with open(LOG_FILE_Path, "a") as log_file:
            log_file.write(f"{current_time} - {service} is {status}\n")
        return 0
    except FileNotFoundError:
        return 1


def main():
    global switch
    for service in SERVICES:
        try:
            current_status = check_service_status(service)

            if current_status is not None:

                if current_status == 0:
                    current_status = "active"
                else:
                    current_status = "inactive"

                if current_status != previous_status[service]:
                    previous_status[service] = current_status
                    if (log_status(service, current_status) == 1):
                        switch = False

        except Exception as e:
            print(f"Error processing {service}: {e}")


while switch:
    main()
    time.sleep(5)

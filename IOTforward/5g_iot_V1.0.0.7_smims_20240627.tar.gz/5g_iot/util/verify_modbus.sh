#!/bin/bash


echo --------------EBARA--------------

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 101 1 40004 == 8
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 101 1 40004

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 101 1 40011 == 12

python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 101 1 40011

echo --------------EDWARDS--------------

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 102 1 40801 == 3
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 102 1 40801

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 102 1 40802 == 4
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 102 1 40802

echo --------------KSY_MU_TS--------------

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 103 1 40007 == 42
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 103 1 40007

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 103 1 40027 == 43
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 103 1 40027

echo --------------KSY_SDE_AK--------------

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 104 1 40007 == 8
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 104 1 40007

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 104 1 40011 == 12345
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 104 1 40011

echo --------------FINS--------------

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41001 == 19008
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41001

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41002 == 19009
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41002

echo '$ /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41003 == 31996'
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41003

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41004 == 19012
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41004

echo '$ /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41005 == 32768'
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41005

echo '$ /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41007 == 62256'
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41007

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41008 == 32772
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 201 1 41008

echo --------------modbus to modbus--------------

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 301 1 41001 == 6314
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 301 1 41001

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 301 1 41002 == 6309
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 301 1 41002

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 301 1 41003 == 6302
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 301 1 41003

echo $ /opt/5g_iot/util/read_modbus.py 127.0.0.1 301 1 41004 == 511
python3 /opt/5g_iot/util/read_modbus.py 127.0.0.1 301 1 41004

#!/bin/bash

WATCH_DIR="/dev/shm/5g_iot/keep_value/"
LOG_FILE="/opt/5g_iot/dir_watch.txt"

last_count=0

get_file_count(){
find "$WATCH_DIR" -type f | wc -l
}
log_change() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - File count changed: $1" >> "$LOG_FILE"
}

last_count=$(get_file_count)
echo "$(date '+%Y-%m-%d %H:%M:%S') - Initial file count: $last_count" >> "$LOG_FILE"

while true; do
  current_count=$(get_file_count)
 
  if [ "$current_count" -ne "$last_count" ]; then
    log_change "$current_count"
    last_count="$current_count"
  fi

  sleep 1
done
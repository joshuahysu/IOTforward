#!/bin/bash


java -cp /opt/5g_iot/secsgem/HsmsSs_host.jar:/opt/5g_iot/secsgem/lib/bin/\* secshost.HsmsSs_host


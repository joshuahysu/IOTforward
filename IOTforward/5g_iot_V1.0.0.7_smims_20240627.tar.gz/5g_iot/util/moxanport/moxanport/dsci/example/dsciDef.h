#ifndef DEFIDH
#define DEFIDH

#define		MAX_PORT_NUM	8

#define		BROADCAST		0
#define		SEARCH_BY_IP	1	

#define     MAX_DEVICE_NUM          512

#define     SEARCH_TIMEOUT                  1000
#define     SEARCH_RETRY_CNT                5

typedef struct _CONFIGINFO {
    DS_INFO             ds_info;
	DS_HANDLE			dshdl;
	PIFCONFIGINFO		p_ifconfig;
	int					ipcfgsetting;
	SERPARMITEM			pserial_info;
	int					baud_index;
    BYTE                port_type;
	char				svr_name[16];
	int					watchdog;
	int					operation_mode;
	PKERNELINFO			pkernel_info;
	int					system_changed;
	char				new_passwd[17];
	char				new_privatekey[16];
	PAPINFO				pap_info;
} CFGINFO, *PCFGINFO;



#endif
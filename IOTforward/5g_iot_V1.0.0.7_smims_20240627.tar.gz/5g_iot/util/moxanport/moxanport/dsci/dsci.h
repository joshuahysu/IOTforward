
#ifndef _DSCI_H
#define _DSCI_H

#if defined(_WIN32) || defined(_WIN64) || defined(_WIN32_WCE)	// Windows
#   if defined(_BUILD_DLL)
#       define DLLEXPORT __declspec(dllexport)
#   elif defined(_BUILD_STATIC) || defined(_IMPORT_STATIC)
#       define DLLEXPORT
#   else
#       define DLLEXPORT __declspec(dllimport)
#   endif

#   define DLLLOCAL
#   define MX_FUNC  __stdcall

#   if !( defined(_WINSOCKAPI_) || defined(_WINSOCK2API_) )
#       include <winsock2.h>
#   endif

#   pragma comment (lib, "Ws2_32.lib")
#   pragma comment (lib, "Iphlpapi.lib")

#   ifndef PSYSTEMTIME
        typedef SYSTEMTIME *PSYSTEMTIME;
#   endif

#elif defined (__GNUC__) && defined(__unix__)	// Linux
#   define DLLEXPORT __attribute__ ((visibility("default")))
#   define DLLLOCAL __attribute__ ((visibility("hidden")))
#   define MX_FUNC
#   define CALLBACK

#   include <stdint.h> 
    typedef uint32_t            DWORD;
    typedef uint16_t            WORD;
    typedef uint8_t             BYTE;
    typedef int                 BOOL;
    typedef int32_t             LONG;   // LONG type in Windows is 32-bit regardless of the platform is x86 or x64
    typedef unsigned char       UCHAR;
    typedef uint32_t            ULONG;  // ULONG type in Windows is 32-bit regardless of the platform is x86 or x64
    typedef void*               LPVOID;
    typedef BYTE*               LPBYTE;
    typedef void*               LPARAM;

    typedef struct _SYSTEMTIME {
        WORD wYear;
        WORD wMonth;
        WORD wDayOfWeek;
        WORD wDay;
        WORD wHour;
        WORD wMinute;
        WORD wSecond;
        WORD wMilliseconds;
    } SYSTEMTIME, *PSYSTEMTIME;
#endif

/* error code */
#define DSC_OK	             1
#define DSC_FAIL		-1
#define DSC_TOUT		-2
#define DSC_SOCKET		-3
#define DSC_USER_BREAK	-4
#define DSC_PARAM		-5
#define DSC_FOPEN_FAIL	-6
#define DSC_FLASH_LEN	-7
#define DSC_FIRM_FORMAT	-9
#define DSC_MAX_LIMIT	-10
#define DSC_MEM_ALLOC	-11
#define DSC_NOT_LOGIN        -12
#define DSC_PASS_FAIL          -13
#define DSC_DEFAULT_FAIL -14

#define DS_HANDLE	int

/* dsc_GetKernelInfo */
/*	KERNELINFO.flag */
#define K_PASSENABLED	0x01
#define NEW_DSCIFUNC	0x0100
#define IA_MODEL		0x0200
#define PPP_2217FUNC	0x0400
#define HAS_B5075		0x0800

/* dsc_GetSerialIOCtl */
#define B50		    0x00
#define B75		    0x01
#define B110		0x02
#define B134		0x03
#define B150		0x04
#define B300		0x05
#define B600		0x06
#define B1200		0x07
#define B1800		0x08
#define B2400		0x09
#define B4800		0x0A
#define B7200		0x0B
#define B9600		0x0C
#define B19200		0x0D
#define B38400		0x0E
#define B57600		0x0F
#define B115200 	0x10
#define B230400 	0x11
#define B460800		0x12
#define B921600		0x13


#define BIT_5	0x00
#define BIT_6	0x01
#define BIT_7	0x02
#define BIT_8	0x03

#define STOP_1	0x00
#define STOP_2	0x04

#define P_MASK      0x38
#define P_NONE		0x00
#define P_ODD		0x08
#define P_EVEN		0x18
#define P_MRK		0x28
#define P_SPC		0x38

#define NONE_FLOWCTRL	0
#define HW_FLOWCTRL	    1
#define SW_FLOWCTRL	    2
#define DTRDSR_FLOWCTRL	3

/*	dsc_GetSerialInterface */
#define IF_RS232	0
#define IF_RS422	1
#define IF_RS4852W	2
#define IF_RS4854W	3

/*      dsc_GetSerialLineStatus */
#define L_RTS	0x02
#define L_DTR	0x01
#define L_CTS	0x10
#define L_DSR	0x20
#define L_DCD	0x80

/* dsc_UpgradeXXX step define */
#define DW_CONNECT      10
#define DW_SEND_DATA    20
#define DW_UPDATE       30
#define DW_WAIT_FINISH  40

/* dsc_GetSerialIOCtl, dsc_GetSerialFIFO, dsc_GetSerialInterface */
#define SERCURRENT      0
#define SERINIT         1

/* dsc_GetNetstat, TCP state */
#define ST_CLOSED       0
#define ST_LISTEN       1
#define ST_SYN_RCVD     2
#define ST_SYN_SEND     3
#define ST_ESTABLISHED  4
#define ST_FIN_WAIT1    5
#define ST_FIN_WAIT2    6
#define ST_CLOSE_WAIT   7
#define ST_CLOSING      8
#define ST_LAST_ACK     9
#define ST_TIME_WAIT    10


/* DS_INFO.flag */
#define IP_SPECIFIED	0x01
#define F_NP1G		    0x10

/* set console */
#define CON_WEB		0x01
#define CON_HTTP	CON_WEB
#define CON_TELNET	0x02
#define CON_SERIAL	0x04
#define CON_SW_RST	0x08
#define CON_HTTPS	0x10
#define CON_SSH		0x20
#define CON_DSCI	0x40

/* log event type */
#define	EVT_COLD_START	 1
#define EVT_WARM_START	 2
#define EVT_ATUEH_FAIL	 3
#define EVT_IP_CHANGED	 4
#define	EVT_PASS_CHANGED 5
#define EVT_DCD_OFF	     6
#define EVT_DCD_ON	     7
#define EVT_DSR_OFF	     8
#define EVT_DSR_ON	     9

/* opmode */
#define	DRV_MODE	    0x02
#define TCPSVR_MODE	    0x0A
#define TCPCLI_MODE	    0x0D
#define UDP_MODE	    0x0E
#define	PAIRSLAVE_MODE	0x00
#define PAIRMASTER_MODE	0x01
#define ETHMODEM_MODE	0x0C
#define RTELNET_MODE	0x08
#define	DISABLE_MODE	0x07
#define PPP_MODE	    0x0F
#define DRV_2217_MODE   0x14

/* TCP Client Connect Control */
#define STARTUP_NONE	0x11
#define ANYCHAR_NONE	0x12
#define ANYCHAR_INACT	0x22
#define DSRON_DSROFF	0x44
#define DSRON_NONE		0x14
#define DCDON_DCDOFF	0x88
#define DCDON_NONE		0x18

/* LCM & Reset Protect */
#define LCMPASSWD		0x01
#define RESETPROTECT	0x02

/* PPP opmode */
#define OP_DIRECTLY_CONNECT		0
#define OP_LEASE_LINE			1
#define OP_DIAL_OUT				2
#define OP_DIAL_IN				3

/* PPP disconnect mode */
#define DISCON_DEFAULT			0
#define DISCON_NONE				1
#define DISCON_DSR				2
#define DISCON_DCD				3

/* PPP authentication type */
#define AUTH_CHAP_PAP			0
#define AUTH_PAP				1
#define AUTH_CHAP				2

/* PPP Flag */
#define DPPP_FLAGS_TCP_COMPRESS 0x01	/* Support TCP Compress for PPP */
#define DPPP_FLAGS_LQR_REPORT	0x10	/* Support LQR Report for PPP */

/* PPP Status */
#define SPPP_CLOSE			0
#define SWAIT_DCD			1
#define SLCP_NEGOTIATE1		2
#define SLCP_NEGOTIATE2		3
#define SLCP_NEGOTIATE3		4
#define SLCP_NEGOTIATE4		5
#define SLCP_NEGOTIATE5		6
#define SLCP_NEGOTIATE6		7
#define SLCP_NEGOTIATE7		8
#define SLCP_NEGOTIATE8		9
#define SAUTH_NEGOTIATE1	100
#define SAUTH_NEGOTIATE2	101
#define SAUTH_NEGOTIATE3	102
#define SAUTH_NEGOTIATE4	103
#define SAUTH_NEGOTIATE5	104
#define SAUTH_NEGOTIATE6	105
#define SAUTH_NEGOTIATE7	106
#define SAUTH_NEGOTIATE8	107
#define SAUTH_NEGOTIATE9	108
#define SAUTH_NEGOTIATE10	109
#define SAUTH_NEGOTIATE_FAIL	110
#define SIPCP_NEGOTIATE1	300
#define SIPCP_NEGOTIATE2	301
#define SIPCP_NEGOTIATE3	302
#define SIPCP_NEGOTIATE4	303
#define SIPCP_NEGOTIATE5	304
#define SIPCP_NEGOTIATE6	305
#define SIPCP_NEGOTIATE7	306
#define SIPCP_NEGOTIATE8	307
#define SIPCP_NEGOTIATE9	308
#define SPPP_CONNEXT_OK		309

/* WNDLIBPROC func define */
#define FUNC_GET_SEARCH	            0x01
#define	FUNC_GET_LOCATE	            0x02
#define FUNC_GET_NAME	            0x10
#define FUNC_GET_WATCHDOG	        0x12
#define FUNC_GET_DEBUG		        0x13
#define FUNC_GET_NETSTAT		    0x14
#define FUNC_GET_APINFO		        0x15
#define FUNC_GET_KERNELINFO	        0x16
#define FUNC_GET_APSTATUS		    0x17
#define FUNC_GET_ENVIRONMENTMODE	0x18
#define FUNC_GET_IP			        0x21
#define FUNC_GET_NETMASK		    0x22
#define FUNC_GET_GATEWAY		    0x23
#define FUNC_GET_IPCONFIG	        0x24
#define FUNC_GET_IPLOCATION	        0x25
#define FUNC_GET_IFCONFIG	        0x26

#define FUNC_GET_SERIALIOCTL	    0x31
#define FUNC_GET_SERIALFIFO	        0x32
#define FUNC_GET_SERIALINTERFACE	0x34
#define FUNC_GET_SERIALLINESTATUS	0x35
#define FUNC_GET_SERIALDATACNT	    0x36

#define FUNC_GET_REDUNDANTCOMSTATUS 0x3A


/* TLS version flag define (for future) */
#define TLS_VER_1_0 0x01	/* TLS V1.0 */
#define TLS_VER_1_1 0x02	/* TLS V1.1 */
#define TLS_VER_1_2 0x04	/* TLS V1.2 */

/* encryption mode for below function (for future)
	dsc_SetSnmpAgent()
	dsc_GetSnmpAgent()
*/
#define DSCI_ENCRYPT_AES128		0

/* encryption mode for below function (for future)
	dsc_SetSnmpAgent()
	dsc_GetSnmpAgent()
	dsc_SetMailAccount_ex()
	dsc_SetRetriveMailAccount_ex()
	dsc_GetPPPAuthTable_Ex()
	dsc_SetPPPAuthTable_Ex()
	dsc_SetPresharedKey_ex()
*/
#define NO_ENCRYPT						0
#define DSCI_ENCRYPT_AES256		2

/* encryption mode for below function
	dsc_SetLogin_Ex() 
*/
#define DSCI_ENCRYPT_SHA256		2

/* encryption mode for below function
	set_PasswordEx() 
*/
#define DSCI_OLD_PWD_ENCRYPT_MD5			0
#define DSCI_OLD_PWD_ENCRYPT_AES128		1
#define DSCI_OLD_PWD_ENCRYPT_SHA256		2

#define DSCI_NEW_PWD_ENCRYPT_AES128		0
#define DSCI_NEW_PWD_ENCRYPT_AES256		2


//NPort 1G function
#if 0
#define OP_GETMAC 			0x49	// get MAC address
#define OP_CALL 			0x01	// get NPort Config
#define OP_START_SHINING    0x31	// Start S1 shining
#define OP_STOP_SHINING     0x32	// Stop S1 shining
#define OP_SET_IP_MASK	    0x33	// Set IP address & net mask
#define OP_SET_GATEWAY	    0x34	// Set default gate way
#define OP_SAVE_RESTART     0x35	// Save parameter & restart
#define OP_SET_NAME			0x36	// Set CN2100 name
#define OP_SET_MODE			0x37	// Set RS-232 port OP_MODE
#define OP_SET_PASSWD	    0x38	// Set new password
#define OP_SET_ROUTE	    0x39	// Add/Delete a routing
#define OP_READ_ROUTE	    0x3A	// Read all routing
#define OP_GETPORTS_RIGHT   0x3B	// Get CN2100 port access right table
#define OP_SETPORTS_RIGHT   0x3C	// Get CN2100 port access right table
#define OP_SET_WANPORT	    0x3E	// Get CN2100 wan port
#define OP_GET_WANPORT	    0x3F	// Get CN2100 wan port
#define OP_IPCONFLICT		0x3D	// Check CN2100 IP confllic or not
#define OP_SET_COMPORT	    0x40	// Set CN2100 COM port
#define OP_GET_MODE			0x41	// Set RS-232 port OP_MODE
#define OP_GET_MODEMSTR	    0x42	// Get CN2100 port modem init string
#define OP_SET_MODEMSTR	    0x43	// Set CN2100 port modem init string
#define	OP_GET_MONITOR		0x70	// Get CN2100 monitor information
#define	OP_SET_INTERFACE	0x44	// Set interface information
#define	OP_GET_INTERFACE	0x73	// Get interface information
#define	OP_SETGET_DHCP		0x45	// Set/Get interface information

#define OP_SET_TCP_SERVER		0x4E	/* Set TCP server 			*/
#define OP_GET_TCP_SERVER		0x4F	/* Get TCP server 			*/
#define OP_SET_INACTIVITY_TIME	0x50	/* Set inactivity time 		*/
#define OP_GET_INACTIVITY_TIME	0x51	/* Get inactivity time 		*/
#define OP_SET_TCP_ALIVE		0x52	/* Set TCP alive check time */
#define OP_GET_TCP_ALIVE		0x53	/* Get TCP alive check time */
#define OP_SET_DATA_PACKING	    0x54	/* Set Data Packing 		*/
#define OP_GET_DATA_PACKING	    0x55	/* Get Data Packing 		*/
#define OP_SET_UART_FIFO		0x56	/* Set UART FIFO			*/
#define OP_GET_UART_FIFO		0x57	/* Get UART FIFO 			*/
#define OP_GET_ETHERNET_STATUS	0x58	/* Get Ethernet status 		*/

#endif

#define FUNC_SET_BIT                 0x80000000L

#define	FUNC_SET_GETID	        (0x00 | FUNC_SET_BIT)
#define FUNC_SET_LOGIN	        (0x01 | FUNC_SET_BIT)
#define FUNC_SET_SAVERESTART	(0x02 | FUNC_SET_BIT)
#define FUNC_RECV_CONFIG		(0x03 | FUNC_SET_BIT)
#define FUNC_UPGRADE_CONFIG		(0x04 | FUNC_SET_BIT)
#define FUNC_UPGRADE_FIRM		(0x05 | FUNC_SET_BIT)
#define FUNC_UPGRADE_FIRM_FILE  (0x06 | FUNC_SET_BIT)
#define FUNC_UPGRADE_FILE		(0x07 | FUNC_SET_BIT)
#define FUNC_UPGRADE_FIRM_AP	(0x08 | FUNC_SET_BIT)

#define FUNC_SET_RUNORSTOPAP	(0x09 | FUNC_SET_BIT)
#define FUNC_SET_PRIVATEKEY	    (0x0A | FUNC_SET_BIT)

#define FUNC_SET_NAME		    (0x10 | FUNC_SET_BIT)
#define FUNC_SET_PASSWORD	    (0x11 | FUNC_SET_BIT)
#define FUNC_SET_WATCHDOG	    (0x12 | FUNC_SET_BIT)
#define FUNC_SET_DEBUG		    (0x13 | FUNC_SET_BIT)

#define FUNC_SET_IP			    (0x21 | FUNC_SET_BIT)
#define FUNC_SET_NETMASK		(0x22 | FUNC_SET_BIT)
#define FUNC_SET_GATEWAY		(0x23 | FUNC_SET_BIT)
#define FUNC_SET_IPCONFIG	    (0x24 | FUNC_SET_BIT)
#define FUNC_SET_IPLOCATION	    (0x25 | FUNC_SET_BIT)

#define FUNC_SET_SERIALIOCTL	    (0x31 | FUNC_SET_BIT)
#define FUNC_SET_SERIALFIFO	        (0x32 | FUNC_SET_BIT)
#define FUNC_SET_SERIALINTERFACE	(0x34 | FUNC_SET_BIT)


#pragma pack(1)

/***************************************************/
//#ifndef	_BASE_DEFINE
//#define _BASE_DEFINE

#define MAXDS				512     /* Max Device Server number supported */
#define MACLEN				6       /* MAC Address field byte count */
#define MAXIPNUM			32		/* Max IP address number for ipv6 */
#define MAXIPLEN			40		
#define	APNAMELEN			40      /* AP name max length */
#define HOSTNAMELEN			40      /* Host Domain Name max length */
#define SVRNAMELEN			40      /* Device Server Name */
#define SVRNAMELEN_OLD		30      /* Device Server Name */
#define MAXIFITEM			256      /* dsc_GetIfConfig item max count */
#define MD5LEN              16
#define SVRPASSWDLEN		16      /* password max length */
#define USRNAMELEN			16
#define PRIVATEKEYLEN		15      /* private key max length */
#define	MAXNETITEM			256     /* dsc_GetNetStat item max count */
#define MAILADDRLEN			64
#define PORTNAMELEN			16
#define MAXLOGCNT			1024
#define FSNAME				32
#define PPPNAMELEN			20
#define PPPPASSWORDLEN		20
#define	PPPDIALOUTLEN		52

#define PPPNAMELEN_EX		16
#define PPPPASSWORDLEN_EX	16
#define MODEMINITSTRLEN		16
#define	MODEMATCMDLEN		8

#define MAXMULTISESSION		4

#define MAXPORT				16
#define MAXACCESSIP			16
#define MAXUSER				16
#define MAXCONNECT			8

#define MAXACLITEM          40

//Will
#define MAX_EXT_DOMAIN_LEN 128
#define MAX_COMMUNITY_LEN 32
//
#define FROM_LAN1 0x01
#define FROM_LAN2 0x02


// opcode 0x5C
#define GET_FILE_NAME_LEN               64
//Will
// 0x0002, 0x0001
#define FULL_SERIAL_NO_LEN	12
//
// ------------------


typedef struct _DS_INFO
{
    DWORD	apid;
    WORD	hwid;
    WORD	flag;
    DWORD	real_ip_addr;       // LAN1
    DWORD	pseudo_ip_addr;     // LAN2
// for dual lan module
    DWORD   real_ip_addr2;
    DWORD   pseudo_ip_addr2;
    BYTE    from_ip_flag;
////
    DWORD	host_ip_addr;
    DWORD   scope_id;
    char	real_ip_addr_v6[MAXIPNUM][MAXIPLEN];
    char	pseudo_ip_addr_v6[MAXIPNUM][MAXIPLEN];
    char	host_ip_addr_v6[MAXIPLEN];
    BYTE	mac[MACLEN];
// for dual lan module
    BYTE	mac2[MACLEN];
////    
	WORD    reserved1;
    DWORD	serial_no_1g;

    BOOL    socket_v4;
}
DS_INFO, *PDS_INFO;


typedef	struct	_RSP_OPCALL_DATA
{
    DWORD   challenge;      //challenge id
    WORD	type;		// device type
    WORD	serial; 	// device serial no
    DWORD	eip;		// function ECHP IP
    WORD	version;	// ???
    WORD	len;		// ???
    DWORD	version4;	// ???
    BYTE	flag;		// password flag,  bit 0,0 --> No password set
    //		   bit 0,1 --> password is set
    //		   bit 1 --> Installed
    //		   bit 2 --> IP conflict
    BYTE	ports;		// RS-232 ports
    BYTE	svrname[SVRNAMELEN_OLD];	// CN2100 name
    BYTE	opmode[MAXPORT];// CN2100 OP_MODE
    DWORD	ip;			// CN2100 IP address
    DWORD	mask;		// CN2100 net mask
    DWORD	gateway;	// CN2100 default gateway
}
RSP_OPCALL_DATA, *PRSP_OPCALL_DATA;



typedef struct _NETSTATINFO
{
    DWORD		remote_ip;
    DWORD		local_ip;
    WORD		remote_port;
    WORD		local_port;
    BYTE		socket_type;
    BYTE		connect_status;
    BYTE		ser_port;
    BYTE		reserved;
}
NETSTATINFO, *PNETSTATINFO;

typedef struct _APINFO
{
    BYTE		name[APNAMELEN];
    DWORD		version;

    WORD		year;
    BYTE		month;
    BYTE		day;
    BYTE		hour;
    BYTE		min;
    WORD		reserve;

    DWORD		length;
}
APINFO, *PAPINFO;

typedef struct _KERNELINFO
{
    DWORD		firm_version;
    DWORD		bios_version;
    DWORD		serial_no;
    WORD		flag;
    WORD		DSCI_Ver;
}
KERNELINFO, *PKERNELINFO;


typedef struct _IPLOCATIONINFO
{
    char		loc_server[HOSTNAMELEN];
    WORD		loc_port;
    WORD		loc_period;
}
IPLOCATIONINFO, *PIPLOCATIONINFO;


typedef struct _IFCONFIGINFO
{
    WORD		ifid;
    WORD		flag;
    DWORD		ipaddr;
    DWORD		netmask;
    DWORD		gateway;
}
IFCONFIGINFO, *PIFCONFIGINFO;

typedef struct _IFCFGLIST {
    int total;
    PIFCONFIGINFO   info;
}
IFCFGLIST, *PIFCFGLIST;

typedef struct	_SERPARMITEM
{
    DWORD		baud;
    BYTE		mode;
    BYTE		flowctrl;
    BYTE		reserve[2];
}
SERPARMITEM, *PSERPARMITEM;

typedef struct _SERDATACNT
{
    DWORD		txcnt;
    DWORD		rxcnt;
    DWORD		total_txcnt;
    DWORD		total_rxcnt;
}
SERDATACNT, *PSERDATACNT;

typedef struct _REDCOMSTATUS
{
        // [][0]: IP1, [][1]: IP2
	DWORD		ip[MAXCONNECT][2];
	BYTE		status[MAXCONNECT*2];
}
REDCOMSTATUS, *PREDCOMSTATUS;

typedef struct _IPLOCATION_DATA
{
    BYTE	name[SVRNAMELEN];
    DWORD	apid;
    WORD	hwid;
    BYTE	mac[MACLEN];
    DWORD	serialno;
    DWORD	ip;
    WORD	port;
    WORD	reserve;
}
IPLOCATION_DATA, *PIPLOCATION_DATA;

typedef struct _SNMPINFO
{
    BYTE	is_enabled;
    BYTE	reserved[3];
    char    community[HOSTNAMELEN];
    char    contact[HOSTNAMELEN];
    char    location[HOSTNAMELEN];
    char    trap_host[HOSTNAMELEN];
}
SNMPINFO, *PSNMPINFO;

typedef struct _MAILINFO
{
    char mail_svr[HOSTNAMELEN];
    DWORD auth_enable;
//        char usr_name[USRNAMELEN];
//        char password[SVRPASSWDLEN];
    char from_addr[MAILADDRLEN];
    char to_addr1[MAILADDRLEN];
    char to_addr2[MAILADDRLEN];
    char to_addr3[MAILADDRLEN];
    char to_addr4[MAILADDRLEN];
}
MAILINFO, *PMAILINFO;

typedef struct _DATAPACKINGINFO
{
    BYTE		enabled;
    BYTE		ch1;
    BYTE		ch2;
    BYTE		reserved;
    DWORD		force_tx;
}
DATAPACKINGINFO, *PDATAPACKINGINFO;

typedef struct _DATAPACKINGINFO_EX
{
    BYTE		enabled;
    BYTE		ch1;
    BYTE		ch2;
    WORD		force_tx;
    WORD		packlen;
    BYTE		reserved[5];
}
DATAPACKINGINFO_EX, *PDATAPACKINGINFO_EX;

typedef struct _DRVMODEINFO
{
    BYTE	max_connection;
}
DRVMODEINFO, *PDRVMODEINFO;

typedef struct _DRVMODEINFO_EX
{
    BYTE	max_connection;
    BYTE	drvctl;
    BYTE	ignorejam;
    BYTE	reserved[5];
}
DRVMODEINFO_EX, *PDRVMODEINFO_EX;

typedef struct _TCPSVRINFO
{
    WORD	cmd_port;
    WORD	listen_port;
    DWORD	max_connection;
}
TCPSVRINFO, *PTCPSVRINFO;

typedef struct _TCPSVRINFO_EX
{
    WORD	cmd_port;
    WORD	listen_port;
    BYTE	max_connection;
    BYTE	drvctl;
    BYTE	ignorejam;
    BYTE	reserved[5];
}
TCPSVRINFO_EX, *PTCPSVRINFO_EX;

typedef struct _TCPCLI_ITEM
{
    char	dest_svr[MAXMULTISESSION][HOSTNAMELEN];
    WORD	dest_port[MAXMULTISESSION];
}
TCPCLIITEM;

typedef struct _TCPCLI_ITEM_EX
{
    char	dest_svr[MAXMULTISESSION][HOSTNAMELEN];
    WORD	dest_port[MAXMULTISESSION];
    WORD	local_port[MAXMULTISESSION];
}
TCPCLIITEM_EX;

typedef struct _TCPCLIINFO
{
    TCPCLIITEM	tcpcli_item;
    WORD	conn_mode;
    WORD	reserved;
}
TCPCLIINFO, *PTCPCLIINFO;

typedef struct _TCPCLIINFO_EX
{
    TCPCLIITEM_EX	tcpcli_item;
    WORD	conn_mode;
    BYTE	ignorejam;
    BYTE	reserved[5];
}
TCPCLIINFO_EX, *PTCPCLIINFO_EX;

typedef struct _UDP_ITEM
{
    DWORD ip[2];
    DWORD port;
}
UDP_ITEM;

typedef struct _UDP_INFO
{
    UDP_ITEM udpitem[4];
    WORD	port;
    WORD	reversed;
}
UDP_INFO, *PUDP_INFO;

typedef struct _PAIRCONN
{
    WORD	src_port;
    WORD	dest_port;
    char	dest_svr[HOSTNAMELEN];
}
PAIRCONN, *PPAIRCONN;

typedef struct _ETH_MODEM
{
    char	modem_reg[HOSTNAMELEN];
}
ETHMODEM, *PETHMODEM;

typedef struct _RTELNET
{
    WORD listen_port;
    BYTE mapcrlf;
    BYTE reversed[5];
}
RTELNET, *PRTELNET;

typedef struct _ACCESSIPINFO
{
    DWORD	mode;
    DWORD	ip_addr;
    DWORD	mask;
}
ACCESSIPINFO, *PACCESSIPINFO;

typedef struct _ALERTINFO
{
    WORD	event;
    WORD	mail;
    WORD	trap;
    WORD	dout;
}
ALERTINFO, *PALERTINFO;

typedef struct _PORTALERTINFO
{
    BYTE	event;
    BYTE	mail;
    BYTE	trap;
    BYTE	dout;
}
PORTALERTINFO, *PPORTALERTINFO;

typedef struct _SYSLOG
{
    WORD	year;
    BYTE	month;
    BYTE	day;
    BYTE	hour;
    BYTE	min;
    BYTE	sec;
    BYTE	type;
    WORD	Port;
    BYTE	reserved[54];
}
SYSLOG, *PSYSLOG;

typedef struct _FSINFO
{
    BYTE            havefs;
    BYTE            reserved[3];
    char            name[FSNAME];
    DWORD           ver;
    DWORD           time;
    DWORD           size;
}
FSINFO, *PFSINFO;

typedef struct _AUDIOINFO
{
    char            name[FSNAME];
    DWORD           size;
	BYTE			reserved[8];
}
AUDIOINFO, *PAUDIOINFO;

typedef struct _PPP_CONFIG
{
    BYTE			opmode;
    BYTE			disconnectmode;
    BYTE			supportLQR;
    BYTE			authtype;
    char			myusername[PPPNAMELEN];
    char			mypassword[PPPPASSWORDLEN];
    DWORD			localip;
    DWORD			remoteip;
    DWORD			netmask;
    DWORD			baudrate;
    BYTE			datamode;
    BYTE			flowctrl;
    BYTE			reverse[2];
    BYTE			dialoutcmd[PPPDIALOUTLEN];
}
PPPCONFIG, *PPPPCONFIG;

typedef struct _PPP_CONFIG_EX
{
    BYTE		flags;
    BYTE		authType;
    WORD		rev;
    DWORD		localIP;
    DWORD		remoteIP;
    DWORD		netmask;
    char		modemInitStr[MODEMINITSTRLEN];
    char		modemAtCmd[MODEMATCMDLEN];
}
PPPCONFIG_EX, *PPPPCONFIG_EX;

typedef struct _PPP_STATUS
{
    WORD			pppstate;
    WORD            reserved;
    DWORD			myip;
    DWORD			remoteip;
}
PPPSTATUS, *PPPPSTATUS;

typedef struct _PPP_STATISTIC
{
    DWORD			lasttimeconnect;
    DWORD			lasttimedisconnect;
    DWORD			sendbytes;
    DWORD			recvbytes;
}
PPPSTATISTIC, *PPPPSTATISTIC;

typedef struct _PPP_AUTHTBL
{
    char			remoteusername[MAXUSER][PPPNAMELEN];
    char			remotepassword[MAXUSER][PPPPASSWORDLEN];
}
PPPAUTHTBL, *PPPPAUTHTBL;

typedef struct _PPP_AUTHTBL_EX
{
    char		username[PPPNAMELEN_EX];
    char		password[PPPPASSWORDLEN_EX];
}
PPPAUTHTBL_EX, *PPPPAUTHTBL_EX;

typedef struct _ACL_ITEM
{
    DWORD	host_ip;
    DWORD	host_msk;
    WORD	ports_flag;
}
ACL_ITEM;

typedef struct _ACL_TABLE
{
    WORD	total_item;		//+------------------------------+
    WORD	start_item;		//			+.....
    WORD	item_num;		//			+--item_num----+
    ACL_ITEM	rights_ip[MAXACLITEM];
}
ACL_TABLE;

typedef struct _PORT_MONITOR_INFO
{
    UCHAR	connectStat;
    UCHAR	lineStatus;
    UCHAR	charMode;
    UCHAR	flowCtrl;
    ULONG	baudRate;
    ULONG	idleTime;			// unit, seconds
    UCHAR	loginName[52];
    ULONG	loginIP;
    ULONG	loginTime;			// unit, seconds
    ULONG	totalTxCnt;
    ULONG	totalRxCnt;
    ULONG	loginTxCnt;
    ULONG	loginRxCnt;
    ULONG	sysTimer;			// unit, mini seconds
    short	iface;
}
PORT_MONITOR_INFO;

typedef struct _DS_IP_ADDR {
	WORD  ipnum;
	char* ip[MAXIPNUM];
}
DS_IP_ADDR, *PDS_IP_ADDR;

// OPCode 0x5C group
typedef struct _R_GET_FILE{
	DWORD       file_status;  // 0 = file ok or exist, -1 = file not exist
	DWORD       file_len;     // in/out argument, in: length of file_buf, out: used length of file_buf
	void        *file_buf;
}R_GET_FILE, *P_R_GET_FILE;
// -------------------------

typedef struct _LLDP_INFO {
	BYTE  state;
	BYTE  reserved;
	WORD  time;
}
LLDP_INFO, *PLLDP_INFO;
//will
typedef struct _PASSWORDEX_DATA{	//struct for OpCode 0x7A catalog 0x0002 func 0x0001
	WORD	isChanged;
}PASSWORDEX_DATA;

typedef struct _NOTIFICATION_DATA{
	WORD welcomeLen;
	char *welcomeMsg;
	WORD failLen;
	char *failMsg;
}NOTIFICATION_DATA;

typedef struct _PASSWORD_POLICY_DATA{
	WORD output_items_num;
	WORD *items;
}PASSWORD_POLICY_DATA;

typedef struct _PASSWORD_POLICY_PDATA{
	WORD *output_items_num;
	WORD *items;
}PASSWORD_POLICY_PDATA;

typedef struct _ACCOUNT_LOCKOUT_DATA{
	WORD enable;
	DWORD threshold;
	DWORD lockout_time;
	char reserved[2];
}ACCOUNT_LOCKOUT_DATA;

typedef struct _ACCOUNT_LOCKOUT_PDATA{
	WORD *enable;
	DWORD *threshold;
	DWORD *lockout_time;
}ACCOUNT_LOCKOUT_PDATA;

typedef struct _SYSLOG_SERVER_INFO{
	WORD severity;
	WORD facility;
	WORD port;
	char domain[MAX_EXT_DOMAIN_LEN];
}SYSLOG_SERVER_INFO, *PSYSLOG_SERVER_INFO;

typedef struct _SYSLOG_SERVER_DATA{
	WORD server_num;
	SYSLOG_SERVER_INFO *server_info;
}SYSLOG_SERVER_DATA;

typedef struct _SYSLOG_SERVER_PDATA{
	WORD *server_num;
	SYSLOG_SERVER_INFO *server_info;
}SYSLOG_SERVER_PDATA;

typedef struct _SNMP_TRAP_INFO{
	WORD version;
	char community[MAX_COMMUNITY_LEN];
	char domain[MAX_EXT_DOMAIN_LEN];
	BYTE encrypt_mode;
	char reserved[31];
}SNMP_TRAP_INFO, *PSNMP_TRAP_INFO;

typedef struct _SNMP_TRAP_DATA{
	WORD trap_num;
	SNMP_TRAP_INFO *snmp_trap_info;
}SNMP_TRAP_DATA;

typedef struct _SNMP_TRAP_PDATA{
	WORD *trap_num;
	SNMP_TRAP_INFO *snmp_trap_info;
}SNMP_TRAP_PDATA;

typedef struct _SET_CONSOLE_EX_DATA{
	WORD output_items_num;
	char *items;
}SET_CONSOLE_EX_DATA;

typedef struct _SET_CONSOLE_EX_PDATA{
	WORD *output_items_num;
	WORD *items;
}SET_CONSOLE_EX_PDATA;

#define SNMP_STR_LEN 64
typedef struct _SNMP_AGENT_INFO{
	BYTE enable;
	WORD version;
	char rcommunity[SNMP_STR_LEN];
	char wcommunity[SNMP_STR_LEN];
	char contact[SNMP_STR_LEN];
	char location[SNMP_STR_LEN];
	BYTE ro_auth;
	char ro_username[SNMP_STR_LEN];
	char ro_password[SNMP_STR_LEN];
	BYTE ro_priv_mode;
	char ro_privacy[SNMP_STR_LEN];
	BYTE rw_auth;
	char rw_username[SNMP_STR_LEN];
	char rw_password[SNMP_STR_LEN];
	BYTE rw_priv_mode;
	char rw_privacy[SNMP_STR_LEN];
	BYTE encrypt_mode;
}
SNMP_AGENT_INFO, *PSNMP_AGENT_INFO;

typedef struct _SSL_CONFIG_DATA{
	WORD output_items_num;
	char *items;
}SSL_CONFIG_DATA;

typedef struct _SSL_CONFIG_PDATA{
	WORD *output_items_num;
	WORD *items;
}SSL_CONFIG_PDATA;

typedef struct _SYSTEM_LOG_DATA{
	WORD  output_items_num;
	DWORD *items;
}SYSTEM_LOG_DATA;

typedef struct _SYSTEM_LOG_PDATA{
	WORD  *output_items_num;
	DWORD *items;
}SYSTEM_LOG_PDATA;

//
typedef struct _ACCOUNT_INFO{
	WORD	uid_len;
	char	uid[32 + 1];
	DWORD	user_group;
	BYTE	active;
	DWORD	support_field;
	char	password[32 + 1];
}ACCOUNT_INFO, *PACCOUNT_INFO;

//Will
#define SALT_LEN	16
typedef struct _ACCOUNT_INFO_EXT{
	WORD	user_num;
	BYTE	salt[SALT_LEN];/* AP don't need fill */
	PACCOUNT_INFO account_info;
}ACCOUNT_INFO_EXT, *PACCOUNT_INFO_EXT;

typedef struct _MULTI_LAN_PDATA{
	WORD  *output_items_num;
	WORD *items;
}MULTI_PDATA;

typedef struct _LOG_CAPA_INFO{
	BYTE	enable;
	BYTE	warning_at;
	BYTE	warning_by;
	BYTE	oversize_act;
	DWORD	reserved;
}LOG_CAPA_INFO, *PLOG_CAPA_INFO;

typedef struct _TLS_INFO{
	WORD data_len;
	BYTE *data;
}TLS_INFO, *PTLS_INFO;

typedef struct _ENCRYPT_INFO{
	WORD data_len;
	BYTE *data;
}ENCRYPT_INFO, *PENCRYPT_INFO;
//
typedef struct _DSINFO
{
    WORD    tot_len;
    BYTE    capa_len;
    BYTE    capa_resv_data[512];    // contain capability, reserved[3], data
}
DSINFO, *PDSINFO;
//#endif //_BASE_DEFINE

typedef int (CALLBACK* WNDENUMSEARCHPROC)(PDS_INFO);
typedef int (CALLBACK* WNDLIBPROC)(DWORD, int, int, LPVOID);

#ifdef __cplusplus
extern "C"
{
#endif

    DLLEXPORT int MX_FUNC dsc_SetArpTable(char *str_ip, char *str_mac);
    DLLEXPORT int MX_FUNC dsc_DelArpTable(char *str_ip);
//DLLEXPORT int MX_FUNC dsc_GetKernelInfo_old(DS_HANDLE dshandle, PRSP_OPCALL_DATA info);
    DLLEXPORT int MX_FUNC dsc_GetKernelInfo_old(DS_HANDLE dshandle, PKERNELINFO info);
    DLLEXPORT int MX_FUNC dsc_SetIPMask_old(DS_HANDLE dshandle, int ifid, DWORD newip, DWORD newmask);
    DLLEXPORT int MX_FUNC dsc_GetACL_old(DS_HANDLE dshandle, ACL_TABLE *info);
    DLLEXPORT int MX_FUNC dsc_SetACL_old(DS_HANDLE dshandle, ACL_TABLE* acl_table);
    DLLEXPORT int MX_FUNC dsc_GetOpMode_old(DS_HANDLE dshandle, int port, int *mode);
    DLLEXPORT int MX_FUNC dsc_GetMonitor_Old(DS_HANDLE dshandle, int *port_list, int port_cnt,
											 PORT_MONITOR_INFO* mon_info);

//////////////////////

    DLLEXPORT int MX_FUNC dsc_EnumSearch(short family, char* server_ip, WNDENUMSEARCHPROC lpenumsearchproc);
//    DLLEXPORT int MX_FUNC dsc_EnumSearch(DWORD server_ip, WNDENUMSEARCHPROC lpenumproc);
    DLLEXPORT int MX_FUNC dsc_EnumSearch_ex(DWORD server_ip, WNDENUMSEARCHPROC lpenumproc, PDS_INFO ds_info, int max);
    DLLEXPORT int MX_FUNC dsc_Attach(PDS_INFO info, DS_HANDLE *dshandle);
    DLLEXPORT int MX_FUNC dsc_Detach(DS_HANDLE dshandle);
	//Will    
	DLLEXPORT int MX_FUNC dsc_Locate(DS_HANDLE dshandle, int sw);
	DLLEXPORT int MX_FUNC dsc_GetBuildDate(DS_HANDLE dshandle, DWORD* build_date);
	//    
	DLLEXPORT int MX_FUNC dsc_GetName(DS_HANDLE dshandle, char *name);
    DLLEXPORT int MX_FUNC dsc_GetFsInfo(DS_HANDLE dshandle, PFSINFO fsinfo);
    DLLEXPORT int MX_FUNC dsc_GetWatchdog(DS_HANDLE dshandle, int *setting);
    DLLEXPORT int MX_FUNC dsc_GetDebug(DS_HANDLE dshandle, int *setting);
    DLLEXPORT int MX_FUNC dsc_GetNetstat(DS_HANDLE dshandle, int maxsocket, int *retcnt, PNETSTATINFO info);
    DLLEXPORT int MX_FUNC dsc_GetAPInfo(DS_HANDLE dshandle, PAPINFO info);
    DLLEXPORT int MX_FUNC dsc_GetKernelInfo(DS_HANDLE dshandle, PKERNELINFO info);
    DLLEXPORT int MX_FUNC dsc_GetAPStatus(DS_HANDLE dshandle, int *status);
    DLLEXPORT int MX_FUNC dsc_GetEnvironmentMode(DS_HANDLE dshandle, int *mode);
    DLLEXPORT int MX_FUNC dsc_GetConsole(DS_HANDLE dshandle, int *settings);
    DLLEXPORT int MX_FUNC dsc_GetTime(DS_HANDLE dshandle, PSYSTEMTIME systm);
    DLLEXPORT int MX_FUNC dsc_GetTimeServer(DS_HANDLE dshandle, char *tmsvr);
    DLLEXPORT int MX_FUNC dsc_GetTimeZone(DS_HANDLE dshandle, LONG *time_zone, DWORD *time_zone_idx);
    DLLEXPORT int MX_FUNC dsc_GetNetstat_ex(DS_HANDLE dshandle, int maxsocket, int *retcnt, PNETSTATINFO info);
    DLLEXPORT int MX_FUNC dsc_GetAudioInfo(DS_HANDLE dshandle, PAUDIOINFO info);

    DLLEXPORT int MX_FUNC dsc_GetIP(DS_HANDLE dshandle, int ifid, DWORD *ip);
    DLLEXPORT int MX_FUNC dsc_GetNetmask(DS_HANDLE dshandle, int ifid, DWORD *netmask);
    DLLEXPORT int MX_FUNC dsc_GetGateway(DS_HANDLE dshandle, int ifid, DWORD *gateway);

    DLLEXPORT int MX_FUNC dsc_GetIP_V6(DS_HANDLE dshandle, int ifid, PDS_IP_ADDR ip);
    DLLEXPORT int MX_FUNC dsc_GetPrefix_V6(DS_HANDLE dshandle, int ifid, WORD* prefix);
    DLLEXPORT int MX_FUNC dsc_GetGateway_V6(DS_HANDLE dshandle, int ifid, char* gateway);

    DLLEXPORT int MX_FUNC dsc_GetIPConfig(DS_HANDLE dshandle, int ifid, int *setting);
    DLLEXPORT int MX_FUNC dsc_GetIfConfig(DS_HANDLE dshandle, int maxif, int *retcnt, PIFCONFIGINFO info);
    DLLEXPORT int MX_FUNC dsc_GetDNS(DS_HANDLE dshandle, int ifid, DWORD *dns1, DWORD *dns2);
    DLLEXPORT int MX_FUNC dsc_GetSNMP(DS_HANDLE dshandle, PSNMPINFO snmpinfo);
    DLLEXPORT int MX_FUNC dsc_GetMailAlert(DS_HANDLE dshandle, PMAILINFO mailinfo);

    DLLEXPORT int MX_FUNC dsc_GetMAC(DS_HANDLE dshandle, int ifid, char *mac);

    DLLEXPORT int MX_FUNC dsc_GetIPLocation(DS_HANDLE dshandle, int ifid, PIPLOCATIONINFO info);
    DLLEXPORT int MX_FUNC dsc_GetSerialIOCtl(DS_HANDLE dshandle, int port, int mode, PSERPARMITEM info);
    DLLEXPORT int MX_FUNC dsc_GetSerialFIFO(DS_HANDLE dshandle, int port, int mode,  LPBYTE info);
    DLLEXPORT int MX_FUNC dsc_GetSerialDataCount(DS_HANDLE dshandle, int port, PSERDATACNT info);
    DLLEXPORT int MX_FUNC dsc_GetSerialLineStatus(DS_HANDLE dshandle, int port, LPBYTE info);
    DLLEXPORT int MX_FUNC dsc_GetSerialInterface(DS_HANDLE dshandle, int port, int mode, LPBYTE info);
    DLLEXPORT int MX_FUNC dsc_GetSerialPortName(DS_HANDLE dshandle, int port, char name[MAXPORT][PORTNAMELEN]);

    DLLEXPORT int MX_FUNC dsc_GetRedundantCOMStatus(DS_HANDLE dshandle, int port, PREDCOMSTATUS info);

    DLLEXPORT int MX_FUNC dsc_GetOpMode(DS_HANDLE dshandle, int port, int *mode);

    DLLEXPORT int MX_FUNC dsc_GetDataPacking(DS_HANDLE dshandle, int port, PDATAPACKINGINFO info);
    DLLEXPORT int MX_FUNC dsc_GetInactivityTime(DS_HANDLE dshandle, int port, WORD *inact_tm);
    DLLEXPORT int MX_FUNC dsc_GetTCPAliveTime(DS_HANDLE dshandle, int port, WORD *alive_tm);
    DLLEXPORT int MX_FUNC dsc_GetDriverMode(DS_HANDLE dshandle, int port, PDRVMODEINFO info);
    DLLEXPORT int MX_FUNC dsc_GetTCPServerMode(DS_HANDLE dshandle, int port, PTCPSVRINFO info);
    DLLEXPORT int MX_FUNC dsc_GetTCPClientMode(DS_HANDLE dshandle, int port, PTCPCLIINFO info);
    DLLEXPORT int MX_FUNC dsc_GetUDPMode(DS_HANDLE dshandle, int port, UDP_INFO info[MAXPORT]);
    DLLEXPORT int MX_FUNC dsc_GetConnection(DS_HANDLE dshandle, int port, PPAIRCONN info);
    DLLEXPORT int MX_FUNC dsc_GetEmodem(DS_HANDLE dshandle, int port, PETHMODEM info);

    DLLEXPORT int MX_FUNC dsc_GetIPFilter(DS_HANDLE dshandle, int idx, int *enable_filter, PACCESSIPINFO info);
	//Will
	DLLEXPORT int MX_FUNC dsc_GetIPFilterWithPlus(DS_HANDLE dshandle, int idx, int *enable_filter, int *enalbe_plus, PACCESSIPINFO info);	
	//    
	DLLEXPORT int MX_FUNC dsc_GetAlert(DS_HANDLE dshandle, PALERTINFO info);
    DLLEXPORT int MX_FUNC dsc_GetPortAlert(DS_HANDLE dshandle, int port, PPORTALERTINFO info);

    DLLEXPORT int MX_FUNC dsc_GetPPPStatus(DS_HANDLE dshandle, int port, PPPPSTATUS pstatus);
    DLLEXPORT int MX_FUNC dsc_GetPPPStatistic(DS_HANDLE dshandle, int port, PPPPSTATISTIC pstatistic);

    DLLEXPORT int	MX_FUNC dsc_Login(DS_HANDLE dshandle, char *password);
    DLLEXPORT int         MX_FUNC dsc_SetLogin_Ex(DS_HANDLE dshandle, WORD uid_len, char *uid, WORD encryption_protocol, WORD password_len_mode, char *password);
    DLLEXPORT int	MX_FUNC dsc_Logout(DS_HANDLE dshandle);
    DLLEXPORT int	MX_FUNC dsc_SaveAndRestart(DS_HANDLE dshandle);
    DLLEXPORT int	MX_FUNC dsc_SaveAndRestart_Ex(DS_HANDLE dshandle, int port, BYTE mode);
    //DLLEXPORT int	MX_FUNC dsc_ReadConfig(DS_HANDLE dshandle, int* config_len);
	//Will
	DLLEXPORT int	MX_FUNC dsc_ReadConfig(DS_HANDLE dshandle, int* config_len);
	//
    DLLEXPORT int	MX_FUNC dsc_receive_data(DS_HANDLE dshandle, char* buffer, int len);
    DLLEXPORT int	MX_FUNC dsc_UpdateConfig(DS_HANDLE dshandle, char* file_path);

    DLLEXPORT int	MX_FUNC dsc_Reset(DS_HANDLE dshandle, int port);
    DLLEXPORT int	MX_FUNC dsc_SetName(DS_HANDLE dshandle, char *name);
    DLLEXPORT int	MX_FUNC dsc_SetPassword(DS_HANDLE dshandle, char *password);
    DLLEXPORT int	MX_FUNC dsc_SetWatchdog(DS_HANDLE dshandle, int settings);
    DLLEXPORT int	MX_FUNC dsc_SetDebug(DS_HANDLE dshandle, int settings);
	//Will
	DLLEXPORT int	MX_FUNC dsc_SetToFactoryDefault(DS_HANDLE dshandle);

	//
    DLLEXPORT int	MX_FUNC dsc_SetConsole(DS_HANDLE dshandle, int settings);
    DLLEXPORT int	MX_FUNC dsc_SetTime(DS_HANDLE dshandle, PSYSTEMTIME systm);
    DLLEXPORT int	MX_FUNC dsc_SetTimeServer(DS_HANDLE dshandle, char *tmsvr);
    DLLEXPORT int	MX_FUNC dsc_SetTimeZone(DS_HANDLE dshandle, LONG time_zone, DWORD time_zone_idx);
    DLLEXPORT int	MX_FUNC dsc_SetPrivateKey(DS_HANDLE dshandle, char *key);
    DLLEXPORT int	MX_FUNC dsc_RunOrStopUserAp(DS_HANDLE dshandle, int setting);

    DLLEXPORT int	MX_FUNC dsc_SetIP(DS_HANDLE dshandle, int ifid, DWORD newip);
    DLLEXPORT int	MX_FUNC dsc_SetNetmask(DS_HANDLE dshandle, int ifid, DWORD netmask);
    DLLEXPORT int	MX_FUNC dsc_SetGateway(DS_HANDLE dshandle, int ifid, DWORD gateway);

    DLLEXPORT int	MX_FUNC dsc_SetIP_V6(DS_HANDLE dshandle, int ifid, char* newip);
    DLLEXPORT int	MX_FUNC dsc_SetPrefix_V6(DS_HANDLE dshandle, int ifid, WORD prefix);
    DLLEXPORT int	MX_FUNC dsc_SetGateway_V6(DS_HANDLE dshandle, int ifid, char* gateway);

    DLLEXPORT int	MX_FUNC dsc_SetIPConfig(DS_HANDLE dshandle, int ifid, int setting);
    DLLEXPORT int	MX_FUNC dsc_SetIPLocation(DS_HANDLE dshandle, int ifid, PIPLOCATIONINFO info);
    DLLEXPORT int	MX_FUNC dsc_SetDNS(DS_HANDLE dshandle, int ifid, DWORD dns1, DWORD dns2);
    DLLEXPORT int	MX_FUNC dsc_SetSNMP(DS_HANDLE dshandle, PSNMPINFO snmpinfo);
    DLLEXPORT int 	MX_FUNC dsc_SetMailAlert(DS_HANDLE dshandle, PMAILINFO mailinfo);

    DLLEXPORT int	MX_FUNC dsc_SetSerialIOCtl(DS_HANDLE dshandle, int port, BYTE baud, BYTE mode, BYTE flowctrl);
    DLLEXPORT int	MX_FUNC dsc_SetSerialFIFO(DS_HANDLE dshandle, int port, int setting);
    DLLEXPORT int	MX_FUNC dsc_SetSerialInterface(DS_HANDLE dshandle, int port, int setting);
    DLLEXPORT int	MX_FUNC dsc_SetSerialPortName(DS_HANDLE dshandle, int port, char *portname);

    DLLEXPORT int	MX_FUNC dsc_SetOPMode(DS_HANDLE dshandle, int port, int mode);
    DLLEXPORT int	MX_FUNC dsc_SetDataPacking(DS_HANDLE dshandle, int port, PDATAPACKINGINFO info);
    DLLEXPORT int	MX_FUNC dsc_SetInactivityTime(DS_HANDLE dshandle, int port, WORD inact_time);
    DLLEXPORT int	MX_FUNC dsc_SetTCPAlive(DS_HANDLE dshandle, int port, WORD alive_tm);
    DLLEXPORT int	MX_FUNC dsc_SetDriverMode(DS_HANDLE dshandle, int port, PDRVMODEINFO info);
    DLLEXPORT int	MX_FUNC dsc_SetTCPSvrMode(DS_HANDLE dshandle, int port, PTCPSVRINFO info);
    DLLEXPORT int	MX_FUNC dsc_SetTCPCliMode(DS_HANDLE dshandle, int port, PTCPCLIINFO info);
    DLLEXPORT int	MX_FUNC dsc_SetUDPMode(DS_HANDLE dshandle, int port, PUDP_INFO info);
    DLLEXPORT int	MX_FUNC dsc_SetConnection(DS_HANDLE dshandle, int port, PPAIRCONN info);
    DLLEXPORT int	MX_FUNC dsc_SetEmodem(DS_HANDLE dshandle, int port, PETHMODEM info);

    DLLEXPORT int	MX_FUNC dsc_SetIPFilter(DS_HANDLE dshandle, int enable_ipfilter, PACCESSIPINFO info);
	//Will
	DLLEXPORT int	MX_FUNC dsc_SetIPFilterWithPlus(DS_HANDLE dshandle, int enable_ipfilter, int enable_plus, PACCESSIPINFO info);
	//    
	DLLEXPORT int	MX_FUNC dsc_SetAlert(DS_HANDLE dshandle, PALERTINFO info);
    DLLEXPORT int	MX_FUNC dsc_SetPortAlert(DS_HANDLE dshandle, int port, PPORTALERTINFO info);

    DLLEXPORT int	MX_FUNC dsc_SetMailAcount(DS_HANDLE dshandle, char *username, char *password);
    DLLEXPORT int	MX_FUNC dsc_RetriveMailAcount(DS_HANDLE dshandle, char *username, char *password);

    DLLEXPORT int	MX_FUNC dsc_ClearLog(DS_HANDLE dshandle);
    DLLEXPORT int	MX_FUNC dsc_RecvLog(DS_HANDLE dshandle, char *buf, DWORD len, DWORD *rlen);

    DLLEXPORT int	MX_FUNC dsc_Upgrade(DS_HANDLE dshandle, char *filename);
    DLLEXPORT int	MX_FUNC dsc_UpgradeAP(DS_HANDLE dshandle, char *filename);
    DLLEXPORT int	MX_FUNC dsc_UpgradeKernel(DS_HANDLE dshandle, char *filename);
    DLLEXPORT int	MX_FUNC dsc_UpgradeAPKernel(DS_HANDLE dshandle, char *filename);
    DLLEXPORT int	MX_FUNC dsc_UpgradeFile(DS_HANDLE dshandle, char *filename);
    DLLEXPORT int	MX_FUNC dsc_UpgradeFile_Ex(DS_HANDLE dshandle, char *filename , BYTE filetype);
    DLLEXPORT int	MX_FUNC dsc_Upgrade_WebKernel(DS_HANDLE dshandle, char *filename, PFSINFO fsinfo);

    DLLEXPORT int	MX_FUNC dsc_UpgradeAPConfig(DS_HANDLE dshandle, char *buf, DWORD len);
    DLLEXPORT int	MX_FUNC dsc_RecvAPConfig(DS_HANDLE dshandle, char *buf, DWORD len);

    DLLEXPORT void MX_FUNC dsc_SetSocketOpt(DS_HANDLE dshandle, BOOL socket_ver);
    DLLEXPORT void MX_FUNC dsc_SetSearchOpt(int timeout, int retrycnt);
    DLLEXPORT int MX_FUNC dsc_LibSetTimeout(DS_HANDLE dshandle, int timeout, int retrycnt);
    DLLEXPORT int MX_FUNC dsc_LibSetProc(DS_HANDLE dshandle, WNDLIBPROC lplibproc, LPVOID lpparam);
    DLLEXPORT int MX_FUNC dsc_GetDSINFO(DS_HANDLE dshandle, PDS_INFO dsinfo);
    DLLEXPORT int MX_FUNC dsc_UpdateDSINFO(DS_HANDLE dshandle, PDS_INFO dsinfo);
    DLLEXPORT int MX_FUNC dsc_LibSetUpgTimeout(DS_HANDLE dshandle, DWORD timeout);
    DLLEXPORT int MX_FUNC dsc_set_dsci_password_old(DS_HANDLE dshandle, char *password);

    DLLEXPORT int MX_FUNC dsc_ClearUserAP(DS_HANDLE dshandle);
    DLLEXPORT int MX_FUNC dsc_SetPPPConfig(DS_HANDLE dshandle, int port, PPPPCONFIG pconfig);
    DLLEXPORT int MX_FUNC dsc_GetPPPConfig(DS_HANDLE dshandle, int port, PPPPCONFIG pconfig);
    DLLEXPORT int MX_FUNC dsc_SetPPPAuthTable(DS_HANDLE dshandle, int user, PPPPAUTHTBL pauth);
    DLLEXPORT int MX_FUNC dsc_GetPPPAuthTable(DS_HANDLE dshandle, int *retuser, PPPPAUTHTBL pauth);
    DLLEXPORT int MX_FUNC dsc_GetPPPStatus(DS_HANDLE dshandle, int port, PPPPSTATUS pstatus);
    DLLEXPORT int MX_FUNC dsc_GetPPPStatistic(DS_HANDLE dshandle, int port, PPPPSTATISTIC pstatistic);
    DLLEXPORT BOOL MX_FUNC dsc_init(void);
    DLLEXPORT void MX_FUNC dsc_end(void);
    DLLEXPORT int	MX_FUNC dsc_SetSysPerformance(DS_HANDLE dshandle, BYTE mode);
    DLLEXPORT int	MX_FUNC dsc_SetLCMResetProtect(DS_HANDLE dshandle, BYTE protect);
    DLLEXPORT int	MX_FUNC dsc_SetRTelnet(DS_HANDLE dshandle, int port, PRTELNET info);
    DLLEXPORT int	MX_FUNC dsc_SetDataPacking_Ex(DS_HANDLE dshandle, int port, PDATAPACKINGINFO_EX info);
    DLLEXPORT int	MX_FUNC dsc_SetDriverMode_Ex(DS_HANDLE dshandle, int port, PDRVMODEINFO_EX info);
    DLLEXPORT int	MX_FUNC dsc_SetTCPSvrMode_Ex(DS_HANDLE dshandle, int port, PTCPSVRINFO_EX info);
    DLLEXPORT int	MX_FUNC dsc_SetTCPCliMode_Ex(DS_HANDLE dshandle, int port, PTCPCLIINFO_EX info);

    DLLEXPORT int MX_FUNC dsc_GetSysPerformance(DS_HANDLE dshandle, BYTE *mode);
    DLLEXPORT int MX_FUNC dsc_GetLCMResetProtect(DS_HANDLE dshandle, BYTE *protect);
    DLLEXPORT int MX_FUNC dsc_GetSysUpTime(DS_HANDLE dshandle, DWORD *time);
    DLLEXPORT int MX_FUNC dsc_GetRTelnet(DS_HANDLE dshandle, int port, PRTELNET info);
    DLLEXPORT int MX_FUNC dsc_GetDataPacking_Ex(DS_HANDLE dshandle, int port, PDATAPACKINGINFO_EX info);
    DLLEXPORT int MX_FUNC dsc_GetDriverMode_Ex(DS_HANDLE dshandle, int port, PDRVMODEINFO_EX info);
    DLLEXPORT int MX_FUNC dsc_GetTCPServerMode_Ex(DS_HANDLE dshandle, int port, PTCPSVRINFO_EX info);
    DLLEXPORT int MX_FUNC dsc_GetTCPClientMode_Ex(DS_HANDLE dshandle, int port, PTCPCLIINFO_EX info);
    DLLEXPORT int MX_FUNC dsc_SetPPPConfig_Ex(DS_HANDLE dshandle, int port, PPPPCONFIG_EX pconfig);
    DLLEXPORT int MX_FUNC dsc_SetPPPAuthTable_Ex(DS_HANDLE dshandle, int user, PPPPAUTHTBL_EX pauth);
    DLLEXPORT int MX_FUNC dsc_GetPPPConfig_Ex(DS_HANDLE dshandle, int port, PPPPCONFIG_EX pconfig);
    DLLEXPORT int MX_FUNC dsc_GetPPPAuthTable_Ex(DS_HANDLE dshandle, int *retuser, PPPPAUTHTBL_EX pauth);

    DLLEXPORT void MX_FUNC DoSetIpNetEntry(DWORD dwInetAddr, BYTE *bPhysAddr, DWORD dwIfIpAddr);
    DLLEXPORT void MX_FUNC DoDeleteIpNetEntry(DWORD dwInetAddr, DWORD dwIfIpAddr, BYTE *bPhysAddr);
    DLLEXPORT void MX_FUNC DoSetIpForwardEntry(DWORD Dest, DWORD NetMask, DWORD Gateway, DWORD dwIfIpAddr, DWORD dwMetric);
    DLLEXPORT void MX_FUNC DoDeleteIpForwardEntry(DWORD dwForwardDest);

    DLLEXPORT int MX_FUNC dsc_GetLLDP(DS_HANDLE dshandle, PLLDP_INFO info);
    DLLEXPORT int MX_FUNC dsc_SetLLDP(DS_HANDLE dshandle, PLLDP_INFO info);

    DLLEXPORT int MX_FUNC dsc_SetPassword_Ex(DS_HANDLE dshandle, WORD uid_len, char *uid, WORD old_pwd_encryption_protocol, 
                                            WORD old_password_len_mode, char *old_password, WORD new_pwd_encryption_protocol, 
                                            WORD new_password_len_mode, char *new_password);
		DLLEXPORT int	MX_FUNC dsc_SetAccount(DS_HANDLE dshandle, WORD user_number, PACCOUNT_INFO info);
	//Will
	DLLEXPORT int	MX_FUNC dsc_SetLoginNotification(DS_HANDLE dshandle, NOTIFICATION_DATA *inputData);
	DLLEXPORT int	MX_FUNC dsc_SetAccountLockout(DS_HANDLE dshandle, WORD enable, DWORD threshold, DWORD lockout_time);
	DLLEXPORT int	MX_FUNC dsc_SetPasswordPolicy(DS_HANDLE dshandle, WORD items_num, WORD *items);
	DLLEXPORT int	MX_FUNC dsc_SetSNMPTrap(DS_HANDLE dshandle, WORD trap_num, PSNMP_TRAP_INFO info);
	DLLEXPORT int	MX_FUNC dsc_SetSyslogServer(DS_HANDLE dshandle,WORD server_num, PSYSLOG_SERVER_INFO info);
	DLLEXPORT int	MX_FUNC dsc_SetConsole_Ex(DS_HANDLE dshandle, WORD items_num, WORD *items);
	DLLEXPORT int	MX_FUNC dsc_SetSnmpAgent(DS_HANDLE dshandle, PSNMP_AGENT_INFO info);
	DLLEXPORT int	MX_FUNC dsc_SetSSLConfig(DS_HANDLE dshandle, WORD items_num, WORD *items);
	DLLEXPORT int	MX_FUNC dsc_SetSystemLog(DS_HANDLE dshandle, WORD items_num, DWORD *items);
	DLLEXPORT int	MX_FUNC dsc_SetAccount(DS_HANDLE dshandle, WORD user_number, PACCOUNT_INFO info);
	DLLEXPORT int	MX_FUNC dsc_SetMultiLanMode(DS_HANDLE dshandle, WORD items_num, WORD *items);
	DLLEXPORT int	MX_FUNC dsc_SetLogCapacity(DS_HANDLE dshandle, PLOG_CAPA_INFO log_capa_info);
	DLLEXPORT int	MX_FUNC dsc_SetTlsVersion(DS_HANDLE dshandle, PTLS_INFO info);
	DLLEXPORT int	MX_FUNC dsc_SetEncryptionVersion(DS_HANDLE dshandle, PENCRYPT_INFO info);
	//IMPORT_EXPORT int	MX_FUNC dsc_SetPresharedKey(DS_HANDLE dshandle, char *preshared_key);
	DLLEXPORT int	MX_FUNC dsc_SetMailAccount_ex(DS_HANDLE dshandle, char* username, char* password, WORD encrypt_mode);
	/*IMPORT_EXPORT int	DSCI_FUNC dsc_SetRetriveMailAccount_ex(DS_HANDLE dshandle, char* username, char* password);
	IMPORT_EXPORT int	DSCI_FUNC dsc_SetPresharedKey_ex(DS_HANDLE dshandle, char *preshared_key, WORD SecurityMode);*/

	DLLEXPORT int   MX_FUNC dsc_GetFullSerialNo(DS_HANDLE dshandle, char full_sn[FULL_SERIAL_NO_LEN+1]);
	DLLEXPORT int	MX_FUNC dsc_GetDefaultPassWordChange(DS_HANDLE dshandle, WORD *is_changed);
	DLLEXPORT int	MX_FUNC dsc_GetLoginNotification(DS_HANDLE dshandle, WORD max_welcome_len, WORD max_fail_len, NOTIFICATION_DATA *outputData);
	DLLEXPORT int	MX_FUNC dsc_GetAccountLockout(DS_HANDLE dshandle, WORD *enable, DWORD *threshold, DWORD *lockout_time);
	DLLEXPORT int	MX_FUNC dsc_GetPasswordPolicy(DS_HANDLE dshandle, WORD max_items_num, WORD *output_items_num, WORD *items);
	DLLEXPORT int	MX_FUNC dsc_GetSNMPTrap(DS_HANDLE dshandle, WORD max_trap_num, WORD *output_trap_num, PSNMP_TRAP_INFO info);
	DLLEXPORT int	MX_FUNC dsc_GetSyslogServer(DS_HANDLE dshandle, WORD max_server_num, WORD *output_server_num, PSYSLOG_SERVER_INFO info);
	DLLEXPORT int	MX_FUNC dsc_GetConsole_Ex(DS_HANDLE dshandle, WORD max_items_num, WORD *output_items_num, WORD *items);
	DLLEXPORT int	MX_FUNC dsc_GetSnmpAgent(DS_HANDLE dshandle, PSNMP_AGENT_INFO info);
	DLLEXPORT int	MX_FUNC dsc_GetSSLConfig(DS_HANDLE dshandle, WORD max_items_num, WORD *output_items_num, WORD *items);
	DLLEXPORT int	MX_FUNC dsc_GetSystemLog(DS_HANDLE dshandle, WORD max_items_num, WORD *output_items_num, DWORD *items);
	DLLEXPORT int	MX_FUNC dsc_GetAccount(DS_HANDLE dshandle, WORD max_user_num, PACCOUNT_INFO_EXT account_info);
	DLLEXPORT int	MX_FUNC dsc_GetMultiLanMode(DS_HANDLE dshandle, WORD max_items_num, WORD *output_items_num, WORD *items);
	DLLEXPORT int	MX_FUNC dsc_GetLogCapacity(DS_HANDLE dshandle, PLOG_CAPA_INFO log_capa_info);
	DLLEXPORT int	MX_FUNC dsc_GetTlsVersion(DS_HANDLE dshandle, PTLS_INFO tls_info);
	DLLEXPORT int	MX_FUNC dsc_GetEncryptionVersion(DS_HANDLE dshandle, PENCRYPT_INFO info);
	
	DLLEXPORT int MX_FUNC dsc_GetDSInfo_op3(DS_HANDLE dshandle, PDSINFO info);
	// ... Frank Ho Test 2009.02.19 ...
	DLLEXPORT void MX_FUNC DoGetIpForwardEntry(DWORD dwForwardDest);
	// ... end ...
	DLLEXPORT int dsc_GetFile(DS_HANDLE dshandle, DWORD query_mode, DWORD type, char file_name[GET_FILE_NAME_LEN], R_GET_FILE *rparam);
	
	DLLEXPORT int	dsc_Login_Express(DS_HANDLE dshandle, char *uid, char *password);
#pragma pack()


#ifdef __cplusplus
}
#endif

#endif	//_DSCI_H

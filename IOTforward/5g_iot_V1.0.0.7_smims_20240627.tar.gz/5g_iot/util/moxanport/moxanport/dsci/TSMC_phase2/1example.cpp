/***********************************************************************************************
    File name:	Example.cpp
 
    Description:
	This program demo how to use MOXA DSCI Lib to manage NPort from PC Host. 
	
	The Hardware connection is following:
	PC Host--- ~~LAN~~ ---[NPort]
	
	This program demo:
		how to search NPort and get information. 
		how to set serial interface. 
		how to set serial port speed.

	Use function:
		dsc_SetSearchOpt,	dsc_GetSerialInterface,		dsc_GetKernelInfo,
		dsc_EnumSearch,		dsc_GetSerialIOCtl,			dsc_Attach,			
		dsc_GetIfConfig,	dsc_Login,					dsc_Logout,
		dsc_SetSerialIOCtl,	dsc_SaveAndRestart,			dsc_SetSerialFIFO
	
    History:    
    	Version		Date			Comment
        1.0			12-27-2022		Wrote it.
************************************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <new>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <dsci.h>
#include "dsciDef.h"

#define		SET_NPORT_FUNCTION	0

#define		PASS_MASK		0x01

#define SEARCH_BROADCAST	"255.255.255.255"


typedef struct _PARAM_SET
{
	int SetIndex;
	int param1;
	int param2;
	BYTE baudrate_idx;
}PARAM_SET, *PPARAM_SET;

static CFGINFO	SearchInfo[MAX_DEVICE_NUM];
static int		search_count;
bool			main_flag;
#if 1
static int		BaudrateBuf[20] = { 50, 75, 110, 134, 150, 300, 600, 1200, 1800, 2400, 4800,
									7200, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600};
#endif
int CALLBACK EnumSearchProc(PDS_INFO dsinfo);
char Menu_Search(void);
int	Searching(int mode, DWORD search_ip);
void ShowSearchResult(void);
DWORD GetInputIP(int mode);
int SavetoPDS(CFGINFO *cfg_info, char *account, char *passwd, int mode, int port, PPARAM_SET pParam);
void SetNportFun(CFGINFO *cfg_info, int port, PPARAM_SET pParam);
int MenuSelectPort(void);
char Menu_Config(void);
void Configuration(int mode);


int main(void)
{
	DWORD			search_ip;

	printf("Welcome to DSCI Lib Example for Console Application!\n\n");
	main_flag = true;
	dsc_init();

	while (main_flag) {
		switch(Menu_Search()) {
		case 'a':
			printf("Broadcast Searching......");
			if (!Searching(BROADCAST, 0)) {
				printf("%d NPort found.\n\n", search_count);
				ShowSearchResult();
				Configuration(BROADCAST);	
			}
			break;
		case 'b':
			search_ip = GetInputIP(0);
			printf("Search By IP Address......");
			if (!Searching(SEARCH_BY_IP, search_ip)) {
				printf("OK.\n\n");
				ShowSearchResult();
				Configuration(SEARCH_BY_IP);	
			}
			break;
		case 'q':
			printf("Example Program End !\n");
			main_flag = false;
			break;
		default:
			printf("There isn't this option.\n\n");
			break;
		}
	}
	return 0;
}

char Menu_Search(void)
{
	char	ch;

	printf("Please select a way to search NPort, or Exit:\n");
	printf("a :Broadcast Searching\n");
	printf("b :Search by IP\n");
	printf("q :Exit\n\n");

	printf("Your choice: ");
	scanf(" %c", &ch);

	return ch;
}

int	Searching(int mode, DWORD search_ip)
{
	int		i, ret, retcnt;

	search_count = 0;

	// Set Search timeout and try count
	dsc_SetSearchOpt(SEARCH_TIMEOUT, SEARCH_RETRY_CNT);

	if (mode == BROADCAST) {
		dsc_EnumSearch(AF_INET, (char*)SEARCH_BROADCAST, EnumSearchProc);
	} else {
		char ip[16];

		memset(ip, 0x0, sizeof(ip));
		sprintf(ip, "%d.%d.%d.%d", ((BYTE*)(&search_ip))[0], ((BYTE*)(&search_ip))[1], ((BYTE*)(&search_ip))[2], ((BYTE*)(&search_ip))[3]);
		dsc_EnumSearch(AF_INET, ip, EnumSearchProc);
	}
	usleep(500);

	if (search_count <= 0) {
		printf("Not any NPort found !\n\n");
		return -1;
	}

	for (i=0; i<search_count; i++) {
		if ((ret=dsc_Attach(&SearchInfo[i].ds_info, &SearchInfo[i].dshdl)) != DSC_OK) {
			printf("dsc_Attach() fail, error code: %d.\n\n",ret);
			return -1;
		}
		// Get ip address, netmask, gateway
		SearchInfo[i].p_ifconfig = new IFCONFIGINFO;
		if ((ret=dsc_GetIfConfig(SearchInfo[i].dshdl, 1, &retcnt, SearchInfo[i].p_ifconfig)) != DSC_OK) {
			printf("dsc_GetIfConfig() fail, error code: %d.\n\n",ret);
			return -1;
		}
		//Get the NPort kernel/firmware information.
		SearchInfo[i].pkernel_info = new KERNELINFO;
		if ((ret=dsc_GetKernelInfo(SearchInfo[i].dshdl, SearchInfo[i].pkernel_info)) != DSC_OK) {
			printf("dsc_GetKernelInfo() fail, error code: %d.\n\n",ret);
			return -1;
		}

	}

	return 0;
}

bool DevList_MatchMac(LPBYTE mac)
{
	int i=0;
	
	while(i<search_count)
	{
		if( memcmp(SearchInfo[i].ds_info.mac, mac,
						sizeof(SearchInfo[i].ds_info.mac)) == 0)
        {
			return true;
        }
		i++;
	}

	return false;
}

int CALLBACK EnumSearchProc(PDS_INFO dsinfo)
{
	if (dsinfo == NULL)
		return true;

    if (DevList_MatchMac(dsinfo->mac) == true)
    {
		return true;
    }

	memcpy(&SearchInfo[search_count].ds_info, dsinfo, sizeof(DS_INFO));
	search_count++;
	return false; // stop search when unitcast search
}

void ShowSearchResult(void)
{
	int				i, j;
	struct in_addr	ip;

	printf("Search Result:\n");
	printf("Num	IP Address\t\tMAC Address\n");

	for(i=0; i<search_count; i++) {
		ip.s_addr = SearchInfo[i].p_ifconfig->ipaddr;

		printf("%d\t%s\t%s\t", i+1, inet_ntoa(ip));

		for(j=0; j<6; j++) {
			printf("%02X", SearchInfo[i].ds_info.mac[j]);
			if (j<5)
				printf(":");
		}
		printf("\n");
	}
	printf("\n");
}

void Configuration(int mode)
{
	int		pds_num, port, i;
	char	ch[5], buf[10];
	bool	Config_flag;
	PARAM_SET	sParamSet;

	if (mode == BROADCAST) {
		printf("Please choice target NPort to control it.(Select the Num column)\n");
		printf("Your choice: ");
		scanf("%s", ch);
		pds_num = atoi(ch);
		if(pds_num<=0)
			pds_num = -1;
		pds_num -= 1;
	} else if (mode == SEARCH_BY_IP)
		pds_num = 0;

	if (pds_num < 0 || pds_num >= search_count) {
		printf("There isn't this Num.\n\n");
		return;
	}
	Config_flag = true;

	while (Config_flag) {
		switch(Menu_Config()) {
		case '1':
			port = MenuSelectPort();
			if(port==0)
			{
				printf("Quit from Configuration.\n\n");
				Config_flag = false;
				break;
			}
			sParamSet.SetIndex = 1;
			sParamSet.param1 = 1;
			SetNportFun(&SearchInfo[pds_num], port, &sParamSet);
			Config_flag = false;
			break;
		case '2':
			port = MenuSelectPort();
			if(port==0)
			{
				printf("Quit from Configuration.\n\n");
				Config_flag = false;
				break;
			}
			sParamSet.SetIndex = 1;
			sParamSet.param1 = 0;
			SetNportFun(&SearchInfo[pds_num], port, &sParamSet);
			Config_flag = false;
			break;
		case '3':
			port = MenuSelectPort();
			if(port==0)
			{
				printf("Quit from Configuration.\n\n");
				Config_flag = false;
				break;
			}
			sParamSet.SetIndex = 2;
			sParamSet.param2 = 0;
			SetNportFun(&SearchInfo[pds_num], port, &sParamSet);
			Config_flag = false;
			break;
		case '4':
			port = MenuSelectPort();
			if(port==0)
			{
				printf("Quit from Configuration.\n\n");
				Config_flag = false;
				break;
			}
			sParamSet.SetIndex = 2;
			sParamSet.param2 = 1;
			SetNportFun(&SearchInfo[pds_num], port, &sParamSet);
			Config_flag = false;
			break;
		case '5':
			port = MenuSelectPort();
			if(port==0)
			{
				printf("Quit from Configuration.\n\n");
				Config_flag = false;
				break;
			}
			sParamSet.SetIndex = 2;
			sParamSet.param2 = 2;
			SetNportFun(&SearchInfo[pds_num], port, &sParamSet);
			Config_flag = false;
			break;
		case '6':
			port = MenuSelectPort();
			if(port==0)
			{
				printf("Quit from Configuration.\n\n");
				Config_flag = false;
				break;
			}
			// ===== select baudrate =====
			printf("Please select a baudrate to be set:\n");
			for(i=0; i<20; i++) {
				printf("%d\t:", i);
				sprintf(buf, "%d", BaudrateBuf[i]);
				printf("%s\n", buf);
			}
			printf("\nYour choice: ");
			scanf("%s", buf);
			sParamSet.baudrate_idx = atoi(buf);
			// ===========================
			sParamSet.SetIndex = 3;
			SetNportFun(&SearchInfo[pds_num], port, &sParamSet);
			Config_flag = false;
			break;
		case '7':
			port = MenuSelectPort();
			if(port==0)
			{
				printf("Quit from Configuration.\n\n");
				Config_flag = false;
				break;
			}
			// ===== input local TCP port =====
			printf("Please input local TCP port:\n");
			scanf("%s", buf);
			sParamSet.param1 = atoi(buf);
			// ===== input TCP command port =====
			printf("Please input TCP command port:\n");
			scanf("%s", buf);
			sParamSet.param2 = atoi(buf);
			// ===========================
			sParamSet.SetIndex = 4;
			SetNportFun(&SearchInfo[pds_num], port, &sParamSet);
			Config_flag = false;
			break;
		case '8':
			port = MenuSelectPort();
			if(port==0)
			{
				printf("Quit from Configuration.\n\n");
				Config_flag = false;
				break;
			}
			// ===== input TCP alive check time =====
			printf("Please input TCP alive check time(min):\n");
			scanf("%s", buf);
			sParamSet.param1 = atoi(buf);
			// ===== input inactive time =====
			printf("Please input inactive time(ms):\n");
			scanf("%s", buf);
			sParamSet.param2 = atoi(buf);
			// ===========================
			sParamSet.SetIndex = 5;
			SetNportFun(&SearchInfo[pds_num], port, &sParamSet);
			Config_flag = false;
			break;
		case 'q':
			printf("Quit from Configuration.\n\n");
			Config_flag = false;
			break;
		default:
			printf("There isn't this option.\n");
			break;
		}
	}
}

char Menu_Config(void)
{
	char	ch;

	printf("\nConfigurate the NPort you selected, or Quit:\n");
	printf("1 :Enable serial FIOF\n");
	printf("2 :Disable serial FIFO\n");
	printf("3 :Set serial interface to RS232 mode\r\n");
	printf("4 :Set serial interface to RS422 mode\r\n");
	printf("5 :Set serial interface to RS485 mode\r\n");
	printf("6 :Set serial port baud rate\r\n");
	printf("7 :Set TCP Server port\r\n");
	printf("8 :Set TCP Server inactive time & TCP alive check time\r\n");
	printf("q :Quit\n\n");

	printf("Your choice: ");
	scanf(" %c", &ch);

	return ch;
}

int MenuSelectPort(void)
{
	char	ch[10];
	int SelNum;

	memset(ch, 0x0, sizeof(ch));
	printf("\nSelect port number. Input 0 is quit:\n");
	printf("Your choice: ");
	scanf(" %c", ch);
	SelNum = atoi(ch);
	if( (SelNum<1) || (SelNum>MAX_PORT_NUM) )
	{
		printf("\nInput number over range\r\n");
		return 0;
	}
	
	return SelNum;

}
void SetNportFun(CFGINFO *cfg_info, int port, PPARAM_SET pParam)
{
	char	password[32], account[32];
	int		i;

	// Password Checking if password enabled
	memset(password, 0, sizeof(password));
	memset(account, 0, sizeof(account));
	if (cfg_info->pkernel_info->flag & PASS_MASK) {
		// account
		printf("Please input User Account: ");
		scanf("%s", account);

		// password
		printf("Please input Password: ");
		scanf("%s", password);
	}

	printf("Setting NPort......");
	if (!SavetoPDS(cfg_info, account, password, SET_NPORT_FUNCTION, port, pParam)) 
		printf("OK\n");

	printf("\n");
}

int SavetoPDS(CFGINFO *cfg_info, char *account, char *passwd, int mode, int port, PPARAM_SET pParam)
{
	int		ret;

	if( (ret=dsc_Login_Express(cfg_info->dshdl, account, passwd))!=DSC_OK) {
		printf("dsc_Login() fail, error code: %d.\n",ret);
		main_flag = false;
		return -1;
	}

// ====================== setting region ===================
	if (mode == SET_NPORT_FUNCTION)
	{

	// ================ param 1 setting================
		if(pParam->SetIndex==1)
		{
			if( (ret=dsc_SetSerialFIFO(cfg_info->dshdl, port, pParam->param1 )) != DSC_OK )
			{
				printf("Get NPort Information error, error code: %d.\n",ret);
				dsc_Logout(cfg_info->dshdl);
				return -1;
			}
		}
	// ================ param 2 setting================
		if(pParam->SetIndex==2)
		{
			if( (ret=dsc_SetSerialInterface(cfg_info->dshdl, port, pParam->param2 )) != DSC_OK )
			{
				printf("Get NPort Information error, error code: %d.\n",ret);
				dsc_Logout(cfg_info->dshdl);
				return -1;
			}
		}
	// ================ param 3 setting================
		if(pParam->SetIndex==3)
		{
			dsc_GetSerialIOCtl(cfg_info->dshdl, port, 0, &cfg_info->pserial_info);
			if ((ret=dsc_SetSerialIOCtl(cfg_info->dshdl, port, pParam->baudrate_idx, cfg_info->pserial_info.mode, cfg_info->pserial_info.flowctrl)) != DSC_OK) {
				printf("dsc_SetSerialIOCtl() fail, error code: %d.\n",ret);
				dsc_Logout(cfg_info->dshdl);
				return -1;
			}
		}
	// ================ param 4 setting================
		if(pParam->SetIndex==4)
		{
			dsc_GetTCPServerMode_Ex(cfg_info->dshdl, port, &cfg_info->tcp_info);
			cfg_info->tcp_info.cmd_port = pParam->param2;
			cfg_info->tcp_info.listen_port = pParam->param1;
			if ((ret=dsc_SetTCPSvrMode_Ex(cfg_info->dshdl, port, &cfg_info->tcp_info)) != DSC_OK) {
				printf("dsc_SetTCPSvrMode_Ex() fail, error code: %d.\n",ret);
				dsc_Logout(cfg_info->dshdl);
				return -1;
			}
		}
	// ================ param 5 setting================
		if(pParam->SetIndex==5)
		{
			if ((ret=dsc_SetTCPAlive(cfg_info->dshdl, port, pParam->param1)) != DSC_OK) {
				printf("dsc_SetTCPAlive() fail, error code: %d.\n",ret);
				dsc_Logout(cfg_info->dshdl);
				return -1;
			}
			if ((ret=dsc_SetInactivityTime(cfg_info->dshdl, port, pParam->param2)) != DSC_OK) {
				printf("dsc_SetInactivityTime() fail, error code: %d.\n",ret);
				dsc_Logout(cfg_info->dshdl);
				return -1;
			}
		}
	}
// ==========================================================

	if ((ret=dsc_SaveAndRestart(cfg_info->dshdl)) != DSC_OK) {
		printf("dsc_SaveAndRestart() fail, error code: %d.\n",ret);
		dsc_Logout(cfg_info->dshdl);
		return -1;
	}

	if ((ret=dsc_Logout(cfg_info->dshdl)) != DSC_OK) {
		printf("dsc_Logout() fail, error code: %d.\n",ret);
		return -1;
	}

	return 0;
}

DWORD GetInputIP(int mode)
{
	char	ipbuf[30];

	if (mode) 
		printf("Please input new IP address: ");
	else
		printf("Please input IP Address to be searched: ");

	memset(ipbuf, 0, sizeof(ipbuf));
	scanf("%s",ipbuf);
	
	return (inet_addr(ipbuf));
}

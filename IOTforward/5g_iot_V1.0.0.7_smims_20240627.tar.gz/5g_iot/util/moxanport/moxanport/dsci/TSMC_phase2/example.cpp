/***********************************************************************************************
    File name:	Example.cpp

    Description:
    This program demo how to use MOXA DSCI Lib to manage NPort from PC Host.

    The Hardware connection is following:
    PC Host--- ~~LAN~~ ---[NPort]

    This program demo:
        how to search NPort and get information.
        how to set serial interface.
        how to set serial port speed.

    Use function:
        dsc_SetSearchOpt,	dsc_GetSerialInterface,		dsc_GetKernelInfo,
        dsc_EnumSearch,		dsc_GetSerialIOCtl,			dsc_Attach,
        dsc_GetIfConfig,	dsc_Login,					dsc_Logout,
        dsc_SetSerialIOCtl,	dsc_SaveAndRestart,			dsc_SetSerialFIFO

    History:
        Version		Date			Comment
        1.0			12-27-2022		Wrote it.
************************************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <new>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <dsci.h>
#include "dsciDef.h"
#include <sqlite3.h>
#include <string>
#include <iostream>
#include <chrono>
#include <thread>

#define SET_NPORT_FUNCTION 0

#define PASS_MASK 0x01

#define SEARCH_BROADCAST "255.255.255.255"

typedef struct _PARAM_SET
{
    int SetIndex;
    int param1;
    int param2;
    BYTE baudrate_idx;
} PARAM_SET, *PPARAM_SET;

static CFGINFO SearchInfo[MAX_DEVICE_NUM];
static int search_count;
bool main_flag;
#if 1
static int BaudrateBuf[20] = {50, 75, 110, 134, 150, 300, 600, 1200, 1800, 2400, 4800,
                              7200, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600};
#endif
int CALLBACK EnumSearchProc(PDS_INFO dsinfo);
char Menu_Search(void);
int Searching(int mode, DWORD search_ip);
void ShowSearchResult(void);
DWORD GetInputIP(const char ip_address[]);
int SavetoPDS(CFGINFO *cfg_info, char *account, char *passwd, int mode, int port, PPARAM_SET pParam, int pParammode);
void SetNportFun(CFGINFO *cfg_info, int port, PPARAM_SET pParam, int pParammode);
int MenuSelectPort(void);
char Menu_Config(void);
void Configuration(int mode);
int ReadFromSQLite(const char *db_file);
bool DevList_MatchMac(LPBYTE mac);
enum DataBits
{
    FIVE_BITS = 0x00,
    SIX_BITS = 0x01,
    SEVEN_BITS = 0x02,
    EIGHT_BITS = 0x03
};
enum StopBits
{
    ONE_STOP_BIT = 0x00,
    TWO_STOP_BITS = 0x04
};

enum Parity
{
    NO_PARITY = 0x00,
    EVEN_PARITY = 0x18,
    ODD_PARITY = 0x08,
    MARK_PARITY = 0x28,
    SPACE_PARITY = 0x38
};
int ReadFromSQLite(const char *db_file)
{
    PARAM_SET sParamSet;
    DWORD search_ip;
    FILE *fp;
    char line[1024];
    CFGINFO devices[MAX_DEVICE_NUM];
    int device_count = 0;
    int modebyte = 0;
    DataBits dataBits;
    StopBits stopBits;
    Parity parity;
    dsc_init();
    sqlite3 *db;
    char *err_msg = 0;
    int rc, pds_num, port;
    unsigned char controlByte = 0x00;
    rc = sqlite3_open(db_file, &db);

    if (rc != SQLITE_OK)
    {
        fprintf(stderr, "無法打開數據庫: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }

    const char *sql = "SELECT * FROM deviceinfo";
    sqlite3_stmt *stmt;

    rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    if (rc != SQLITE_OK)
    {
        fprintf(stderr, "無法準備查詢語句: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }
    int ret;
    pds_num = 0;
    char passwd[32] = "1qaz@WSX";
    char account[32] = "admin";
    CFGINFO *cfg_info = &SearchInfo[pds_num];

    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW)
    {
        const char *serial_port = "";
        bool stopBitsSet = false; 
        bool partiySet = false; 
        bool dataBitsSet = false;
        for (int i = 0; i < sqlite3_column_count(stmt); ++i)
        {
            const unsigned char *j_raw = sqlite3_column_text(stmt, i);
            const char *j = reinterpret_cast<const char *>(j_raw);
            const unsigned char *slave_port_value_raw = sqlite3_column_text(stmt, 10);
            const char *slave_port_str = reinterpret_cast<const char *>(slave_port_value_raw);
            
            if (j == nullptr || *j == '\0')
                continue;

            
            if (slave_port_str == nullptr)
            {
                continue;
            }
            if (strcmp(j, slave_port_str) == 0)
            {

                int ip_length = 12;

                char ip[ip_length + 1];

                strncpy(ip, slave_port_str + 6, ip_length);

                ip[ip_length] = '\0';
                
                search_ip = GetInputIP(ip);

                if (!Searching(SEARCH_BY_IP, search_ip))
                {
                    printf("OK.\n\n");
                    ShowSearchResult();
                }

                serial_port = slave_port_str;
                int len = strlen(slave_port_str);
                char port_char = serial_port[len - 1];

                port = port_char - '0';
                if ((ret = dsc_Login_Express(cfg_info->dshdl, account, passwd)) != DSC_OK)
                {
                    printf("dsc_Login() fail, error code: %d.\n", ret);
                    main_flag = false;
                    return -1;
                }
            }
           
            if (strcmp(serial_port, "") != 0)
            {
                if (strcmp(j, "RS-422") == 0)
                {
                    sParamSet.SetIndex = 2;
                    sParamSet.param2 = 1;

                    
                    SetNportFun(&SearchInfo[pds_num], port, &sParamSet, controlByte);
                    sParamSet.SetIndex = 3;
                    controlByte |= dataBits;
                    controlByte |= stopBits;
                    controlByte |= parity;
                    
                    SearchInfo[pds_num].pserial_info.flowctrl = 0;
                    SetNportFun(&SearchInfo[pds_num], port, &sParamSet, controlByte);
                    serial_port = "";
                    stopBitsSet = false;
                    partiySet =false;
                    dataBitsSet=false;
                    controlByte = 0x00;
                    if ((ret = dsc_SaveAndRestart(cfg_info->dshdl)) != DSC_OK)
                    {
                        printf("dsc_SaveAndRestart() fail, error code: %d.\n", ret);
                        dsc_Logout(cfg_info->dshdl);
                        return -1;
                    }

                    if ((ret = dsc_Logout(cfg_info->dshdl)) != DSC_OK)
                    {
                        printf("dsc_Logout() fail, error code: %d.\n", ret);
                        return -1;
                    }
                    std::this_thread::sleep_for(std::chrono::seconds(3));
                    continue;
                }
                else if (strcmp(j, "RS-485") == 0)
                {

                    sParamSet.SetIndex = 3;

                    controlByte |= dataBits;
                    controlByte |= stopBits;
                    controlByte |= parity;

                    SearchInfo[pds_num].pserial_info.flowctrl = 0;
                    SetNportFun(&SearchInfo[pds_num], port, &sParamSet, controlByte);
                    
                    sParamSet.SetIndex = 2;
                    sParamSet.param2 = 2;
                    SetNportFun(&SearchInfo[pds_num], port, &sParamSet, controlByte);
                    serial_port = "";
                    controlByte = 0x00;
                    stopBitsSet = false;
                    partiySet =false;
                    dataBitsSet=false;
                    if ((ret = dsc_SaveAndRestart(cfg_info->dshdl)) != DSC_OK)
                    {
                        printf("dsc_SaveAndRestart() fail, error code: %d.\n", ret);
                        dsc_Logout(cfg_info->dshdl);
                        return -1;
                    }

                    if ((ret = dsc_Logout(cfg_info->dshdl)) != DSC_OK)
                    {
                        printf("dsc_Logout() fail, error code: %d.\n", ret);
                        return -1;
                    }
                    std::this_thread::sleep_for(std::chrono::seconds(3));
                    continue;
                }
                else if (strcmp(j, "RS-232") == 0)
                {

                    sParamSet.SetIndex = 2;
                    sParamSet.param2 = 0;
                    SetNportFun(&SearchInfo[pds_num], port, &sParamSet, controlByte);
                    sParamSet.SetIndex = 3;
                    controlByte |= dataBits;
                    controlByte |= stopBits;
                    controlByte |= parity;

                    SearchInfo[pds_num].pserial_info.flowctrl = 0;
                    SetNportFun(&SearchInfo[pds_num], port, &sParamSet, controlByte);
                    serial_port = "";
                    controlByte = 0x00;
                    stopBitsSet = false;
                    partiySet =false;
                    dataBitsSet=false;
                    if ((ret = dsc_SaveAndRestart(cfg_info->dshdl)) != DSC_OK)
                    {
                        printf("dsc_SaveAndRestart() fail, error code: %d.\n", ret);
                        dsc_Logout(cfg_info->dshdl);
                        return -1;
                    }

                    if ((ret = dsc_Logout(cfg_info->dshdl)) != DSC_OK)
                    {
                        printf("dsc_Logout() fail, error code: %d.\n", ret);
                        return -1;
                    }
                    std::this_thread::sleep_for(std::chrono::seconds(3));
                    continue;
                }
                else if (strcmp(j, "8") == 0&& !dataBitsSet)
                {
                    dataBits = EIGHT_BITS;
                    dataBitsSet=true;
                    continue;
                }
                else if (strcmp(j, "7") == 0 && !dataBitsSet)
                {
                    dataBits = SEVEN_BITS;
                    dataBitsSet=true;
                    continue;
                }
                else if (strcmp(j, "6") == 0&& !dataBitsSet)
                {
                    dataBits = SIX_BITS;
                    dataBitsSet=true;
                    continue;
                }
                else if (strcmp(j, "5") == 0&& !dataBitsSet)
                {
                    dataBits = FIVE_BITS;
                    dataBitsSet=true;
                    continue;
                }
                else if (strcmp(j, "1") == 0&& !stopBitsSet)
                {
                    
                   
                    stopBits = ONE_STOP_BIT;
                    stopBitsSet = true;           
                    
                    
                    continue;
                }
                else if (strcmp(j, "2") == 0&& !stopBitsSet)
                {
                     
                    stopBits = TWO_STOP_BITS;
                    stopBitsSet = true;        
                    
                    
                    continue;
                }
                else if (strcmp(j, "None") == 0 && !partiySet)
                {

                    parity = NO_PARITY;
                    partiySet=true;
                    continue;
                }
                else if (strcmp(j, "Even") == 0&& !partiySet)
                {
                    parity = EVEN_PARITY;
                    partiySet=true;
                    continue;
                }
                else if (strcmp(j, "Odd") == 0&& !partiySet)
                {
                    parity = ODD_PARITY;
                    partiySet=true;
                    continue;
                }
                for (int z = 0; z < 20; z++)
                {
                    std::string baudrateStr = std::to_string(BaudrateBuf[z]);
                    const char *baudrateChar = baudrateStr.c_str();
                    if (strcmp(j, baudrateChar) == 0)
                    {
                        sParamSet.baudrate_idx = z;
                        sParamSet.SetIndex = 3;

                        break;
                    }
                }
            }
        }
    }

    if (rc != SQLITE_DONE)
    {
        fprintf(stderr, "無法解析數據: %s\n", sqlite3_errmsg(db));
    }

    sqlite3_finalize(stmt);

    sqlite3_close(db);

    return 0;
}
int main(void)
{
    printf("start main:\n");
    const char *db_file = "/opt/5g_iot/web/sqlite/5giot.db";
    if (ReadFromSQLite(db_file) != 0)
    {
        printf("start end:\n");
        return 1;
    }

    return 0;
}
void ShowSearchResult(void)
{
    int i, j;
    struct in_addr ip;

    printf("Search Result:\n");
    printf("Num	IP Address\t\tMAC Address\n");

    for (i = 0; i < search_count; i++)
    {
        ip.s_addr = SearchInfo[i].p_ifconfig->ipaddr;

        printf("%d\t%s\t%s\t", i + 1, inet_ntoa(ip));

        for (j = 0; j < 6; j++)
        {
            printf("%02X", SearchInfo[i].ds_info.mac[j]);
            if (j < 5)
                printf(":");
        }
        printf("\n");
    }
    printf("\n");
}
void SetNportFun(CFGINFO *cfg_info, int port, PPARAM_SET pParam, int pParammode)
{
    char password[32] = "1qaz@WSX";
    char account[32] = "admin";

    int i;

    printf("Setting NPort......");
    if (!SavetoPDS(cfg_info, account, password, SET_NPORT_FUNCTION, port, pParam, pParammode))
        printf("OK\n");

    printf("\n");
}

int SavetoPDS(CFGINFO *cfg_info, char *account, char *passwd, int mode, int port, PPARAM_SET pParam, int pParammode)
{
    int ret;

    // if ((ret = dsc_Login_Express(cfg_info->dshdl, account, passwd)) != DSC_OK)
    //{
    //     printf("dsc_Login() fail, error code: %d.\n", ret);
    //     main_flag = false;
    //     return -1;
    // }

    // ====================== setting region ===================
    if (mode == SET_NPORT_FUNCTION)
    {

        // ================ param 1 setting================
        if (pParam->SetIndex == 1)
        {
            if ((ret = dsc_SetSerialFIFO(cfg_info->dshdl, port, pParam->param1)) != DSC_OK)
            {
                printf("Get NPort Information error, error code: %d.\n", ret);
                dsc_Logout(cfg_info->dshdl);
                return -1;
            }
        }
        // ================ param 2 setting================
        if (pParam->SetIndex == 2)
        {
            if ((ret = dsc_SetSerialInterface(cfg_info->dshdl, port, pParam->param2)) != DSC_OK)
            {
                printf("Get NPort Information error, error code: %d.\n", ret);
                dsc_Logout(cfg_info->dshdl);
                return -1;
            }
        }
        // ================ param 3 setting================
        if (pParam->SetIndex == 3)
        {
            dsc_GetSerialIOCtl(cfg_info->dshdl, port, 0, &cfg_info->pserial_info);
            if ((ret = dsc_SetSerialIOCtl(cfg_info->dshdl, port, pParam->baudrate_idx, pParammode, cfg_info->pserial_info.flowctrl)) != DSC_OK)
            {
                printf("dsc_SetSerialIOCtl() fail, error code: %d.\n", ret);
                dsc_Logout(cfg_info->dshdl);
                return -1;
            }
        }
    }
    // ==========================================================

    // if ((ret = dsc_SaveAndRestart(cfg_info->dshdl)) != DSC_OK)
    // {
    //   printf("dsc_SaveAndRestart() fail, error code: %d.\n", ret);
    //  dsc_Logout(cfg_info->dshdl);
    // return -1;
    // }

    // if ((ret = dsc_Logout(cfg_info->dshdl)) != DSC_OK)
    //{
    //   printf("dsc_Logout() fail, error code: %d.\n", ret);
    // return -1;
    // }

    return 0;
}
DWORD GetInputIP(const char ip_address[])
{
    char ipbuf[30];
    strcpy(ipbuf, ip_address);

    return (inet_addr(ipbuf));
}

int CALLBACK EnumSearchProc(PDS_INFO dsinfo)
{
    if (dsinfo == NULL)
        return true;

    if (DevList_MatchMac(dsinfo->mac) == true)
    {
        return true;
    }

    memcpy(&SearchInfo[search_count].ds_info, dsinfo, sizeof(DS_INFO));
    search_count++;
    return false; // stop search when unitcast search
}
bool DevList_MatchMac(LPBYTE mac)
{
    int i = 0;

    while (i < search_count)
    {
        if (memcmp(SearchInfo[i].ds_info.mac, mac,
                   sizeof(SearchInfo[i].ds_info.mac)) == 0)
        {
            return true;
        }
        i++;
    }

    return false;
}
int Searching(int mode, DWORD search_ip)
{
    int i, ret, retcnt;

    search_count = 0;

    // Set Search timeout and try count
    dsc_SetSearchOpt(SEARCH_TIMEOUT, SEARCH_RETRY_CNT);

    if (mode == BROADCAST)
    {
        dsc_EnumSearch(AF_INET, (char *)SEARCH_BROADCAST, EnumSearchProc);
    }
    else
    {
        char ip[16];

        memset(ip, 0x0, sizeof(ip));
        sprintf(ip, "%d.%d.%d.%d", ((BYTE *)(&search_ip))[0], ((BYTE *)(&search_ip))[1], ((BYTE *)(&search_ip))[2], ((BYTE *)(&search_ip))[3]);
        dsc_EnumSearch(AF_INET, ip, EnumSearchProc);
    }
    usleep(500);

    if (search_count <= 0)
    {
        printf("Not any NPort found !\n\n");
        return -1;
    }

    for (i = 0; i < search_count; i++)
    {
        if ((ret = dsc_Attach(&SearchInfo[i].ds_info, &SearchInfo[i].dshdl)) != DSC_OK)
        {
            printf("dsc_Attach() fail, error code: %d.\n\n", ret);
            return -1;
        }
        // Get ip address, netmask, gateway
        SearchInfo[i].p_ifconfig = new IFCONFIGINFO;
        if ((ret = dsc_GetIfConfig(SearchInfo[i].dshdl, 1, &retcnt, SearchInfo[i].p_ifconfig)) != DSC_OK)
        {
            printf("dsc_GetIfConfig() fail, error code: %d.\n\n", ret);
            return -1;
        }
        // Get the NPort kernel/firmware information.
        SearchInfo[i].pkernel_info = new KERNELINFO;
        if ((ret = dsc_GetKernelInfo(SearchInfo[i].dshdl, SearchInfo[i].pkernel_info)) != DSC_OK)
        {
            printf("dsc_GetKernelInfo() fail, error code: %d.\n\n", ret);
            return -1;
        }
    }

    return 0;
}

import os
import socket
import time
import json
import sqlite3
import paho.mqtt.client as mqtt
from datetime import datetime
import copy
# 常量
DEVICE_INFO_PATH = '/opt/5g_iot/config/deviceinfo.csv'
LOG_PATH = '/opt/5g_iot/log/{}{}{}.csv'
MQTT_CONFIG = {
    "ip": "127.0.0.1",
    "port": "1883",
    "username": "fivegiot",
    "password": "k76gH54s"
}
DB_PATH = '/opt/5g_iot/web/sqlite/5giot.db'
HEADER_TXT = "#UPDATETIME,SVID,MASTER_ADDRESS,MQTT_VALUE"
Timebool = True
device_setting_path = "/opt/5g_iot/config/check_tag_setting.txt"
# 讀取設備信息

reslut_list = []
count = 0
mqtt_bool = True
deviceinfo_list = []
db_info = {}
# 寫入標頭行


def write_header(log_path):
    try:
        with open(log_path, "w", encoding="utf-8") as fp:
            fp.write(HEADER_TXT + '\n')
    except FileNotFoundError:
        time.sleep(10)
        write_header(log_path)
# 讀取 CSV 文件的大小


def read_csv_size(file_path):

    try:
        with open(file_path, 'r') as fp:
            lines = fp.readlines()
            if len(lines) >= 500000:
                return False
    except FileNotFoundError:
        time.sleep(1)
        write_header(file_path)

    return True

# 讀取 CSV 文件


def read_csv(file_path):

    data = []
    try:
        with open(file_path, 'r') as fp:
            for line in fp:
                line = line.split('#')[0].strip()
                if line:
                    data.append(line.split(','))
    except FileNotFoundError:
        time.sleep(30)

    return data

# 轉換功能碼


def convert_functioncode(functioncode):
    if (functioncode == '1'):
        return '0'
    elif (functioncode == '2'):
        return '1'
    elif (functioncode == '3'):
        return '4'
    elif (functioncode == '4'):
        return '3'

# 獲取 SVID 信息


def fetch_svidinfo(data):

    result = []
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        device_csv = data[27:].split('.')[0]
        device_csv = device_csv[:-1]
        # 準確搜尋設備csv檔
        query = "SELECT class,parameterid,remark,tagname  FROM svidinfo WHERE class=?"
        cursor.execute(query, (device_csv,))
        rows = cursor.fetchall()
        if rows == []:
            device_csv = data[27:].split('.')[0]
            # 模糊搜尋設備csv檔
            cursor.execute(
                "SELECT class,parameterid,remark,tagname  FROM svidinfo WHERE ? LIKE '%' || class || '%'", (data,))
            rows = cursor.fetchall()
        cursor.close()
        conn.close()
        with open(data, 'r') as fp:
            lines = fp.readlines()[1:]
            values = [[line.split(',')[0], line.split(',')[1]]
                      for line in lines]

        for row in rows:
            for item in values:
                if item[0].zfill(3) == row[1]:
                    item[1] = row[3]
                    result.append(item)
                    break
    except sqlite3.Error:
        time.sleep(30)

    return result

# 寫入設備日誌


def write_device_log(data, log_path, batch_size=75, sleep_time=0.5):
    log_path = log_path.format(get_str_date())
    lines_to_write = []
    # 先處理資料並限制一次上傳大小
    for index, item in enumerate(data):
        if isinstance(item, str):
            lines_to_write.append(item + '\n')
        else:
            line = ",".join(map(str, item))
            lines_to_write.append(line + '\n')
        time.sleep(0.001)
        if (index + 1) % batch_size == 0:
            with open(log_path, "a", encoding="utf-8") as fp:
                fp.writelines(lines_to_write)
            lines_to_write = []
            time.sleep(sleep_time)

    if lines_to_write:
        with open(log_path, "a", encoding="utf-8") as fp:
            fp.writelines(lines_to_write)
            time.sleep(sleep_time)
# MQTT 消息處理


def on_message(client, userdata, msg):
    global mqtt_bool
    if mqtt_bool == True:
        mqtt_data = json.loads(msg.payload.decode())
        mqtt_data = {msg.topic: mqtt_data}
        source_mqtt_data_list.append(mqtt_data)


# 檢查設備映射


def check_device_mapping(data, device_path):
    check_tag = []
    for item in data:
        if item[0] in device_path:
            check_tag = item[1:]
            return check_tag

# 獲取當前日期的字符串表示


def get_str_date():
    list_tmp = list(time.localtime(time.time()))[:3]
    return '_'+'%04d%02d%02d' % tuple(list_tmp[:3])


# 設置 MQTT 客戶端

mqtt_client = mqtt.Client()
mqtt_client.username_pw_set("fivegiot", "k76gH54s")
mqtt_client.connect(MQTT_CONFIG["ip"], int(MQTT_CONFIG["port"]), int(10))
mqtt_data_list = []
source_mqtt_data_list = []
topic = "GIOT-GW/FIVEGIOT/UL/#"
mqtt_client.subscribe(topic)
mqtt_client.on_message = on_message
mqtt_client.loop_start()

data = read_csv(DEVICE_INFO_PATH)
start = time.perf_counter()
end = start
# 紀錄設備svid與點位
for item in data:

    dpm_id, chamber_id, data_val, device_type = item[2], item[3], item[15].strip(
    ), item[6]
    if chamber_id not in db_info:
        db_info[chamber_id] = []
    db_info[chamber_id].append(
        {'svid_info': fetch_svidinfo(data_val)})


while (Timebool):
    try:
        # 搜尋mqtt值兩秒
        while (time.perf_counter() - start < 2):
            time.sleep(1)
        # 停止收值
        mqtt_bool = False

        while source_mqtt_data_list:

            for item in data:
                dpm_id, chamber_id, data_val, device_type = item[2], item[3], item[15].strip(
                ), item[6]
                # 限制MODBUSTCP類型設備無法寫入
                if device_type == "MODBUSTCP":
                    continue

                log_file_path = LOG_PATH.format(dpm_id.strip().replace(
                    "'", ''), chamber_id.strip().replace("'", ''), get_str_date())
                # 填寫標頭
                # if not read_csv_size(log_file_path):
                #     write_header(log_file_path)

                # result = fetch_svidinfo(data_val)
                to_remove = []
                for result_item in db_info[chamber_id]:
                    device_db_info = result_item['svid_info']

                for mqtt_data in source_mqtt_data_list:
                    if not mqtt_data:
                        continue
                    # 解析mqtt傳值與設備svid對應
                    topic_prefix = "GIOT-GW/FIVEGIOT/UL/{}{}".format(
                        dpm_id.strip().replace("'", ""), chamber_id.strip().replace("'", ""))
                    for topic in list(mqtt_data.keys()):
                        if topic.startswith(topic_prefix):
                            for key, value in mqtt_data[topic].items():
                                value_str = str(value)

                                for result_item_item in device_db_info:
                                    if result_item_item[0].zfill(3) == key[:3]:

                                        device_info = [
                                            str(datetime.now())] + result_item_item + [value_str]
                                        deviceinfo_list.append(device_info)

                                        to_remove.append((topic, key))
                                        break
                    # 使用過的item清空
                    for topic, key in to_remove:
                        if topic in mqtt_data and key in mqtt_data[topic]:
                            del mqtt_data[topic][key]
                            if not mqtt_data[topic]:
                                del mqtt_data[topic]
                    to_remove = []
                # 填寫log
                write_device_log(deviceinfo_list, LOG_PATH.format(dpm_id.strip().replace(
                    "'", ''), chamber_id.strip().replace("'", ''), get_str_date()))
                # 使用過的item清除
                source_mqtt_data_list[:] = [
                    mqtt_data for mqtt_data in source_mqtt_data_list if mqtt_data]

                deviceinfo_list = []
            # 清空收值資料
            source_mqtt_data_list = []
            batch = []
        # 開始收值
        mqtt_bool = True
        start = time.perf_counter()
        source_mqtt_data_list = []
        time.sleep(0.001)
    except (socket.error, mqtt.MQTTException) as e:
        print("Error:", e)
        time.sleep(30)

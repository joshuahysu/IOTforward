#!/bin/bash
#sudo tcpdump -i any -X 'tcp port 5000 or tcp port 5001'
sudo tcpdump -i br0 tcp port 5000 or 5001

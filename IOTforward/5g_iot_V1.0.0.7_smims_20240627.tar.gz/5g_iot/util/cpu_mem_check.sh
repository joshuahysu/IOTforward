#!/bin/bash
exceed_threshold=false

while true
do
    cpu_percent=$(ps -eo pcpu | awk 'NR>1' | awk '{tot=tot+$1} END {print tot}')
    mem_percent=$(free | awk 'NR==2{printf "%.2f\n", $3*100/$2 }')
    current_time=$(date +"%Y-%m-%d %H:%M:%S")

    if [ $(echo "$cpu_percent > 90" | bc) -eq 1 ] || [ $(echo "$mem_percent > 90" | bc) -eq 1 ]; then
        if [ $exceed_threshold = false ]; then
            echo "[$current_time] CPU使用率：$cpu_percent%  記憶體使用率：$mem_percent%" >> /tmp/log/log_cpu_ram_use.txt
            exceed_threshold=true
        fi
    elif [ $exceed_threshold = true ] && [ $(echo "$cpu_percent < 80" | bc) -eq 1 ] && [ $(echo "$mem_percent < 80" | bc) -eq 1 ]; then
        echo "[$current_time] CPU使用率：$cpu_percent%  記憶體使用率：$mem_percent%" >> /tmp/log/log_cpu_ram_use.txt
        exceed_threshold=false
    fi

    sleep 5
done

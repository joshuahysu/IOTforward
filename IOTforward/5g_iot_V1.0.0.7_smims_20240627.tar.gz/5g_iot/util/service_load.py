#!/usr/bin/python3
import os


#-------------------------------------
def os_exec(str_cmd):
	print('$ ' + str_cmd)
	str_resp = os.popen(str_cmd).read()
	if len(str_resp) > 0:
		print(str_resp)
	return str_resp


#-------------------------------------
if __name__ == '__main__':
	str_5giot_service_path = '/opt/5g_iot/service/'
	str_system_service_path = '/etc/systemd/system/'

	list_5giot_service = os.listdir(str_5giot_service_path)

	for str_service in list_5giot_service:
		os_exec('sudo cp %s %s' % (str_5giot_service_path+str_service, str_system_service_path))

	os_exec('sudo systemctl daemon-reload')
	os_exec('sudo systemctl enable 5giot_manager.service')
	os_exec('sudo systemctl start 5giot_manager.service')


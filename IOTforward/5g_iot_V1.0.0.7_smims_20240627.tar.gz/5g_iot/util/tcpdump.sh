#!/bin/bash

tcpdump_log() {
    if pgrep -x "tcpdump" > /dev/null
    then
        echo "tcpdump is already running. Exiting..."
        return 1
    fi
    timestamp=$(date +"%Y%m%d_%H%M")
	logfile="/opt/5g_iot/log/tcpdump_log_${timestamp}.pcap"
    #logfile="/tmp/log/tcpdump_log_${timestamp}.pcap"  
    sudo tcpdump -i br0 tcp port 5000 or 5001 or 502 -w "$logfile" 2>&1 &  
    tcpdump_pid=$!  # 獲取 tcpdump 的進程 ID
    echo "tcpdump started with PID $tcpdump_pid"
    sleep 180  # 等待 3 分鐘
    sudo kill $tcpdump_pid  # 終止 tcpdump
    echo "tcpdump stopped"
}

tcpdump_log


#!/usr/bin/python3
import sys,socket
from pyModbusTCP.client import ModbusClient


if __name__ == '__main__':
	if len(sys.argv) < 5:
		print('Usage: read_modbus [ip_address] [port] [unit_id] [reg_address]')
		exit()


	try:
		socket.inet_aton(sys.argv[1])
		str_ip_addr = sys.argv[1]
	except:
		print('ERROR: [ip_address]')
		print('Usage: read_modbus [ip_address] [port] [unit_id] [reg_address]')
		exit()

	try:
		int_port = int(sys.argv[2])
	except:
		print('ERROR: [port]')
		print('Usage: read_modbus [ip_address] [port] [unit_id] [reg_address]')
		exit()

	try:
		int_unit_id = int(sys.argv[3])
	except:
		print('ERROR: [unit_id]')
		print('Usage: read_modbus [ip_address] [port] [unit_id] [reg_address]')
		exit()

	# ikki ServerFunctionCode
	# Coils              0
	# Discrete Inputs    1
	# Input Registers    2
	# Holding Registers  3

	# ikki FunctionCode
	# MODBUS_FC_READ_COILS              1
	# MODBUS_FC_READ_DISCRETE_INPUTS    2
	# MODBUS_FC_READ_HOLDING_REGISTERS  3
	# MODBUS_FC_READ_INPUT_REGISTERS    4

	# Data_Block         Prefix
	# Coils              0
	# Discrete Inputs    1
	# Input Registers    3
	# Holding Registers  4

	str_data_block = sys.argv[4][0]
	if str_data_block != '0' and str_data_block != '1' and str_data_block != '3' and str_data_block != '4':
		print('ERROR: [reg_address]')
		exit()

	str_reg_addr = sys.argv[4][1:]
	try:
		int_reg_addr = int(str_reg_addr) - 1
	except:
		print('ERROR: [reg_address]')
		print('Usage: read_modbus [ip_address] [port] [unit_id] [reg_address]')
		exit()

	client = ModbusClient(host=str_ip_addr, port=int_port, unit_id=int_unit_id, auto_open=True)
	if str_data_block == '4':
		list_tmp = client.read_holding_registers(reg_addr=int_reg_addr, reg_nb=1)
	elif str_data_block == '3':
		list_tmp = client.read_input_registers(reg_addr=int_reg_addr, reg_nb=1)
	elif str_data_block == '1':
		list_tmp = client.read_discrete_inputs(bit_addr=int_reg_addr, bit_nb=1)
	elif str_data_block == '0':
		list_tmp = client.read_coils(bit_addr=int_reg_addr, bit_nb=1)
	else:
		list_tmp = None

	if list_tmp != None:
		for item in list_tmp:
			print(item)

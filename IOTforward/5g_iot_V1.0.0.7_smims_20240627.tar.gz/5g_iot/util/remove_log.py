#!/usr/bin/python3
import os
import sys
import time


# ---------------

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: remove_log [days]')
        exit()

    try:
        int_days = int(sys.argv[1])
    except ValueError:
        print('ERROR: [days]')
        print('Usage: remove_log [days]')
        exit()

    # ------------------------------------
    int_service_restart_days = 5

    str_cmd = 'sudo systemctl status 5giot_secsgem.service | grep "Active: active (running)"'
    str_resp = os.popen(str_cmd).read()
    try:
        i = int(str_resp.split('; ')[1].split(' ', 1)[0])
    except:
        i = 0
    if i >= int_service_restart_days:
        str_cmd = 'sudo systemctl restart 5giot_secsgem.service'
        str_resp = os.popen(str_cmd).read()

    # ------------------------------------

    list_log_path = ['/opt/5g_iot/log']
    for str_path in list_log_path:
        try:
            os.chdir(str_path)
            list_name = os.listdir()
        except:
            continue

        for str_name in list_name:
            try:
                i = int('%04d%02d%02d' %
                        tuple(time.localtime(os.path.getmtime(str_name)))[:3])
                j = int('%04d%02d%02d' % tuple(time.localtime(
                    time.time() - int_days*24*60*60))[:3])
                x = int('%04d%02d%02d' %
                        tuple(time.localtime(time.time() - 10*24*60*60))[:3])
                if "1200" in str_name:
                    if i <= x:
                        os.remove(str_name)
                        print('delete: %s' % (str_path + os.sep + str_name))
                elif i <= j:
                    os.remove(str_name)
                    print('delete: %s' % (str_path + os.sep + str_name))
            except:
                pass

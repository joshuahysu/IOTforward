import os
import socket
import time
import json
import sqlite3
import paho.mqtt.client as mqtt
from datetime import datetime
from pyModbusTCP.client import ModbusClient

# Constants
DEVICE_INFO_PATH = '/opt/5g_iot/config/deviceinfo.csv'
LOG_PATH = '/opt/5g_iot/log/{}{}{}.csv'
DB_PATH = '/opt/5g_iot/web/sqlite/5giot.db'
HEADER_TXT = "#UPDATETIME,SVID,MASTER_ADDRESS,MQTT_VALUE"
Timebool = True
LSC_setting_path = "/opt/5g_iot/util/Lsc_tag_setting.txt"
# 設定 Modbus 伺服器參數
host = '127.0.0.1'  # 伺服器IP
port = 502          # Modbus TCP埠
db_info = {}
# 寫入標頭行


def write_header(log_path):
    try:
        with open(log_path, "w", encoding="utf-8") as fp:
            fp.write(HEADER_TXT + '\n')
    except FileNotFoundError:
        time.sleep(10)
        write_header(log_path)

# 讀取 CSV 文件的大小


def read_csv_size(file_path):

    try:
        with open(file_path, 'r') as fp:
            lines = fp.readlines()
            if len(lines) >= 500000:
                return False
    except FileNotFoundError:
        time.sleep(1)
        write_header(file_path)

    return True

# 讀取 CSV 文件


def read_csv(file_path):

    data = []
    try:
        with open(file_path, 'r') as fp:
            for line in fp:
                line = line.split('#')[0].strip()
                if line:
                    data.append(line.split(','))
    except FileNotFoundError:
        time.sleep(30)

    return data

# 轉換功能碼


def convert_functioncode(functioncode):
    if (functioncode == '1'):
        return '0'
    elif (functioncode == '2'):
        return '1'
    elif (functioncode == '3'):
        return '4'
    elif (functioncode == '4'):
        return '3'

# 獲取 SVID 信息


def fetch_svidinfo(data):

    result = []
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        device_csv = data[27:].split('.')[0]
        device_csv = device_csv[:-1]

        query = "SELECT class, parameterid, remark, address, functioncode FROM svidinfo WHERE class=?"
        cursor.execute(query, (device_csv,))
        rows = cursor.fetchall()
        if rows == []:
            device_csv = data[27:].split('.')[0]
            cursor.execute(
                "SELECT class,parameterid,remark,address,functioncode FROM svidinfo WHERE ? LIKE '%' || class || '%'", (data,))
            rows = cursor.fetchall()
        cursor.close()
        conn.close()

        with open(data, 'r') as fp:
            lines = fp.readlines()[1:]
            values = [[line.split(',')[0], line.split(',')[1]]
                      for line in lines]

        for row in rows:
            for item in values:
                if item[0].zfill(3) == row[1]:
                    # item[1] = row[2]
                    # item.insert(2, "NULL")

                    item[1] = convert_functioncode(row[4]) + row[3]

                    result.append(item)
                    break
    except sqlite3.Error:
        time.sleep(30)

    return result

# 寫入設備日誌


def write_device_log(data, log_path, batch_size=75, sleep_time=0.5):
    log_path = log_path.format(get_str_date())
    lines_to_write = []
    # 先處理資料並限制一次上傳大小
    for index, item in enumerate(data):
        if isinstance(item, str):
            lines_to_write.append(item + '\n')
        else:
            line = ",".join(map(str, item))
            lines_to_write.append(line + '\n')
        time.sleep(0.001)
        if (index + 1) % batch_size == 0:
            with open(log_path, "a", encoding="utf-8") as fp:
                fp.writelines(lines_to_write)
            lines_to_write = []
            time.sleep(sleep_time)

    if lines_to_write:
        with open(log_path, "a", encoding="utf-8") as fp:
            fp.writelines(lines_to_write)
            time.sleep(sleep_time)

# 檢查設備映射


def check_device_mapping(data, device_path):
    check_tag = []
    for item in data:
        if item[0] in device_path:
            check_tag = item[1:]
            return check_tag

# 獲取當前日期的字符串表示


def get_str_date():
    list_tmp = list(time.localtime(time.time()))[:3]
    return '_'+'%04d%02d%02d' % tuple(list_tmp[:3])

# 對應回傳位置


def check_batch_address(batch, results):
    filtered_result = [results.get(int(key), None) for key in batch]
    return filtered_result


# 根據functioncode使用不同方式讀取點位值

def functioncode_read(functioncode, batch, length, modbus_client):
    if functioncode == '4':
        list_tmp = modbus_client.read_holding_registers(
            reg_addr=batch, reg_nb=length)
    elif functioncode == '3':
        list_tmp = modbus_client.read_input_registers(
            reg_addr=batch, reg_nb=length)
    elif functioncode == '1':
        list_tmp = modbus_client.read_discrete_inputs(
            bit_addr=batch, bit_nb=length)
    elif functioncode == '0':
        list_tmp = modbus_client.read_coils(
            bit_addr=batch, bit_nb=length)
    else:
        list_tmp = None
        return list_tmp
    return list_tmp


def modbustcpclinet(host, port, stationid, addresses, register_count):
    # 創建 Modbus TCP 客戶端
    modbus_client = ModbusClient(host, port, stationid, auto_open=True)
    # 嘗試連接到伺服器
    # if not modbus_client.is_open():
    #     modbus_client.open()
    try:
        # 初始化空的批次讀取
        batch = []
        results = []
        sorted_batch = []
        device_info = []
        for svid, address in addresses:
            address = int(address)
            address_str = str(address)
            if address > 65535:

                function_code = address_str[0]

                address_last = address_str[1:].lstrip('0').zfill(4)

                address = int(function_code + address_last)
            # 如果批次不是空的且這個地址與批次中最後一個地址的差距超過設定值，則執行批次讀取
            if sorted_batch and abs(address - int(sorted_batch[0])) <= register_count:
                # 將地址添加到批次中
                batch.append('{:05d}'.format(address))
                sorted_batch = sorted(batch)

            else:
                if sorted_batch != []:
                    start_address = int(str(sorted_batch[0])[1:])-1
                    length = abs(
                        int(sorted_batch[0]) - int(sorted_batch[-1])) + 1
                    raw_result = functioncode_read(
                        str(sorted_batch[0])[:1], start_address, length, modbus_client)
                    if raw_result is not None:
                        result = {int(sorted_batch[0]) +
                                  i: raw_result[i] for i in range(len(raw_result))}
                        results.extend(check_batch_address(batch, result))
                    batch = []
                batch.append('{:05d}'.format(address))
                sorted_batch = sorted(batch)
        # 執行剩餘的批次讀取
        if sorted_batch:

            length = abs(int(sorted_batch[0]) - int(sorted_batch[-1])) + 1
            start_address = int(str(sorted_batch[0])[1:])-1
            raw_result = functioncode_read(
                str(sorted_batch[0])[:1], start_address, length, modbus_client)
            if raw_result is not None:
                result = {int(sorted_batch[0]) +
                          i: raw_result[i] for i in range(len(raw_result))}
                results.extend(check_batch_address(batch, result))

    # 將讀取到的值填入地址對應的陣列的第三個欄位
        for i, (svid, address) in enumerate(addresses):
            try:
                device_info_item = [str(
                    datetime.now())] + [svid] + [address] + [str(results[i])]
                device_info.append(device_info_item)
            except (Exception) as e:
                modbus_client.close()
                return device_info

        # 關閉連接
        modbus_client.close()
        # else:
        #     print("無法連接到Modbus伺服器")
    except Exception as e:
        print(f"Error in Modbus communication: {e}")
        modbus_client.close()
        return device_info
    return device_info


data = read_csv(DEVICE_INFO_PATH)
LSC_data = read_csv(LSC_setting_path)
diff_time = int(LSC_data[0][1])
search_range = int(LSC_data[1][1])
start = time.perf_counter()
end = start
count = 0
# 紀錄設備svid與點位
for item in data:

    dpm_id, chamber_id, data_val, device_type = item[2], item[3], item[15].strip(
    ), item[6]
    if chamber_id not in db_info:
        db_info[chamber_id] = []
    db_info[chamber_id].append(
        {'svid_info': fetch_svidinfo(data_val)})
while (Timebool):
    while (time.perf_counter() - start < diff_time):
        time.sleep(0.001)
    for item in data:

        dpm_id, chamber_id, data_val, device_ip, device_port, station_id, device_type = item[2], item[3], item[15].strip(
        ), item[13], item[14], item[7], item[6]
        if device_type != "MODBUSTCP":
            continue
        if (not read_csv_size(LOG_PATH.format(dpm_id.strip().replace(
                "'", ''), chamber_id.strip().replace("'", ''), get_str_date()))):
            write_header(LOG_PATH.format(dpm_id.strip().replace(
                "'", ''), chamber_id.strip().replace("'", ''), get_str_date()))

        # dpm_id, chamber_id, data_val = item[2], item[3], item[15][3:-2].strip()
        for result_item in db_info[chamber_id]:
            device_db_info = result_item['svid_info']
        # result = fetch_svidinfo(data_val)
        result = modbustcpclinet(device_ip, int(device_port),
                                 int(station_id), device_db_info, search_range)
        # check_tag = check_device_mapping(device_data, data_val)
        if result == None:
            continue
        write_device_log(result, LOG_PATH.format(dpm_id.strip().replace(
            "'", ''), chamber_id.strip().replace("'", ''), get_str_date()))
        start = time.perf_counter()
    time.sleep(0.001)

#!/usr/bin/python3
# History:
#   2022/11/28 v1.0.0:
#   2023/02/20 v1.1.0:
#     1. 加入動態設定 IP 到指定的網路介面的功能
#   2023/08/08 v1.1.1:
#     1. 移除從 dmesg 解析 serial port 寫入 comports.csv 的功能. 改用手工編輯
#     2. 加入設定 apn 的功能
#     3. 改用 mbimcli 控制 5g 連線
#   2023/12/06 v1.1.2:
#     1. 等待 /dev/cdc-wdm0 出現後再進行 5g 連線
# 2024/3/28 v1.1.3:
# 1. 新增 cpu判斷的service
#     2. other 看起來kapi有改過manager詳細請他再補
# 2024/06/06 v2.0.1:
#     1.新增新版modbus相關需要檔案與驗證程式

import os
import time
# -------------------------------------
str_version = 'v1.1.2,2023/12/06'
str_ver_filename = '5giot_manager_version.csv'


# -------------------------------------
def get_str_time():
    list_tmp = list(time.localtime(time.time()))[:6]
    return '%04d/%02d/%02d %02d:%02d:%02d' % tuple(list_tmp[:6])


def get_str_date():
    list_tmp = list(time.localtime(time.time()))[:3]
    return '%04d%02d%02d' % tuple(list_tmp[:3])


def print_log(str_msg):
    global str_log_path
    try:
        fp = open('%slog_5giot_manager_%s.txt' %
                  (str_log_path, get_str_date()), 'a')
        list_tmp = str_msg.split('\n')
        for str_tmp in list_tmp:
            if len(str_tmp):
                str_tmp = '%s: %s' % (get_str_time(), str_tmp)
                # print(str_tmp)
                fp.write(str_tmp + '\n')
        fp.close()
    except:
        pass


def os_exec(str_cmd):
    print_log('$ ' + str_cmd)
    str_resp = os.popen(str_cmd).read()
    if len(str_resp) > 0:
        print_log(str_resp)
    return str_resp


def service_try_start(str_service):
    str_resp = os_exec('systemctl status %s | grep Active:' %
                       str_service).lstrip().replace('Active: ', '').split(' ', 1)[0]
    if str_resp == 'inactive' or str_resp == 'failed':
        os_exec('sudo systemctl start %s' % str_service)


# -------------------------------------
if __name__ == '__main__':
    try:
        str_ver_path = os.environ['PATH_5GIOT_VER']
        if not str_ver_path.endswith(os.sep):
            str_ver_path += os.sep
    except:
        str_ver_path = ''

    try:
        str_cfg_path = os.environ['PATH_5GIOT_CFG']
        if not str_cfg_path.endswith(os.sep):
            str_cfg_path += os.sep
    except:
        str_cfg_path = ''

    try:
        str_log_path = os.environ['PATH_5GIOT_LOG']
        if not str_log_path.endswith(os.sep):
            str_log_path += os.sep
    except:
        str_log_path = ''

    # -------------------------

    os_exec('sudo rm /dev/shm/5g_iot/keep_value/*227')
    os_exec('sudo rm /opt/5g_iot/keep_value/*227')

    try:
        with open(str_cfg_path + 'local_IP.txt', 'r') as fp:
            str_ip, str_netmask = fp.readline().replace(
                '\r', '').replace('\n', '').split(',')
        with open(str_cfg_path + 'netif.cfg', 'r') as fp:
            str_netif = fp.readline().replace('\r', '').replace('\n', '')
    except:
        str_ip = ''
        str_netmask = ''
        str_netif = ''

    if len(str_ip) > 0 and len(str_netmask) > 0 and len(str_netif) > 0:
        i = 0
        try:
            for j in str_netmask.split('.'):
                i += bin(int(j)).count('1')
        except:
            i = 24
        os_exec('sudo ip addr add %s/%s dev %s label %s:1' %
                (str_ip, str(i), str_netif, str_netif))

    # -------------------------
    os_exec('sudo systemctl stop setting_serial_port.service')
    os_exec('sudo systemctl start setting_serial_port.service')
    os_exec('sudo systemctl stop checksdstatus.service')
    os_exec('sudo systemctl start checksdstatus.service')
    os_exec('sudo systemctl stop monitor_cpu_ram.service')
    os_exec('sudo systemctl start monitor_cpu_ram.service')
    os_exec('sudo systemctl start cachelog.service')
    os_exec('sudo systemctl stop modbus_tag_log.service')
    os_exec('sudo systemctl start modbus_tag_log.service')
    os_exec('sudo systemctl stop mqtt_tag_log.service')
    os_exec('sudo systemctl start mqtt_tag_log.service')
    flag_first_time = True
    str_wwan0_ip = ''
    while True:
        while not os.path.exists(str_cfg_path + 'no_dialup'):
            if not os.path.exists('/dev/cdc-wdm0'):
                time.sleep(1)
                continue
            if flag_first_time:
                flag_first_time = False
                try:
                    with open(str_cfg_path + 'apn.cfg', 'r') as fp:
                        str_apn = fp.read().rstrip()
                    with open('/etc/mbim-network.conf', 'w') as fp:
                        fp.write(
                            'APN=%s\nAPN_USER=\nAPN_PASS=\nPROXY=yes\n' % str_apn)
                except:
                    pass
                os_exec('sudo systemctl stop ModemManager.service')
                os_exec('sudo modprobe option')
                os_exec(
                    'echo "1e2d 00f1" | sudo tee /sys/bus/usb-serial/drivers/option1/new_id')
                os_exec(
                    'sudo mbimcli --device=/dev/cdc-wdm0 --device-open-proxy --set-radio-state=on')

            str_resp = os_exec(
                'sudo mbimcli -d /dev/cdc-wdm0 --device-open-proxy --query-ip-configuration')
            str_ip = ''
            for item in str_resp.split('\n'):
                str_tmp = item.lstrip()
                if str_tmp.startswith('IP [0]: '):
                    str_ip = str_tmp[str_tmp.find("'")+1:-1]
                    break
            if len(str_ip) > 0 and str_ip == str_wwan0_ip:  # 如果 ip 和上一次查詢的一樣就不作重新dialup的程序
                break

            os_exec('sudo systemctl stop 5giot_modbusservice.service')
            os_exec('sudo systemctl stop 5giot_secsgem.service')

            os_exec('sudo mbim-network /dev/cdc-wdm0 stop')
            os_exec('sudo ip link set wwan0 down')

            str_resp = os_exec(
                'sudo mbimcli -d /dev/cdc-wdm0 --query-registration-state --device-open-proxy')

            flag_continue = False
            flag_exit = True
            for item in str_resp.split('\n'):
                str_tmp = item.lstrip()
                if str_tmp.startswith('Register state: '):
                    if 'searching' in str_tmp or 'denied' in str_tmp:
                        flag_continue = True
                    flag_exit = False
                    break
            if flag_exit or flag_continue:  # 'searching' 沒插 SIM 卡或沒基地台, 'denied' 被基地台拒絕
                time.sleep(2)
                continue

            os_exec('sudo mbim-network /dev/cdc-wdm0 start')

            str_resp = os_exec(
                'sudo mbimcli -d /dev/cdc-wdm0 --device-open-proxy --query-ip-configuration')
            str_ip = ''
            for item in str_resp.split('\n'):
                str_tmp = item.lstrip()
                if str_tmp.startswith('IP [0]: '):
                    str_ip = str_tmp[str_tmp.find("'")+1:-1]
                    break
            if len(str_ip) == 0:   # 沒有查到 ip
                continue

            str_wwan0_ip = str_ip

            os_exec('sudo ip addr add %s dev wwan0' % str_wwan0_ip)
            os_exec('sudo ip link set wwan0 up')
            os_exec('sudo ip route add default dev wwan0')
            break
        # -------------------------------------------

        if not os.path.exists(str_cfg_path + 'no_simulator'):
            service_try_start('5giot_vcom_ebara_esr_est_ev-s_ev-m.service')
            service_try_start('5giot_vcom_edwards.service')
            service_try_start('5giot_vcom_ksy_mu_ts.service')
            service_try_start('5giot_vcom_ksy_sde_sdt_sdx_sdh.service')
            service_try_start('5giot_simulator_modbus_server.service')
            service_try_start('5giot_simulator_fins.service')
            service_try_start('5giot_simulator_ebara_esr_est_ev-s_ev-m.service')
            service_try_start('5giot_simulator_edwards.service')
            service_try_start('5giot_simulator_ksy_mu_ts.service')
            service_try_start('5giot_simulator_ksy_sde_sdt_sdx_sdh.service')


        service_try_start('5giot_remove_log.service')
        service_try_start('5giot_mqtt2multicast.service')
        service_try_start('5giot_calculator.service')
        service_try_start('5giot_hostlink_fins.service')
        service_try_start('5giot_modbus_client_tcp.service')
        service_try_start('5giot_modbus_client_rtu.service')
        service_try_start('5giot_backup_keep_value.service')
        service_try_start('5giot_fins2mqtt.service')
        service_try_start('5giot_dpm_ebara.service')
        service_try_start('5giot_dpm_edwards.service')
        service_try_start('5giot_dpm_ksy_mu_ts.service')
        service_try_start('5giot_dpm_ksy_sde_sdt_sdx_sdh.service')
        service_try_start('remove_secs_log.timer')       
        service_try_start('5giot_secsgem.service')
        service_try_start('5giot_modbusserverservice.service')

        time.sleep(5)

#!/usr/bin/python3
# -*- coding: utf-8 -*-
#---------------------------------------------
import socket, time, struct, sys
#---------------------------------------------
class message_multicast():
	def __init__(self, multicast_group=('224.0.0.1', 19999), str_interface='0.0.0.0', max_pkg_len=16384):
		self.max_pkg_len = max_pkg_len
		self.multicast_group = multicast_group
		self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
		self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.s.bind(multicast_group)
		self.s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(multicast_group[0])+socket.inet_aton(str_interface))
		self.s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(str_interface))
		self.s.setblocking(False)

	def msg_send(self, topic, msg):
		i = len(topic)
		if i < 1 and len(msg) < 1:
			return 0
		buf = struct.pack('>B', i) + topic + msg
		sum = 0
		for i in range(len(buf)):
			sum += struct.unpack('>B', buf[i:i+1])[0]
		buf += struct.pack('>B', sum & 0xff)
		i = len(buf)
		if i > self.max_pkg_len:
			raise IOError('max_pkg_len=%d, UDP package size > max_pkg_len' % self.max_pkg_len)
		self.s.sendto(buf, self.multicast_group)
		return i

	def msg_recv(self):
		try:
			data = self.s.recv(self.max_pkg_len)
		except BlockingIOError if sys.version_info.major > 2 else socket.error:
			data = b''
		if len(data) < 4:
			return b'', b''
		sum = 0
		for i in range(len(data[:-1])):
			sum += struct.unpack('>B', data[i:i+1])[0]
		sum &= 0xff
		if struct.unpack('>B', data[-1:])[0] != sum:
			return b'', b''
		i = 1 + struct.unpack('>B', data[0:1])[0]
		topic = data[1:i]
		msg = data[i:-1]
		if len(topic) == 0 or len(msg) == 0:
			return b'', b''
		return topic, msg
#---------------------------------------------
if __name__ == '__main__':
	mmc = message_multicast()
	while True:
		topic, msg = mmc.msg_recv()
		if len(topic) > 0:
			print(topic.decode('utf-8'), msg.decode('utf-8'))
		time.sleep(0.001)

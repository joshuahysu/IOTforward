#!/bin/bash
SD_DEVICE="/dev/mmcblk1p1"
DEVICE="/mnt/mmcblk1p1"
LOG_FILE="/mnt/mmcblk1p1/log"
RAW_DEVICE="/dev/mmcblk1"
log_path="/tmp/log/sd_alarm_log.txt"
# 檢查是否有讀取錯誤
check_read_errors() {
    if dmesg | grep -i "error.*$mmcblk1p1"; then
        echo "檢測到SD卡讀取錯誤。"
        
        return 1
    fi
    return 0
}
# 檢查原始設備是否存在
if [ -b "$RAW_DEVICE" ]; then
    echo "檢測到設備 $RAW_DEVICE。"
    # 檢查分區是否存在
    if [ ! -b "$SD_DEVICE" ]; then
        echo "未在 $RAW_DEVICE 上檢測到分區。正在創建分區..."
        echo -e "o\nn\np\n1\n\n\nw" | sudo fdisk $RAW_DEVICE
        sudo partprobe $RAW_DEVICE
        echo "已在 $RAW_DEVICE 上創建分區。"
        sleep 2  # 等待系統識別新分區
    else
        echo "分區 $SD_DEVICE 已經存在。"
    fi
else
    echo "未檢測到設備 $RAW_DEVICE。"
fi
#獲取sd卡系統類型
FS_TYPE=$(lsblk -no FSTYPE $SD_DEVICE)
#SYSTEMLOG_FILE="/mnt/mmcblk1p1/systemlog"
if [ -b "$SD_DEVICE" ]; then
    echo "SD card detected. Mounting..."
    sudo systemctl start mountsd.service
    if [ "$FS_TYPE" != "ext4" ]; then
        echo "SD卡文件系统不是ext4，需要格式化..."
    
        sleep 3
        if mount | grep -q "$SD_DEVICE"; then
        sudo umount $SD_DEVICE
        echo "SD卡卸載完成。"
        sudo mkfs.ext4 $SD_DEVICE
        else
        echo "SD卡未掛載，錯誤。"
        fi   
        echo "SD卡格式化完成。"
        sleep 2
        sudo mount $SD_DEVICE $DEVICE
    else
        echo "SD卡文件系统已經是ext4，無須格式化。"
    fi

    if [ -d "$LOG_FILE" ]; then
        echo "log file exists"
    else
        echo "log file does not exist"
        sudo mkdir -p "$DEVICE"
        sudo mkdir -p "$LOG_FILE"
        
    fi
    
        sudo rm -r /opt/5g_iot/log
        sudo ln -s /mnt/mmcblk1p1/log /opt/5g_iot/log
        
        sudo mkdir -p /tmp/log
        sudo mount -t tmpfs -o defaults,noatime,nosuid,nodev,noexec,mode=1777 tmpfs /tmp/log
        
else
    sudo mkdir -p /tmp/log
    sudo mount -t tmpfs -o defaults,noatime,nosuid,nodev,noexec,mode=1777 tmpfs /tmp/log
    sudo rm -rf "/opt/5g_iot/log"
    sudo ln -s "/dev/null" "/opt/5g_iot/log"
    echo "No SD card detected."
fi
# 最後檢查讀取錯誤
if check_read_errors; then
    echo "No SD card detected.please reboot!!!" >> "$log_path"
fi 
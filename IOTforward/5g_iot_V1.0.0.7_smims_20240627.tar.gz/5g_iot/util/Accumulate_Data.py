import os
import socket
import time
import json
import sqlite3
import paho.mqtt.client as mqtt

# Constants
DEVICE_INFO_PATH = '/opt/5g_iot/config/deviceinfo.csv'
LOG_PATH = '/tmp/log/{}{}{}'
MQTT_CONFIG = {
    "ip": "127.0.0.1",
    "port": "1883",
    "username": "fivegiot",
    "password": "k76gH54s"
}
DB_PATH = '/opt/5g_iot/web/sqlite/5giot.db'
HEADER_TXT = "#SVID,PARAMETER,MQTT_VALUE,SLAVE_ADDRESS,MASTER_ADDRESS"
Timebool = True



def write_header(log_path):

    with open(log_path, "w", encoding="utf-8") as fp:
        fp.write(HEADER_TXT + '\n')


def read_csv_size(file_path):

    try:
        with open(file_path, 'r') as fp:
            lines = fp.readlines()
            if len(lines) >= 1000:
                return False
    except FileNotFoundError:
        time.sleep(1)
        write_header(file_path)

    return True


def read_csv(file_path):

    data = []
    try:
        with open(file_path, 'r') as fp:
            for line in fp:
                line = line.split('#')[0].strip()
                if line:
                    data.append(line.split(','))
    except FileNotFoundError:
        time.sleep(30)

    return data


def fetch_svidinfo(data):

    result = []
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT class,parameterid,remark,address FROM svidinfo WHERE ? LIKE '%' || class || '%'", (data,))
        rows = cursor.fetchall()
        cursor.close()
        conn.close()

        with open(data, 'r') as fp:
            lines = fp.readlines()[1:]
            values = [[line.split(',')[0], line.split(',')[1]]
                      for line in lines]

        for row in rows:
            for item in values:
                if item[0].zfill(3) == row[1]:
                    item.insert(1, row[2])
                    item.insert(2, "NULL")
                    result.append(item + [row[3]])
                    break
    except sqlite3.Error:
        time.sleep(30)

    return result


def write_device_log(data, log_path):
    with open(log_path, "a", encoding="utf-8") as fp:
        if isinstance(data, str):
            fp.write(data + '\n')
        else:
            line = ",".join(map(str, data))
            fp.write(line + '\n')


def on_message(client, userdata, msg):
    mqtt_data = json.loads(msg.payload.decode())
    mqtt_data = {msg.topic: mqtt_data}
    mqtt_data_list.append(mqtt_data)
    print("Received MQTT data:", mqtt_data)


mqtt_client = mqtt.Client()
mqtt_client.username_pw_set("fivegiot", "k76gH54s")
mqtt_client.connect(MQTT_CONFIG["ip"], int(MQTT_CONFIG["port"]), int(10))
mqtt_data_list = []
topic = "GIOT-GW/FIVEGIOT/UL/#"
mqtt_client.subscribe(topic)
mqtt_client.on_message = on_message
mqtt_client.loop_start()
data = read_csv(DEVICE_INFO_PATH)
start = time.perf_counter()
end = start
while (Timebool):
    try:
        while (time.perf_counter() - start < 10):
            time.sleep(0.001)
        for item in data:
            dpm_id, chamber_id, data_val = item[2], item[3], item[15].strip()
            if (not read_csv_size(LOG_PATH.format(dpm_id.strip().replace(
                    "'", ''), chamber_id.strip().replace("'", ''), ".csv"))):
                write_header(LOG_PATH.format(dpm_id.strip().replace(
                    "'", ''), chamber_id.strip().replace("'", ''), ".csv"))
            # dpm_id, chamber_id, data_val = item[2], item[3], item[15][3:-2].strip()

            if mqtt_data_list:
                result = fetch_svidinfo(data_val)
                used_key = set()

                for mqtt_data in mqtt_data_list:
                    topic = "GIOT-GW/FIVEGIOT/UL/{}{}".format(
                        dpm_id.strip().replace("'", ""), chamber_id.strip().replace("'", ""))
                    if topic in mqtt_data:
                        for key, value in mqtt_data[topic].items():
                            value_str = str(value)
                            for result_item in result:
                                if result_item[0].zfill(3) == key and key not in used_key:
                                    used_key.add(key)
                                    result_item[2] = [value_str]
                                    write_device_log(result_item, LOG_PATH.format(dpm_id.strip().replace(
                                        "'", ''), chamber_id.strip().replace("'", ''), ".csv"))
                                    break
                start = time.perf_counter()
            if (time.perf_counter() - end > 600):
                Timebool = False
                mqtt_client.disconnect()
                write_device_log("_______stop..update______", LOG_PATH.format(dpm_id.strip().replace(
                    "'", ''), chamber_id.strip().replace("'", ''), ".csv"))

    except (socket.error, mqtt.MQTTException) as e:
        print("Error:", e)
        time.sleep(30)

#!/bin/bash

#    It's used to monitor CCG cellular status to auto logging the modem logs
#    The script control uses curl/jq
#    please install them before use this utility.

# Version:1.0.0.1

################################################################
########################  User Configs  ########################
################################################################
CCG_USER="admin"
CCG_PASSWORD="1qaz@WSX"
CCG_LAN_IP="192.168.1.254"
UC122A_WAN="192.168.1.2"

# Note that the MONITOR_SERARCHING_TIMEOUT setting needs to be greater than MONITOR_INTERVAL and divisible.
# The interval/timeout specified in seconds
MONITOR_INTERVAL=10
MONITOR_SERARCHING_TIMEOUT=60

# output path for compressed modem logs .
#DIAG_OUTPUT_PATH=/home/moxa/diag_output/
DIAG_OUTPUT_PATH=/opt/5g_iot/log/
# temp folder to write raw-data before stop diag-partner
DIAG_TMP_PATH=/run/diag
# modem logs output size limit, the oldest file will be deleted automatically when the capacity exceeds the limit.
# Specified in MB
DIAG_OUTPUT_SIZE_LIMIT=1000
# Default diag-partner setting.
DIAG_PORT=9123



################################################################
####################### Global Variables #######################
################################################################
VER=0.0.3
CCG_version="2.2"
CURL_BIN=$(which curl)
MDLOG_BIN=$(which diag-partner)

# CCG Restful APIs
API_TOKEN=
API_LOGIN="https://${CCG_LAN_IP}/api/v1/login"
API_LOGOUT="https://${CCG_LAN_IP}/api/v1/logout"
API_DIAG_PARTNER="https://${CCG_LAN_IP}/api/v1/diagpartner"
API_SIM_STATUS="https://${CCG_LAN_IP}/api/v1/sim_status"
API_WWAN_STATUS="https://${CCG_LAN_IP}/api/v1/wwan_status"
API_MODEM_STATUS="https://${CCG_LAN_IP}/api/v1/modem_status"
API_Log_Export="https://${CCG_LAN_IP}/api/v1/log_export"
API_Sys_info="https://${CCG_LAN_IP}/api/v1/system_information"

#HTTP Header
H_CONTENT_JSON="Content-Type: application/json"

# JSON data of CCG API
login_json="{\"username\": \"${CCG_USER}\", \"password\": \"${CCG_PASSWORD}\"}"
diagpartner_enable_json="{\"enable\": true, \"diagpartner_server_address\": \"${UC122A_WAN}\", \"diagpartner_service_port\": \"${DIAG_PORT}\"}"

_LOG() {
    logger -t "DIAGMONITOR" "$*"
}

# checking there have sim inserted then start to monitor
logout() {
    local res=$(${CURL_BIN} -X POST -H "${H_CONTENT_JSON}" -H "Cookie:token=${API_TOKEN}" -d "{}" "$API_LOGOUT" --insecure)
    unset -v API_TOKEN && export API_TOKEN=
}

http_req() {
    local method=$1
    local api=$2
    local json_data=$3
    local result=

	case ${method} in
		GET)
			result=$(${CURL_BIN} --insecure -X GET -H "Cookie:token=${API_TOKEN}" "${api}")
		;;
		PUT)
			result=$(${CURL_BIN} --insecure -X PUT -H "${H_CONTENT_JSON}" -H "Cookie:token=${API_TOKEN}" -d "${json_data}" "$api")
		;;
	esac

    echo ${result}
} 

gen_token() {
    local res=$(${CURL_BIN} -X POST -H "${H_CONTENT_JSON}" -d "$login_json" "$API_LOGIN" --insecure)
    API_TOKEN=$(echo "$res" | jq -r '.data.token')
    export API_TOKEN="${API_TOKEN}"
}

check_diagpartner_sender_enabled() {
    local res=$(http_req GET "${API_DIAG_PARTNER}")
    local is_enable=$(echo ${res} | jq -r '.data.enable')
    
    if [ x"${is_enable}" != x"true" ]; then
        local res=$(http_req PUT "${API_DIAG_PARTNER}" "${diagpartner_enable_json}")
        echo "Enable Diag-Partner: ${res}"        
    fi
}

check_sim_status() {
    local res=$(http_req GET "${API_SIM_STATUS}")
    local sim_status=$(echo ${res} | jq -r '.data.status')
    local rc=0
    
    if [ x"${sim_status}" != x"READY" ]; then
        rc=1
    fi

    echo ${sim_status}
    return ${rc}
}

# Check the modem registration status
# Return 0: Registerted
#        1: non-registerted
check_modem_status() {
    local res=$(http_req GET "${API_MODEM_STATUS}")
    local modem_reg_status=$(echo ${res} | jq -r '.data.common_info.registration')
    local rc=0
    
    if [ x"${modem_reg_status}" != x"Registered" ]; then
        rc=1
    fi
    
    echo ${modem_reg_status}
    return ${rc}
}

# Check the WWAN connection status
# Return 0: connected
#        1: disconnected
check_conn_status() {
    local res=$(http_req GET "${API_WWAN_STATUS}")
    local v4_conn_status=$(echo ${res} | jq -r '.data.wwan_ipconfig[].ip4_connected')
    local v6_conn_status=$(echo ${res} | jq -r '.data.wwan_ipconfig[].ip6_connected')
    local conn_status="connected"
    local rc=0
    
    if [ x"${v4_conn_status}" != x"true" ] && [ x"${v6_conn_status}" != x"true" ]; then
        conn_status="disconnected"
        rc=1
    fi
    
    echo ${conn_status}
    return ${rc}
}

_clean_output_mdlog() {
    local cur_size=$(du -s -m ${DIAG_OUTPUT_PATH} | sed 's/[[:space:]]//g' | cut -d '/' -f 1)
    local oldest_file=
    local rm_oldest=

    while [ $cur_size -gt ${DIAG_OUTPUT_SIZE_LIMIT} ]; do
        oldest_file=$(find "$DIAG_OUTPUT_PATH" -type f -printf '%T+ %p\n' | sort | head -n 1 | awk '{print $2}')
        _LOG "Reached diag upper size limit, rm the odlest '${oldest_file}'"
        rm_oldest=$(rm ${oldest_file})
        cur_size=$(du -s -m ${DIAG_OUTPUT_PATH} | sed 's/[[:space:]]//g' | cut -d '/' -f 1)
    done
}

_clean_unknown_tmp_mdlog() {
    local tmp_folder=
    if [ ! -z "${DIAG_TMP_PATH}" ]; then
        tmp_folder=$(echo ${DIAG_TMP_PATH} | cut -d '/' -f 3)
        local folders_to_delete=$(find ${DIAG_TMP_PATH}* -maxdepth 1 -type d ! -name "$tmp_folder")
        if [ ! -z "${folders_to_delete}" ]; then
            for folder in $folders_to_delete; do
                rm -rf $folder
            done
        fi
    fi
}

start_diagpartner() {
    _clean_unknown_tmp_mdlog
    if [ -f "${MDLOG_BIN}" ]; then
        ${MDLOG_BIN} -v -s ${DIAG_PORT} -c 8 -o ${DIAG_OUTPUT_PATH} -f ${DIAG_TMP_PATH} -e NULL &
    fi
}

stop_diagpartner() {
    local rsp=

    if [ -f "${MDLOG_BIN}" ]; then
        rsp=$(${MDLOG_BIN} stop)
        _LOG "${rsp}"
    fi
}

# restart diag-partner and handle the diag logs rotation
toggle_diagpartner() {
    local running_cnt=$(pgrep -a "diag-partner" | wc -l)
    #clear ouput path while reached to size limit
    if [ -d ${DIAG_OUTPUT_PATH} ]; then
        _clean_output_mdlog
    fi

    [ ${running_cnt} -gt 0 ] && stop_diagpartner

    [ ${running_cnt} -eq 0 ] && start_diagpartner
}

tcpdump_log() {
    sh /opt/5g_iot/util/tcpdump.sh 2>&1 &

}

save_router_info() {
    local log_path="/tmp/log/log_5g_router_info.txt"
    if [ ! -f "$log_path" ]; then
        touch "$log_path"
    fi
    local res=$(http_req GET "${API_MODEM_STATUS}")
    local operation_mode=$(echo "$res" | jq -r '.data.operation_mode')
    local lte_rsrp=$(echo "$res" | jq -r '.data.lte_info.rsrp')
    local nr_rsrp=$(echo "$res" | jq -r '.data.nr_info.rsrp')
    echo "$(date +"%Y-%m-%d %H:%M:%S")" > "$log_path"
    echo "Operation Mode: $operation_mode" >> "$log_path"
    echo "LTE RSRP: $lte_rsrp" >> "$log_path"
    echo "NR RSRP: $nr_rsrp" >> "$log_path"
}

syn_time() {
    local res=$(http_req GET "${API_Sys_info}")
    local systime=$(echo "$res" | jq -r '.data.system_time')
    local CCG_current_version=$(echo "$res" | jq -r '.data.moxa_firmware_version')
    current_sub_version=$(echo "$CCG_current_version" | cut -c4-6)
    if [ "$(echo "$current_sub_version >= $CCG_version" | bc)" -eq 1 ]; then
       
        converted_date=$(date -d "$systime" "+%Y-%m-%d %H:%M:%S")
        sudo timedatectl set-time "$converted_date"
    fi
  
    
   
}

API_Log_Export_get() {
    local API_LOG_EXPORT_DIR="/tmp/log"
    curl -X GET -H "Cookie:token=$API_TOKEN" ${API_Log_Export} -k -o ${API_LOG_EXPORT_DIR}/router_even_log.tar.gz
}

check_ip_reachable(){
 ping -c 1 $CCG_LAN_IP >/dev/null
}
while ! check_ip_reachable;do
	echo "Target IP is unreachable"
	sleep 5
done

main() {
    local prev_sim_status prev_modem_status prev_conn_status
    local cur_sim_status sim_status_rc cur_modem_status modem_status_rc cur_conn_status conn_status_rc 
    local max_serarch_cnt serarching_cnt
    local hour_counter=0
    local HOUR_INTERVAL=360  # 360*10s = 1 hour
    
    max_serarch_cnt=$((${MONITOR_SERARCHING_TIMEOUT}/${MONITOR_INTERVAL}))
    gen_token
    prev_sim_status=$(check_sim_status)
    prev_modem_status=$(check_modem_status)
    prev_conn_status=$(check_conn_status)

    while true; do
        prev_sim_status=${cur_sim_status}
        prev_modem_status=${cur_modem_status}
        prev_conn_status=${cur_conn_status}
        save_router_info
        #if [ $hour_counter -eq $HOUR_INTERVAL ]; then
        syn_time
          #hour_counter=0  # Reset the hour counter
        #fi
        logout
        sleep ${MONITOR_INTERVAL}
        #hour_counter=$((hour_counter+1))
        gen_token
        cur_sim_status=$(check_sim_status)
        sim_status_rc=$?

        # sim status changed
        if [ x"${prev_sim_status}" != x"${cur_sim_status}" ]; then
            if [ x"${sim_status_rc}" = x"1" ]; then
                _LOG "\"lost SIM\" to restart diag-parnter"
                toggle_diagpartner
                continue
            fi
        fi

        if [ x"${sim_status_rc}" = x"0" ]; then
            cur_modem_status=$(check_modem_status)
            modem_status_rc=$?
            cur_conn_status=$(check_conn_status)
            conn_status_rc=$?
            serarching_cnt=0
            # modem status changed
            if [ x"${prev_modem_status}" != x"${cur_modem_status}" ]; then
                if [ x"${modem_status_rc}" = x"1" ]; then
                    [ x"${cur_modem_status}" = x"Not Registered Searching" ] && serarching_cnt=$((serarching_cnt+1))

                    _LOG "\"unknown detach\" to restart diag-parnter"
                    toggle_diagpartner
                    continue
                fi
            else
                [ x"${cur_modem_status}" = x"Not Registered Searching" ] && serarching_cnt=$((serarching_cnt+1))
                if [ ${serarching_cnt} = ${max_serarch_cnt} ]; then
                    _LOG "searching failure" to restart diag-parnter
                    toggle_diagpartner
                    serarching_cnt=0
                    continue
                fi
            fi

            # connection status changed
            if [ x"${prev_conn_status}" != x"${cur_conn_status}" ]; then
                if [ x"${conn_status_rc}" = x"1" ]; then
                    _LOG "\"lost connection\" to restart diag-parnter"
                    API_Log_Export_get
                    tcpdump_log
                    toggle_diagpartner
                    continue
                fi
            fi
        fi
    done
}

# restart diag-partner
trap logout EXIT SIGTERM

gen_token

# checking diag-partner enabled.
check_diagpartner_sender_enabled

logout

main

import os
import sqlite3


def os_exec(str_cmd):   
    str_resp = os.popen(str_cmd).read()
    return str_resp
source_serial_port=""
serial_port =""
BAUD_RATES = [115200, 19200, 9600, 600, 300, 200]  

conn = sqlite3.connect('/opt/5g_iot/web/sqlite/5giot.db')

cur = conn.cursor()
cur.execute("SELECT * FROM deviceinfo")

try:
    rows = cur.fetchall() 
    for row in rows:
            for j in row:
                if j == "/dev/ttyM0":  
                    serial_port = "/dev/ttyM0"
                    source_serial_port="COM1"
                    continue
                elif j == "/dev/ttyM1":  
                    serial_port = "/dev/ttyM1"
                    source_serial_port="COM2"
                    continue
                
                if serial_port != "":
                    if j == "RS-422":
                        os_exec(f'sudo mx-interface-mgmt serialport {source_serial_port} set_interface RS-422')
                        serial_port =""
                        continue
                    elif j == "RS-485":
                        os_exec(f'sudo mx-interface-mgmt serialport {source_serial_port} set_interface RS-485')
                        serial_port =""
                        continue
                    elif j == "RS-232":
                        os_exec(f'sudo mx-interface-mgmt serialport {source_serial_port} set_interface RS-232')
                        serial_port =""
                        continue
                    elif j == "8":
                        os_exec(f'sudo stty cs8 -F {serial_port}')
                        continue
                    elif j == "7":
                        os_exec(f'sudo stty cs7 -F {serial_port}')
                        continue
                    elif j == "1":
                        os_exec(f'sudo stty -cstopb -F {serial_port}')
                        continue
                    elif j == "2":
                        os_exec(f'sudo stty cstopb -F {serial_port}')
                        continue
                    elif j == "None":
                        os_exec(f'sudo stty -parenb -F {serial_port}')
                        
                        continue
                    elif j == "Even":
                        os_exec(f'sudo stty parenb -F {serial_port}')
                        os_exec(f'sudo stty -parodd -F {serial_port}')
                       
                        continue
                    elif j == "Odd":
                        os_exec(f'sudo stty parenb -F {serial_port}')
                        os_exec(f'sudo stty parodd -F {serial_port}')
                       
                        continue


                    for baud_rate in BAUD_RATES:
                        if  j == str(baud_rate):
                            os_exec(f'sudo stty {baud_rate} -F {serial_port}')
                            break
                    
except FileNotFoundError:
    print("File not found.")
finally:
    conn.close()
    os_exec(f'/opt/5g_iot/util/examplea')
##os_exec('sudo systemctl stop setting_serial_port')

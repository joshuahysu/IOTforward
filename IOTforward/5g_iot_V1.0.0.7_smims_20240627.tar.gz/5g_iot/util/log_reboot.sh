#!/bin/bash
LOG_FILE="/opt/5g_iot/log/reboot_log_$(date +'%Y-%m-%d').txt"
echo "System rebooted at: $(date +'%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"

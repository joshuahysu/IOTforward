#!/usr/bin/python3
# History:
#   2022/11/28 v1.0.0:
#   2022/12/29 v1.1.0:
#     1. Output serial port connected/disconnected information to separate event file.
#     2. Output serial port status to separate log file.
#   2023/08/01 v1.2.0:
#     新增: 支援 rfc2217
#     新增: 支援設備未回應時重送 9999.99 給 mqtt
#     新增: 設備未回應時傳送 svid:227 value=0, 有點位值時 svid:227 value=1
#   2023/08/15 v1.3.0:
#     新增: 支援uri "tcp://ip:port" 開啟遠端 serial port
#   2023/09/18 v1.3.1:
#     修改: rx 超過 2 秒沒收到封包就發出 227 斷線通知
#     修改: tx 發出命令後要等待解出封包並且大於等於cfg設定的時間才發出下一筆命令
#     修改: rx 收到不能作數值轉換的字串, 將回傳值設為 9999.99
# ---------------
import os
import socket
import time
import binascii
import paho.mqtt.client as mqtt
import json
import serial

# ---------------
str_version = 'v1.3.1,2023/09/18'
str_ver_filename = 'KSY_SDE_SDT_SDX_SDH_version.csv'
event_tmp_buffer = []
# ---------------


class uart_tcp():
    def __init__(self, str_uri):
        if not str_uri.startswith('tcp://'):
            raise OSError('illegal scheme string')
        self.port = str_uri
        str_uri = str_uri.lstrip('tcp://')
        list_uri = str_uri.split(':')
        socket.inet_aton(list_uri[0])
        list_uri[1] = int(list_uri[1])
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.connect(tuple(list_uri[:2]))
        self.s.setblocking(False)

    def write(self, data):
        self.s.send(data)

    def read_all(self):
        try:
            return self.s.recv(1436)
        except BlockingIOError:
            return b''

    def close(self):
        self.s.close()

# ---------------


def os_exec(str_cmd):
    print('$ ' + str_cmd)
    str_resp = os.popen(str_cmd).read()
    return str_resp


def get_str_time():
    list_tmp = list(time.localtime(time.time()))[:6]
    return '%04d/%02d/%02d_%02d:%02d:%02d' % tuple(list_tmp[:6])


def get_str_time_format_event():
    list_tmp = list(time.localtime(time.time()))[:6]
    return '%04d-%02d-%02d %02d:%02d:%02d' % tuple(list_tmp[:6])


def get_str_date():
    list_tmp = list(time.localtime(time.time()))[:3]
    return '%04d%02d%02d' % tuple(list_tmp[:3])


def get_timestamp_ms():
    return int(time.time()*1000)


def print_log(str_msg):
    global str_log_path
    # print(str_msg)
    try:
        fp = open('%slog_KSY_SDE_SDT_SDX_SDH_%s.txt' %
                  (str_log_path, get_str_date()), 'a')
        fp.write(str_msg + '\n')
        fp.close()
    except:
        pass


def print_device_log(str_device, str_msg):
    global str_log_path
    # print(str_msg)
    try:
        fp = open('%slog_%s_%s.txt' % (str_log_path,
                  str_device.split(os.sep)[-1], get_str_date()), 'a')
        fp.write(str_msg + '\n')
        fp.close()
    except:
        pass


def print_device_event_tmp_data(str_device, str_msg):
    global event_tmp_buffer
    str_log_path_tmp = '/tmp/log/log_dpm_data_' + \
        str_device.split(os.sep)[-1]+'.txt'
    str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)

    event_tmp_buffer.append(str_tmp)

    if len(event_tmp_buffer) >= 10:
        try:
            with open(str_log_path_tmp, "w", encoding="utf-8") as fp:

                fp.writelines(event_tmp_buffer)

            event_tmp_buffer = []
        except Exception as e:
            print(f"Error: {e}")


def print_device_event_tmp(str_device, str_msg):
    str_log_path_tmp = '/tmp/log/log_dpm_'+str_device.split(os.sep)[-1]+'.txt'
    str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)
    try:
        with open(str_log_path_tmp, "w", encoding="utf-8") as fp:
            fp.write(str_tmp)

    except:
        pass


def print_device_event(str_device, str_msg):
    global str_log_path
    str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)
    # print(str_tmp, end='')
    try:
        fp = open('%slogfile_%s_%s.csv' % (str_log_path,
                  str_device.split(os.sep)[-1], get_str_date()), 'a')
        fp.write(str_tmp)
        fp.close()
    except:
        pass

# ---------------


dict_data_map = {
    'A': ['DPMotorCurrent', 'MBPMotorCurrent', 'DPCaseTemperature', 'TC1Temperature', 'MBP2MotorCurrent', 'AnalogInputVoltage', 'DPBackPressure', 'DPCoolingWater', 'TC2Temperature', 'N2Purge', 'DP_MDR_OCL_count', 'DP_MDR_OCT_count', 'TC3Temperature'],
    # 缺原廠datasheet比對
    'a': ['DPMotorCurrent', 'MBPMotorCurrent', 'DPCaseTemperature', 'TC1Temperature', 'DPBackPressure', 'DPCoolingWater', 'N2Purge'],
    'X': ['DPCoolingWater', 'N2Purge', 'DPBackPressure', 'DPCaseTemperature', 'TC1Temperature', 'DPMotorCurrent', 'DPSpeed', 'MBPMotorCurrent', 'MBSpeed', 'MBP2MotorCurrent', 'MB2Speed', 'DP_MDR_OCL_count', 'DP_MDR_OCT_count', 'AnalogInputVoltage', 'TC2Temperature', 'TC3Temperature', 'DPPower', 'MBPower', 'MB2Power', 'HeaterATemperature', 'HeaterBTemperature', 'HeaterCTemp', 'HeaterDTemperature', '23', '24'],
    'K': ['RunningTime'],
    'k': ['RunningTime']
}

dict_data_size = {'X': 4, 'K': 6, 'k': 6, 'A': 3, 'a': 3,
                  'B': 1, 'C': 1, 'D': 1, 'E': 3, 'F': 3, 'G': 1, 'P': [11, 10]}

dict_tx_cmd = {
    'A': b'\x02A43*\r',
    'a': b'\x02a63*\r',
    'X': b'\x02X5A*\r',
    'K': b'\x02K49*\r',
    'k': b'\x02k69*\r'
}

# ---------------
if __name__ == '__main__':
    try:
        str_ver_path = os.environ['PATH_5GIOT_VER']
        if not str_ver_path.endswith(os.sep):
            str_ver_path += os.sep
    except:
        str_ver_path = ''

    try:
        str_cfg_path = os.environ['PATH_5GIOT_CFG']
        if not str_cfg_path.endswith(os.sep):
            str_cfg_path += os.sep
    except:
        str_cfg_path = ''

    try:
        str_log_path = os.environ['PATH_5GIOT_LOG']
        if not str_log_path.endswith(os.sep):
            str_log_path += os.sep
    except:
        str_log_path = ''

    # ---------------
    try:
        with open(str_ver_path + str_ver_filename, 'w') as fp:
            fp.write(str_version)
            fp.flush()
    except:
        pass

    # ---------------
    time.sleep(2)

    while True:
        # ----- Load cfg -----
        print_log('%s: Load cfg' % (get_str_time()))
        try:
            fp = open(str_cfg_path + 'KSY_SDE_SDT_SDX_SDH.cfg', 'r')
        except:
            time.sleep(30)
            continue

        while True:
            str_line = fp.readline()
            if len(str_line) == 0:
                break
            str_line = str_line.replace('\r', '').replace('\n', '').lstrip()
            while True:
                i = str_line.find('#')
                if i < 0:
                    break
                str_line = str_line[:i]
            str_line = str_line.rstrip()
            if len(str_line) > 0:
                list_tmp = str_line.split(',')
                for i in range(len(list_tmp)):
                    list_tmp[i] = list_tmp[i].lstrip().rstrip()
                break
        fp.close()

        try:
            str_mqtt_topic = list_tmp.pop(0)
            str_mqtt_ip = list_tmp.pop(0)
            socket.inet_aton(str_mqtt_ip)
            int_mqtt_port = int(list_tmp.pop(0))
            str_mqtt_user = list_tmp.pop(0)
            str_mqtt_password = list_tmp.pop(0)
            int_cmd_period_ms = int(list_tmp.pop(0))

            mqtt_client = mqtt.Client()
            mqtt_client.username_pw_set(str_mqtt_user, str_mqtt_password)
            mqtt_client.connect(str_mqtt_ip, int_mqtt_port, 30)
        except:
            time.sleep(30)
            continue
        break

    print_log('%s: MQTT Server connected.' % (get_str_time()))

    # ----- Load csv -----
    print_log('%s: Load csv' % (get_str_time()))
    list_csv = []
    try:
        fp = open(str_cfg_path + 'KSY_SDE_SDT_SDX_SDH.csv', 'r')
        while fp:
            str_line = fp.readline()
            if len(str_line) == 0:
                break
            str_line = str_line.replace('\r', '').replace('\n', '').lstrip()
            while True:
                i = str_line.find('#')
                if i < 0:
                    break
                str_line = str_line[:i]
            str_line = str_line.rstrip()
            if len(str_line) > 0:
                list_tmp = str_line.split(',')
                for i in range(len(list_tmp)):
                    list_tmp[i] = list_tmp[i].lstrip().rstrip()

                if list_tmp[2] == '8':
                    list_tmp[2] = serial.EIGHTBITS
                elif list_tmp[2] == '7':
                    list_tmp[2] = serial.SEVENBITS
                elif list_tmp[2] == '6':
                    list_tmp[2] = serial.SIXBITS
                elif list_tmp[2] == '5':
                    list_tmp[2] = serial.FIVEBITS
                else:
                    list_tmp.clear()

                if list_tmp[3] == '1':
                    list_tmp[3] = serial.STOPBITS_ONE
                elif list_tmp[3] == '1.5':
                    list_tmp[3] = serial.STOPBITS_ONE_POINT_FIVE
                elif list_tmp[3] == '2':
                    list_tmp[3] = serial.STOPBITS_TWO
                else:
                    list_tmp.clear()

                if list_tmp[4] == 'none':
                    list_tmp[4] = serial.PARITY_NONE
                elif list_tmp[4] == 'even':
                    list_tmp[4] = serial.PARITY_EVEN
                elif list_tmp[4] == 'odd':
                    list_tmp[4] = serial.PARITY_ODD
                else:
                    list_tmp.clear()

                dict_param_name = {}
                for item in list_tmp[7:]:
                    str_param_name, str_svid_param = item.split('=')
                    str_param_name = str_param_name.lstrip().rstrip()
                    str_svid_param = str_svid_param.lstrip().rstrip()
                    for i in range(0, len(list_tmp[5])):
                        if str_param_name in dict_data_map[list_tmp[5][i]] and str_svid_param != 'zzz':
                            if str_param_name in dict_param_name:
                                dict_param_name[str_param_name].append(
                                    str_svid_param)
                            else:
                                dict_param_name[str_param_name] = [
                                    str_svid_param]
                            break
                str_id = list_tmp[6]
                list_tmp = list_tmp[:6]
                list_tmp.append(str_id)
                list_tmp.append(dict_param_name)

                list_csv.append(list_tmp)
    except:
        os_exec('rm /etc/systemd/system/5giot_dpm_ksy_sde_sdt_sdx_sdh.service')
        os_exec('systemctl  stop 5giot_dpm_ksy_sde_sdt_sdx_sdh.service')
        pass

    # --------------------
    list_tmp = list_csv
    list_csv = []
    while len(list_tmp) > 0:
        try:
            item = list_tmp.pop(0)
            if item[0].startswith('rfc2217://'):
                uart = serial.serial_for_url(item[0], timeout=2)
                uart.baudrate = item[1]
                uart.bytesize = item[2]
                uart.stopbits = item[3]
                uart.parity = item[4]
            elif item[0].startswith('tcp://'):
                uart = uart_tcp(item[0])
            else:
                uart = serial.Serial(
                    port=item[0], baudrate=item[1], bytesize=item[2], stopbits=item[3], parity=item[4], timeout=2)
            # print_log('%s: Serial Port Open: %s' % (get_str_time(), uart.port))
            # print_device_log(uart.port, '%s: %s opened' % (get_str_time(), uart.port))
            list_csv.append([uart] + item[5:] + [0, 0, 0, b'', False])
        except:
            print_log('%s: %s open failure' % (get_str_time(), item[0]))
            print_device_log(item[0], '%s: opene failure' % get_str_time())

    del list_tmp
    # --------------------

# item =
# [uart,                                                           [0]
# 'AK',                                                            [1]
# '1300104',                                                       [2]
# {'RunningTime': ['011'], 'DPCaseTemperature': ['027', '066']},   [3]
# 0,    item[1] pointer                                            [4]
# 0,    tx_timestamp                                               [5]
# 0,    rx_timestamp (解出封包的時間)                              [6]
# b'',  rx_buffer                                                  [7]
# False]  connection                                               [8]

    while len(list_csv) > 0:
        # Write command to uart
        for item in list_csv:
            if not item[8] and get_timestamp_ms() - item[5] > 20000:
                item[4] = 0
                item[6] = item[5]
            if get_timestamp_ms() - item[5] >= int_cmd_period_ms and item[5] <= item[6]:
                tx_cmd = dict_tx_cmd[item[1][item[4]]]
                item[0].write(tx_cmd)

                item[5] = get_timestamp_ms()
                # print_log('%s: %s <- %s' % (get_str_time(), item[0].port, binascii.hexlify(tx_cmd).decode('ascii').upper()))
                # print_device_log(item[0].port, '%s: %s <- %s' % (get_str_time(), item[0].port, binascii.hexlify(tx_cmd).decode('ascii').upper()))
                print_device_event_tmp_data(item[0].port, '%s: %s <- %s' % (
                    get_str_time(), item[0].port, binascii.hexlify(tx_cmd).decode('ascii').upper()))
                time.sleep(int_cmd_period_ms/50000)
        # Read packet from uart
        time.sleep(int_cmd_period_ms/10000)
        for item in list_csv:
            try:
                packet = item[0].read_all()
                if len(packet) > 0:
                    item[7] += packet
                    # print_log('%s: %s -> %s' % (get_str_time(), item[0].port, binascii.hexlify(packet).decode('ascii').upper()))
                    # print_device_log(item[0].port, '%s: %s -> %s' % (get_str_time(), item[0].port, binascii.hexlify(packet).decode('ascii').upper()))
                    print_device_event_tmp_data(item[0].port, '%s: %s -> %s' % (
                        get_str_time(), item[0].port, binascii.hexlify(packet).decode('ascii').upper()))
            except:
                pass

        # 檢查是否長時間沒收到封包, 超過2秒發出 227 斷線
        for item in list_csv:
            if item[8] and get_timestamp_ms() - item[6] > 20000:
                item[8] = False
                item[7] = b''
                item[4] = 0
                # print_device_event(item[0].port, 'disconnected')
                print_device_event_tmp(item[0].port, 'disconnected')
                str_tmp = json.dumps({'227': 0})
                result = mqtt_client.publish(str_mqtt_topic+item[2], str_tmp)
                # print_log('%s: MQTT <- %s %s' % (get_str_time(), str_mqtt_topic+item[2], str_tmp))
                # print_device_log(item[0].port, '%s: MQTT <- %s %s' % (get_str_time(), str_mqtt_topic+item[2], str_tmp))
                if result.rc != mqtt.MQTT_ERR_SUCCESS:
                    # 如果發布失敗，重新連結 MQTT 客戶端
                    mqtt_client.reconnect()
        # Decode packet
        for item in list_csv:
            i = (item[7]).find(b'\x02')  # 找出封包起始點
            if i > 0:
                item[7] = item[7][i:]     # 去除起始點之前的資料
            i = item[7].find(b'*\r')
            if i >= 8:  # 收到封包結尾, 開始解封包, 發佈 MQTT 資料
                packet = item[7][:i]     # 取出封包解碼
                item[7] = item[7][i+2:]  # 從 buffer 移除封包
                fcs = 0
                for ch in packet[:-2]:
                    fcs ^= ch
                fcs = binascii.hexlify(fcs.to_bytes(1, 'big')).upper()
                if packet[-2:] == fcs and packet[1:2] == b'\x06':
                    str_cmd = packet[2:3].decode('ascii')
                    list_function = dict_data_map[str_cmd]
                    data_size = dict_data_size[str_cmd]
                    dict_mqtt = {}
                    for i in range(len(list_function)):
                        j = 3 + i*data_size
                        if list_function[i] in item[3]:
                            try:
                                value = int(
                                    packet[j:j+data_size].decode('ascii'))
                                for str_svid in item[3][list_function[i]]:
                                    dict_mqtt[str_svid] = value
                            except:
                                for str_svid in item[3][list_function[i]]:
                                    dict_mqtt[str_svid] = 9999.99
                    if not item[8]:
                        item[8] = True
                        dict_mqtt['227'] = 1
                        # print_device_event(item[0].port, 'connected')
                        print_device_event_tmp(item[0].port, 'connected')
                    dict_mqtt['227'] = 1
                    str_tmp = json.dumps(dict_mqtt)
                    result = mqtt_client.publish(
                        str_mqtt_topic+item[2], str_tmp)
                    # print_log('%s: MQTT <- %s %s' % (get_str_time(), str_mqtt_topic+item[2], str_tmp))
                    # print_device_log(item[0].port, '%s: MQTT <- %s %s' % (get_str_time(), str_mqtt_topic+item[2], str_tmp))
                    if result.rc != mqtt.MQTT_ERR_SUCCESS:
                        # 如果發布失敗，重新連結 MQTT 客戶端
                        mqtt_client.reconnect()
                    item[6] = get_timestamp_ms()
                    item[4] += 1
                    if item[4] >= len(item[1]):
                        item[4] = 0
            elif i > 0:  # 移除不明封包
                item[7] = item[7][i+2:]

        time.sleep(0.001)

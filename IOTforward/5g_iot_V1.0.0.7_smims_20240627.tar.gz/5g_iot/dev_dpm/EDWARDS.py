#!/usr/bin/python3
# History:
#   2022/11/28 v1.0.0:
#   2022/12/29 v1.1.0:
#     1. Output serial port connected/disconnected information to separate event file.
#     2. Output serial port status to separate log file.
#   2023/08/01 v1.2.0:
#     新增: 支援 rfc2217
#     新增: 支援設備未回應時重送 9999.99 給 mqtt
#     新增: 設備未回應時傳送 svid:227 value=0, 有點位值時 svid:227 value=1
#   2023/08/15 v1.3.0:
#     新增: 支援uri "tcp://ip:port" 開啟遠端 serial port
#   2023/09/14 v1.3.1:
#     修改: rx 超過 2 秒沒收到封包就發出 227 斷線通知
#     修改: tx 發出命令後要等待解出封包並且大於等於cfg設定的時間才發出下一筆命令
#     修改: rx 收到不能作數值轉換的字串, 將回傳值設為 9999.99
#   2023/06/26 v1.3.2:
#     修正: for 迴圈前面漏加 list_tmp = list(item[2].keys())
#---------------
import os,socket,time,binascii
import paho.mqtt.client as mqtt
import json
import serial

#---------------
str_version = 'v1.3.2,2023/06/26'
str_ver_filename = 'EDWARDS_version.csv'

#---------------
class uart_tcp():
	def __init__(self, str_uri):
		if not str_uri.startswith('tcp://'):
			raise OSError('illegal scheme string')
		self.port = str_uri
		str_uri = str_uri.lstrip('tcp://')
		list_uri = str_uri.split(':')
		socket.inet_aton(list_uri[0])
		list_uri[1] = int(list_uri[1])
		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.s.connect(tuple(list_uri[:2]))
		self.s.setblocking(False)

	def write(self, data):
		self.s.send(data)

	def read_all(self):
		try:
			return self.s.recv(1436)
		except BlockingIOError:
			return b''

	def close(self):
		self.s.close()

#---------------

def get_str_time():
	list_tmp = list(time.localtime(time.time()))[:6]
	return '%04d/%02d/%02d_%02d:%02d:%02d' % tuple(list_tmp[:6])

def get_str_time_format_event():
	list_tmp = list(time.localtime(time.time()))[:6]
	return '%04d-%02d-%02d %02d:%02d:%02d' % tuple(list_tmp[:6])

def get_str_date():
	list_tmp = list(time.localtime(time.time()))[:3]
	return '%04d%02d%02d' % tuple(list_tmp[:3])

def get_timestamp_ms():
	return int(time.time()*1000)

def print_log(str_msg):
	global str_log_path
	#print(str_msg)
	try:
		fp = open('%slog_EDWARDS_%s.txt' % (str_log_path, get_str_date()), 'a')
		fp.write(str_msg + '\n')
		fp.close()
	except:
		pass

def print_device_log(str_device, str_msg):
	global str_log_path
	#print(str_msg)
	try:
		fp = open('%slog_%s_%s.txt' % (str_log_path, str_device.split(os.sep)[-1], get_str_date()), 'a')
		fp.write(str_msg + '\n')
		fp.close()
	except:
		pass

def print_device_event(str_device, str_msg):
	global str_log_path
	str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)
	#print(str_tmp, end='')
	try:
		fp = open('%slogfile_%s_%s.csv' % (str_log_path, str_device.split(os.sep)[-1], get_str_date()), 'a')
		fp.write(str_tmp)
		fp.close()
	except:
		pass

#---------------

dict_tx_cmd = {
	'V1':b'?V1\r',
	'V2':b'?V2\r',
	'V3':b'?V3\r',
	'V4':b'?V4\r',
	'V5':b'?V5\r',
	'V6':b'?V6\r',
	'V7':b'?V7\r',
	'V8':b'?V8\r',
	'V9':b'?V9\r',
	'V10':b'?V10\r',
	'V11':b'?V11\r',
	'V12':b'?V12\r',
	'V13':b'?V13\r',
	'V14':b'?V14\r',
	'V16':b'?V16\r',
	'V18':b'?V18\r',
	'V20':b'?V20\r',
	'V21':b'?V21\r',
	'V31':b'?V31\r',
	'V32':b'?V32\r',
	'V34':b'?V34\r',
	'V35':b'?V35\r',
	'V39':b'?V39\r',
	'V40':b'?V40\r',
	'V45':b'?V45\r',
	'V46':b'?V46\r',
	'V47':b'?V47\r',
	'V48':b'?V48\r',
	'V50':b'?V50\r',
	'V51':b'?V51\r',
	'V52':b'?V52\r',
	'V53':b'?V53\r',
	'V54':b'?V54\r',
	'V55':b'?V55\r',
	'V56':b'?V56\r',
	'V57':b'?V57\r',
	'V58':b'?V58\r',
	'V59':b'?V59\r',
	'V60':b'?V60\r',
	'V62':b'?V62\r',
	'V63':b'?V63\r',
	'V67':b'?V67\r',
	'V68':b'?V68\r',
	'V69':b'?V69\r',
	'V70':b'?V70\r',
	'V72':b'?V72\r',
	'V84':b'?V84\r',
	'V85':b'?V85\r',
	'V89':b'?V89\r',
	'V111':b'?V111\r',
	'V116':b'?V116\r',
	'V121':b'?V121\r',
	'V131':b'?V131\r',
	'V140':b'?V140\r',
	'V151':b'?V151\r',
	'V152':b'?V152\r',
	'V153':b'?V153\r',
	'V160':b'?V160\r',
	'V161':b'?V161\r',
	'V169':b'?V169\r',
	'V170':b'?V170\r',
	'V172':b'?V172\r',
	'V173':b'?V173\r',
	'V174':b'?V174\r',
	'V175':b'?V175\r',
	'V176':b'?V176\r',
	'V177':b'?V177\r',
	'V178':b'?V178\r',
	'V180':b'?V180\r',
	'V183':b'?V183\r',
	'V184':b'?V184\r',
	'V185':b'?V185\r',
	'V187':b'?V187\r',
	'V188':b'?V188\r',
	'V211':b'?V211\r',
	'V212':b'?V212\r',
	'V213':b'?V213\r',
	'V214':b'?V214\r',
	'V215':b'?V215\r',
	'V216':b'?V216\r',
	'V217':b'?V217\r',
	'V219':b'?V219\r',
	'V222':b'?V222\r',
	'V223':b'?V223\r',
	'V224':b'?V224\r',
	'V226':b'?V226\r',
	'V227':b'?V227\r',
	'V228':b'?V228\r',
	'V230':b'?V230\r',
	'V231':b'?V231\r',
	'V233':b'?V233\r',
	'V234':b'?V234\r',
	'V235':b'?V235\r',
	'V236':b'?V236\r',
	'V237':b'?V237\r',
	'V239':b'?V239\r',
	'V240':b'?V240\r',
	'V241':b'?V241\r',
	'V242':b'?V242\r',
	'V245':b'?V245\r',
	'V246':b'?V246\r',
	'V801':b'?V801\r',
	'V807':b'?V807\r',
	'V812':b'?V812\r',
	'V813':b'?V813\r',
	'V814':b'?V814\r',
	'V816':b'?V816\r',
	'V817':b'?V817\r',
	'V819':b'?V819\r',
	'V820':b'?V820\r',
	'V821':b'?V821\r',
	'V822':b'?V822\r',
	'V823':b'?V823\r',
	'V824':b'?V824\r',
	'V826':b'?V826\r',
	'V827':b'?V827\r',
	'V829':b'?V829\r',
	'V835':b'?V835\r',
	'V836':b'?V836\r',
	'V837':b'?V837\r',
	'V838':b'?V838\r',
	'V839':b'?V839\r',
	'V840':b'?V840\r',
	'V841':b'?V841\r',
	'V842':b'?V842\r',
	'V843':b'?V843\r',
	'V872':b'?V872\r',
	'V873':b'?V873\r',
	'V874':b'?V874\r',
	'V875':b'?V875\r',
	'V876':b'?V876\r',
	'V877':b'?V877\r',
	'V878':b'?V878\r',
	'V879':b'?V879\r',
	'V880':b'?V880\r',
	'V881':b'?V881\r',
	'V883':b'?V883\r',
	'V884':b'?V884\r',
	'V885':b'?V885\r',
	'V886':b'?V886\r',
	'V887':b'?V887\r',
	'V888':b'?V888\r'
}

#---------------
if __name__ == '__main__':
	try:
		str_ver_path = os.environ['PATH_5GIOT_VER']
		if not str_ver_path.endswith(os.sep):
			str_ver_path += os.sep
	except:
		str_ver_path = ''

	try:
		str_cfg_path = os.environ['PATH_5GIOT_CFG']
		if not str_cfg_path.endswith(os.sep):
			str_cfg_path += os.sep
	except:
		str_cfg_path = ''

	try:
		str_log_path = os.environ['PATH_5GIOT_LOG']
		if not str_log_path.endswith(os.sep):
			str_log_path += os.sep
	except:
		str_log_path = ''

	#---------------
	try:
		with open(str_ver_path + str_ver_filename, 'w') as fp:
			fp.write(str_version)
			fp.flush()
	except:
		pass

	#---------------
	time.sleep(2)

	while True:
		#----- Load cfg -----
		print_log('%s: Load cfg' % (get_str_time()))
		try:
			fp = open(str_cfg_path + 'EDWARDS.cfg', 'r')
		except:
			time.sleep(30)
			continue

		while True:
			str_line = fp.readline()
			if len(str_line) == 0:
				break
			str_line = str_line.replace('\r','').replace('\n','').lstrip()
			while True:
				i = str_line.find('#')
				if i < 0:
					break
				str_line = str_line[:i]
			str_line = str_line.rstrip()
			if len(str_line) > 0:
				list_tmp = str_line.split(',')
				for i in range(len(list_tmp)):
					list_tmp[i] = list_tmp[i].lstrip().rstrip()
				break
		fp.close()

		try:
			str_mqtt_topic = list_tmp.pop(0)
			str_mqtt_ip = list_tmp.pop(0)
			socket.inet_aton(str_mqtt_ip)
			int_mqtt_port = int(list_tmp.pop(0))
			str_mqtt_user = list_tmp.pop(0)
			str_mqtt_password = list_tmp.pop(0)
			int_cmd_period_ms = int(list_tmp.pop(0))

			mqtt_client = mqtt.Client()
			mqtt_client.username_pw_set(str_mqtt_user, str_mqtt_password)
			mqtt_client.connect(str_mqtt_ip, int_mqtt_port, 30)
		except:
			time.sleep(30)
			continue
		break

	print_log('%s: MQTT Server connected.' % (get_str_time()))

	#----- Load csv -----
	print_log('%s: Load csv' % (get_str_time()))
	list_csv = []
	try:
		fp = open(str_cfg_path + 'EDWARDS.csv', 'r')
		while fp:
			str_line = fp.readline()
			if len(str_line) == 0:
				break
			str_line = str_line.replace('\r','').replace('\n','').lstrip()
			while True:
				i = str_line.find('#')
				if i < 0:
					break
				str_line = str_line[:i]
			str_line = str_line.rstrip()
			if len(str_line) > 0:
				list_tmp = str_line.split(',')
				for i in range(len(list_tmp)):
					list_tmp[i] = list_tmp[i].lstrip().rstrip()

				if list_tmp[2] == '8':
					list_tmp[2] = serial.EIGHTBITS
				elif list_tmp[2] == '7':
					list_tmp[2] = serial.SEVENBITS
				elif list_tmp[2] == '6':
					list_tmp[2] = serial.SIXBITS
				elif list_tmp[2] == '5':
					list_tmp[2] = serial.FIVEBITS
				else:
					list_tmp.clear()

				if list_tmp[3] == '1':
					list_tmp[3] = serial.STOPBITS_ONE
				elif list_tmp[3] == '1.5':
					list_tmp[3] = serial.STOPBITS_ONE_POINT_FIVE
				elif list_tmp[3] == '2':
					list_tmp[3] = serial.STOPBITS_TWO
				else:
					list_tmp.clear()

				if list_tmp[4] == 'none':
					list_tmp[4] = serial.PARITY_NONE
				elif list_tmp[4] == 'even':
					list_tmp[4] = serial.PARITY_EVEN
				elif list_tmp[4] == 'odd':
					list_tmp[4] = serial.PARITY_ODD
				else:
					list_tmp.clear()

				dict_param_name = {}
				for item in list_tmp[6:]:
					str_param_name, str_svid_param = item.split('=')
					str_param_name = str_param_name.lstrip().rstrip()
					str_svid_param = str_svid_param.lstrip().rstrip()
					if str_param_name in dict_tx_cmd:
						if str_param_name in dict_param_name:
							dict_param_name[str_param_name].append(str_svid_param)
						else:
							dict_param_name[str_param_name] = [str_svid_param]
				list_tmp = list_tmp[:6]
				list_tmp.append(dict_param_name)

				list_csv.append(list_tmp)
	except:
		pass

	#--------------------

	list_tmp = list_csv
	list_csv = []
	while len(list_tmp) > 0:
		try:
			item = list_tmp.pop(0)
			if item[0].startswith('rfc2217://'):
				uart = serial.serial_for_url(item[0], timeout=2)
				uart.baudrate = item[1]
				uart.bytesize = item[2]
				uart.stopbits = item[3]
				uart.parity = item[4]
			elif item[0].startswith('tcp://'):
				uart = uart_tcp(item[0])
			else:
				uart = serial.Serial(port=item[0],baudrate=item[1],bytesize=item[2],stopbits=item[3],parity=item[4], timeout=2)
			print_log('%s: Serial Port Open: %s' % (get_str_time(), uart.port))
			print_device_log(uart.port, '%s: %s opened' % (get_str_time(), uart.port))
			list_csv.append([uart] + item[5:] + [0, 0, 0, b'', False, 0])
		except:
			print_log('%s: %s open failure' % (get_str_time(), item[0]))
			print_device_log(item[0], '%s: opene failure' % get_str_time())

# [uart,                                      [0]
# '1200001',                                  [1]
# {'V14': ['011'], 'V55': ['066', '166']},    [2]
# 0,      command_pointer                     [3]
# 0,      tx_timestamp                        [4]
# 0,      rx_timestamp (解出封包的時間)       [5]
# b'',    rx_buffer                           [6]
# False,  connection                          [7]

	#--------------------
	while len(list_csv) > 0:
		# Write command to uart
		for item in list_csv:
			if not item[7] and get_timestamp_ms() - item[4] > 2000:
				item[3] = 0
				item[5] = item[4]
			if get_timestamp_ms() - item[4] >= int_cmd_period_ms and item[4] <= item[5]:
				list_tmp = list(item[2].keys())
				tx_cmd = dict_tx_cmd[list_tmp[item[3]]]
				item[0].write(tx_cmd)
				item[4] = get_timestamp_ms()
				print_log('%s: %s <- %s' % (get_str_time(), item[0].port, binascii.hexlify(tx_cmd).decode('ascii').upper()))
				print_device_log(item[0].port, '%s: %s <- %s' % (get_str_time(), item[0].port, binascii.hexlify(tx_cmd).decode('ascii').upper()))

		# Read packet from uart
		for item in list_csv:
			try:
				packet = item[0].read_all()
				if len(packet) > 0:
					item[6] += packet
					print_log('%s: %s -> %s' % (get_str_time(), item[0].port, binascii.hexlify(packet).decode('ascii').upper()))
					print_device_log(item[0].port, '%s: %s -> %s' % (get_str_time(), item[0].port, binascii.hexlify(packet).decode('ascii').upper()))
			except:
				pass

		# 檢查是否長時間沒收到封包, 超過2秒發出 227 斷線
		for item in list_csv:
			if item[7] and get_timestamp_ms() - item[5] > 2000:
				item[6] = b''     # 清空 rx_buffer
				item[3] = 0       # command pointer
				item[7] = False
				print_device_event(item[0].port, 'disconnected')
				str_tmp = json.dumps({'227':0})
				mqtt_client.publish(str_mqtt_topic+item[1], str_tmp)
				print_log('%s: MQTT <- %s %s' % (get_str_time(), str_mqtt_topic+item[1], str_tmp))
				print_device_log(item[0].port, '%s: MQTT <- %s %s' % (get_str_time(), str_mqtt_topic+item[1], str_tmp))

		# Decode packet
		for item in list_csv:
			i = (item[6]).find(b'\r\n')  # 找出封包結尾
			if i >= 0:
				packet = item[6][:i]   # 從rx buffer取出封包
				item[6] = item[6][i+2:]  # 從rx buffer移除這次要解的封包
				i = packet.find(b',')  # 判斷是 Short Reply 或 Long Reply
				if i >= 0:
					packet = packet[:i]

				i = packet.find(b'.')
				try:
					value = float(packet) if i >= 0 else int(packet)
				except ValueError:
					value = 9999.99
				dict_mqtt = {}
				list_tmp = list(item[2].keys())
				str_param_name = list_tmp[item[3]]
				for str_svid in item[2][str_param_name]:
					dict_mqtt[str_svid] = value
				if item[7] == False:
					item[7] = True
					dict_mqtt['227'] = 1
					print_device_event(item[0].port, 'connected')
				str_tmp = json.dumps(dict_mqtt)
				mqtt_client.publish(str_mqtt_topic+item[1], str_tmp)
				print_log('%s: MQTT <- %s %s' % (get_str_time(), str_mqtt_topic+item[1], str_tmp))
				print_device_log(item[0].port, '%s: MQTT <- %s %s' % (get_str_time(), str_mqtt_topic+item[1], str_tmp))

				item[5] = get_timestamp_ms()  # 記錄解出封包的時間

				item[3] += 1  # 換下一個命令
				if item[3] >= len(list(item[2].keys())):
					item[3] = 0

		time.sleep(0.001)

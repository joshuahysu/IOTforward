#!/usr/bin/python3
# -*- coding: utf-8 -*
# ---------------
# History:
#   2024/05/21 v3.0.0:
#     改用 MULTIPLE MEMORY AREA READ 一次讀取所有點位
# ---------------
import json
import os
import socket
import binascii
import time
import struct
import paho.mqtt.client as mqtt
# ---------------
str_version = 'v3.0.0,2024/05/21'
str_ver_filename = 'fins2mqtt_version.csv'
event_tmp_buffer = []
# ---------------


class fins_dev():
    def __init__(self, ip_addr):
        self._ICF = b'\x80'  # Information control field
        self._RSV = b'\x00'  # Reserved. Set to 00
        self._GCT = b'\x02'  # Gateway count. Set to 02.
        self._DNA = b'\x00'  # Destination network address  (00: Local network)
        # self._DA1 = b'\x00'  # Destination node number
        self._DA2 = b'\x00'  # Destination unit address  (00: PC (CPU))
        self._SNA = b'\x00'  # Source network address  (00: Local network)
        # self._SA1 = b'\x00'  # Source node number
        self._SA2 = b'\x00'  # Source unit address  (00: PC (CPU))
        self._SID = b'\x00'  # Service ID

        self._dict_MEM_AREA = {'D': b'\x82', 'H': b'\xB2', 'A': b'\x80'}

        self._DA1 = struct.pack('>B', int(ip_addr[0].split('.')[3]))
        self.ip_addr = ip_addr
        self.socket_inst = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket_inst.setblocking(False)
        self.socket_inst.connect(ip_addr)
        str_local_ip = self.socket_inst.getsockname()[0]
        self._SA1 = struct.pack('>B', int(str_local_ip.split('.')[3]))

    def cmd_mem_area_read(self, str_mem_addr, number_of_items=1):
        try:
            i = 1 if str_mem_addr[1].isdigit() else 2
            mem_area_code = self._dict_MEM_AREA[str_mem_addr[:i]]
            mem_addr = int(str_mem_addr[i:])
        except:
            return b''
        if mem_addr > 65535:
            return b''
        fins_header = self._ICF + self._RSV + self._GCT + self._DNA + \
            self._DA1 + self._DA2 + self._SNA + self._SA1 + self._SA2 + self._SID
        fins_command = b'\x01\x01'
        try:
            fins_packet = fins_header + fins_command + mem_area_code + \
                struct.pack('>H', mem_addr) + b'\x00' + \
                struct.pack('>H', number_of_items)
            self.socket_inst.send(fins_packet)
        except ConnectionRefusedError:
            return b''
        return fins_packet

    def cmd_multiple_mem_area_read(self, list_mem_addr):
        fins_header = self._ICF + self._RSV + self._GCT + self._DNA + \
            self._DA1 + self._DA2 + self._SNA + self._SA1 + self._SA2 + self._SID
        fins_command = b'\x01\x04'
        fins_packet = fins_header + fins_command
        for str_mem_addr in list_mem_addr:
            try:
                i = 1 if str_mem_addr[1].isdigit() else 2
                mem_area_code = self._dict_MEM_AREA[str_mem_addr[:i]]
                mem_addr = int(str_mem_addr[i:])
            except:
                return b''
            if mem_addr > 65535:
                return b''
            fins_packet += (mem_area_code +
                            struct.pack('>H', mem_addr) + b'\x00')
        try:
            self.socket_inst.send(fins_packet)
        except ConnectionRefusedError:
            return b''
        return fins_packet

    def get_response(self):
        try:
            return self.socket_inst.recv(8192)
        except:
            return b''

    def decode_response_packet(self, eth_packet):
        if len(eth_packet) < 16:
            return []
        if eth_packet[:3] != b'\xC0\x00\x02' or eth_packet[3:9] != (self._SNA+self._SA1+self._SA2+self._DNA+self._DA1+self._DA2):
            return []
        if (struct.unpack('>B', eth_packet[12:13])[0] & 0x7f) != 0:
            return []
        if (struct.unpack('>B', eth_packet[13:14])[0] & 0x3f) != 0:
            return []
        list_resp = []
        if eth_packet[10:12] == b'\x01\x01':
            for i in range(14, len(eth_packet), 2):
                list_resp.append(eth_packet[i:i+2])
        elif eth_packet[10:12] == b'\x01\x04':
            for i in range(15, len(eth_packet), 3):
                list_resp.append(eth_packet[i:i+2])
        return list_resp
# ---------------


def get_timestamp_ms():
    return int(time.time()*1000)


def get_str_time():
    list_tmp = list(time.localtime(time.time()))[:6]
    return '%04d/%02d/%02d_%02d:%02d:%02d' % tuple(list_tmp[:6])


def get_str_time_format_event():
    list_tmp = list(time.localtime(time.time()))[:6]
    return '%04d-%02d-%02d %02d:%02d:%02d' % tuple(list_tmp[:6])


def get_str_date():
    list_tmp = list(time.localtime(time.time()))[:3]
    return '%04d%02d%02d' % tuple(list_tmp[:3])


def print_log(str_msg):
    global str_log_path
    # print(str_msg)
    try:
        fp = open('%slog_fins2mqtt_%s.txt' %
                  (str_log_path, get_str_date()), 'a')
        fp.write(str_msg + '\n')
        fp.close()
    except:
        pass


def os_exec(str_cmd):
    print('$ ' + str_cmd)
    str_resp = os.popen(str_cmd).read()
    return str_resp


def print_device_event(ip_addr, str_msg):
    global str_log_path
    str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)
    # print(str_tmp, end='')
    try:
        fp = open('%slogfile_%s_%s.csv' %
                  (str_log_path, '%s:%s' % ip_addr, get_str_date()), 'a')
        fp.write(str_tmp)
        fp.close()
    except:
        pass


def print_device_event_tmp_data(str_device, str_msg):
    global event_tmp_buffer
    str_device = str_device.replace("(", "").replace(")", "").replace(
        "'", "").replace(",", "_").replace(" ", "")
    str_device = str_device.replace("_", "_")
    str_log_path_tmp = '/tmp/log/log_fins_data_' + str_device + '.txt'
    str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)

    event_tmp_buffer.append(str_tmp)

    if len(event_tmp_buffer) >= 10:
        try:
            with open(str_log_path_tmp, "w", encoding="utf-8") as fp:

                fp.writelines(event_tmp_buffer)

            event_tmp_buffer = []
        except Exception as e:
            print(f"Error: {e}")


def print_device_event_tmp(str_device, str_msg):
    str_device = str_device.replace("(", "").replace(")", "").replace(
        "'", "").replace(",", "_").replace(" ", "")
    str_device = str_device.replace("_", "_")
    str_log_path_tmp = '/tmp/log/log_fins_'+str_device+'.txt'
    str_tmp = '%s,%s\n' % (get_str_time_format_event(), str_msg)
    try:
        with open(str_log_path_tmp, "w", encoding="utf-8") as fp:
            fp.write(str_tmp)

    except:
        pass


def print_device_log(ip_addr, str_msg):
    global str_log_path
    # print(str_msg)
    try:
        fp = open('%slog_%s_%s.txt' % (str_log_path, '%s:%s' %
                  ip_addr, get_str_date()), 'a')
        fp.write(str_msg + '\n')
        fp.close()
    except:
        pass


# ---------------
if __name__ == '__main__':
    try:
        str_ver_path = os.environ['PATH_5GIOT_VER']
        if not str_ver_path.endswith(os.sep):
            str_ver_path += os.sep
    except:
        str_ver_path = ''

    try:
        str_cfg_path = os.environ['PATH_5GIOT_CFG']
        if not str_cfg_path.endswith(os.sep):
            str_cfg_path += os.sep
    except:
        str_cfg_path = ''

    try:
        str_log_path = os.environ['PATH_5GIOT_LOG']
        if not str_log_path.endswith(os.sep):
            str_log_path += os.sep
    except:
        str_log_path = ''

    # ---------------
    try:
        fp = open(str_ver_path + str_ver_filename, 'w')
        fp.write(str_version)
        fp.close()
    except:
        pass

    time.sleep(2)

    # ----- Load cfg -----
    print_log('%s: Load cfg' % (get_str_time()))
    try:
        fp = open(str_cfg_path + 'fins2mqtt.cfg', 'r')
    except:
        exit()

    while True:
        str_line = fp.readline()
        if len(str_line) == 0:
            break
        str_line = str_line.replace('\r', '').replace('\n', '').lstrip()
        while True:
            i = str_line.find('#')
            if i < 0:
                break
            str_line = str_line[:i]
        str_line = str_line.rstrip()
        if len(str_line) > 0:
            list_tmp = str_line.split(',')
            for i in range(len(list_tmp)):
                list_tmp[i] = list_tmp[i].lstrip().rstrip()
            break
    fp.close()

    try:
        str_mqtt_topic = list_tmp.pop(0)
        str_mqtt_ip = list_tmp.pop(0)
        socket.inet_aton(str_mqtt_ip)
        int_mqtt_port = int(list_tmp.pop(0))
        str_mqtt_user = list_tmp.pop(0)
        str_mqtt_password = list_tmp.pop(0)
        int_cmd_period_ms = int(list_tmp.pop(0))

        mqtt_client = mqtt.Client()
        mqtt_client.username_pw_set(str_mqtt_user, str_mqtt_password)
        mqtt_client.connect(str_mqtt_ip, int_mqtt_port, 30)
    except:
        exit()

    print_log('%s: MQTT Server connected.' % (get_str_time()))

    # ----- Load csv -----
    try:
        fp = open(str_cfg_path + 'fins2mqtt.csv', 'r')
    except:
        os_exec('rm /etc/systemd/system/5giot_fins2mqtt.service')
        os_exec('systemctl  stop 5giot_fins2mqtt.service')
        exit()

    list_fins_csv_mapping = ['plc_ip', 'plc_port',
                             'fins_dest_node', 'big_endian', 'mqtt_topic']
    list_csv = []
    while True:
        str_line = fp.readline()
        if len(str_line) == 0:
            break
        str_line = str_line.replace('\r', '').replace('\n', '').lstrip()
        i = str_line.find('#')  # 找到註解
        if i >= 0:
            str_line = str_line[:i]  # 去掉註解
        str_line = str_line.rstrip()
        list_tmp = str_line.split(',')  # 分拆參數
        for i in range(len(list_tmp)):
            list_tmp[i] = list_tmp[i].lstrip().rstrip()  # 去掉參數前後的空白
        # ----------------------------------
        dict_csv = {}
        if len(list_tmp) > 0 and len(list_tmp[0]) > 0:
            for i in range(len(list_fins_csv_mapping)):
                dict_csv[list_fins_csv_mapping[i]] = list_tmp[i]
            for str_tmp in dict_csv.keys():
                if str_tmp == 'plc_port' or str_tmp == 'fins_dest_node' or str_tmp == 'big_endian':
                    dict_csv[str_tmp] = int(dict_csv[str_tmp])
            list_tmp = list_tmp[len(list_fins_csv_mapping):]
            dict_csv['parameter'] = {}
            for i in range(len(list_tmp)):
                str_param_name, str_svid_param = list_tmp[i].split('=', 1)
                str_param_name = str_param_name.lstrip().rstrip()  # 去掉參數前後的空白
                str_svid_param = str_svid_param.lstrip().rstrip()  # 去掉參數前後的空白
                if str_param_name in dict_csv['parameter']:
                    if type(dict_csv['parameter'][str_param_name]) == list:
                        dict_csv['parameter'][str_param_name].append(
                            str_svid_param)
                    else:
                        dict_csv['parameter'][str_param_name] = [
                            dict_csv['parameter'][str_param_name], str_svid_param]
                else:
                    dict_csv['parameter'][str_param_name] = str_svid_param
            dict_csv['rx_buffer'] = b''
            dict_csv['svid_mapping'] = {}
            dict_csv['svid_type'] = {}
            dict_csv['bitmask'] = {}
            for str_tmp in list(dict_csv['parameter'].keys()):
                str_dictkey = str_tmp
                str_type = ''
                if str_tmp.startswith('f'):
                    str_type = 'f'
                    str_tmp = str_tmp[1:].lstrip()
                elif str_tmp.startswith('s'):
                    str_type = 's'
                    str_tmp = str_tmp[1:].lstrip()

                if str_tmp.startswith('(') and str_tmp.endswith(')'):
                    list_tmp = str_tmp[1:-1].split('+')
                    for i in range(len(list_tmp)):
                        list_tmp[i] = list_tmp[i].lstrip().rstrip()
                    if len(list_tmp) > 0:
                        dict_csv['svid_mapping'][dict_csv['parameter']
                                                 [str_dictkey]] = list_tmp
                        dict_csv['svid_type'][dict_csv['parameter']
                                              [str_dictkey]] = str_type
                elif str_tmp.startswith('D') or str_tmp.startswith('H') or str_tmp.startswith('A'):
                    i = str_tmp.find('[')
                    j = str_tmp.find(':')
                    k = str_tmp.find(']')
                    list_tmp = []
                    if str_tmp.endswith(']') and i > 0:
                        str_tmp = dict_csv['parameter'].pop(str_dictkey)
                        if str_dictkey[:i] in dict_csv['parameter']:
                            if type(dict_csv['parameter'][str_dictkey[:i]]) == list:
                                dict_csv['parameter'][str_dictkey[:i]].append(
                                    str_tmp)
                            else:
                                dict_csv['parameter'][str_dictkey[:i]] = [
                                    dict_csv['parameter'][str_dictkey[:i]], str_tmp]
                        else:
                            dict_csv['parameter'][str_dictkey[:i]] = str_tmp
                        str_svid_param = str_tmp
                        str_tmp = str_dictkey[:i]
                        try:
                            if j > 0 and j > i + 1 and k > j + 1:
                                list_tmp = [
                                    int(str_dictkey[i+1:j]), int(str_dictkey[j+1:k])]
                                if list_tmp[0] < 0 or list_tmp[1] < 0:
                                    list_tmp.clear()
                            elif j < 0:
                                list_tmp = [int(str_dictkey[i+1:k])]
                                if list_tmp[0] < 0:
                                    list_tmp.clear()
                        except ValueError:
                            pass
                    try:
                        int(str_tmp[1:])
                        if len(list_tmp) > 0:
                            dict_csv['bitmask'][str_svid_param] = list_tmp
                        if type(dict_csv['parameter'][str_tmp]) == list:
                            for str_svid_param in dict_csv['parameter'][str_tmp]:
                                dict_csv['svid_mapping'][str_svid_param] = [
                                    str_tmp]
                                dict_csv['svid_type'][str_svid_param] = str_type
                        else:
                            dict_csv['svid_mapping'][dict_csv['parameter'][str_tmp]] = [
                                str_tmp]
                            dict_csv['svid_type'][dict_csv['parameter']
                                                  [str_tmp]] = str_type
                    except ValueError:
                        pass
                dict_csv['list_cmd'] = sum(
                    dict_csv['svid_mapping'].values(), [])
        # ----------------------------------
        if len(dict_csv) > 0:
            dict_csv['tx_time'] = 0
            dict_csv['rx_time'] = 0
            dict_csv['connection'] = False
            dict_csv['publish_data'] = {}
            list_csv.append(dict_csv)

    print_log('%s: Load csv' % (get_str_time()))

    # ----- Initial device -----
    for item in list_csv:
        item['device'] = fins_dev((item['plc_ip'], item['plc_port']))
        if item['fins_dest_node'] > 0:
            item['device']._DA1 = struct.pack('>B', item['fins_dest_node'])

    # ----- Read device data -----
    while len(list_csv) > 0:
        for item in list_csv:
            if 'device' not in item:
                continue

            if get_timestamp_ms() - item['tx_time'] >= int_cmd_period_ms and item['tx_time'] <= item['rx_time']:
                packet = item['device'].cmd_multiple_mem_area_read(
                    item['list_cmd'])
                item['tx_time'] = get_timestamp_ms()
                item['rx_buffer'] = b''
                str_tmp = '%s: %s:%d <- %s' % (get_str_time(
                ), item['plc_ip'], item['plc_port'], binascii.hexlify(packet).decode('ascii').upper())
                # print_log(str_tmp)
                # print_device_log(item['device'].ip_addr, str_tmp)
                print_device_event_tmp_data(
                    str(item['device'].ip_addr), str_tmp)
                time.sleep(int_cmd_period_ms/50000)
            # Read packet from plc
            packet = item['device'].get_response()
            time.sleep(int_cmd_period_ms/10000)
            if len(packet) > 0:
                item['rx_buffer'] = packet
                str_tmp = '%s: %s:%d -> %s' % (get_str_time(
                ), item['plc_ip'], item['plc_port'], binascii.hexlify(packet).decode('ascii').upper())
                # print_log(str_tmp)
                # print_device_log(item['device'].ip_addr, str_tmp)
                print_device_event_tmp_data(
                    str(item['device'].ip_addr), str_tmp)
                # Decode packet
                list_resp = item['device'].decode_response_packet(
                    item['rx_buffer'])
                if len(list_resp) > 0:
                    for str_svid_param in item['svid_mapping']:
                        str_type = item['svid_type'][str_svid_param]
                        list_tmp = []
                        for str_tmp in item['svid_mapping'][str_svid_param]:
                            list_tmp.append(
                                list_resp[item['list_cmd'].index(str_tmp)])
                        tmp = b''
                        for i in range(len(list_tmp)) if item['big_endian'] > 0 else range(len(list_tmp)-1, -1, -1):
                            tmp += list_tmp[i]
                        value = None
                        i = len(tmp)
                        if str_type == 'f':
                            if i == 4:
                                value = struct.unpack('>f', tmp)[0]
                            elif i == 8:
                                value = struct.unpack('>d', tmp)[0]
                        elif str_type == 's':
                            if i == 2:
                                value = struct.unpack('>h', tmp)[0]
                            elif i == 4:
                                value = struct.unpack('>i', tmp)[0]
                            elif i == 8:
                                value = struct.unpack('>q', tmp)[0]
                        else:
                            if i == 2:
                                value = struct.unpack('>H', tmp)[0]
                            elif i == 4:
                                value = struct.unpack('>I', tmp)[0]
                            elif i == 8:
                                value = struct.unpack('>Q', tmp)[0]
                        if value != None:
                            if str_svid_param in item['bitmask']:
                                list_tmp = item['bitmask'][str_svid_param]
                                if len(list_tmp) > 1:
                                    j = list_tmp[1]
                                else:
                                    j = list_tmp[0]
                                value >>= j
                                i = 15 - list_tmp[0] + j
                                value &= (0xffff >> i)
                            item['publish_data'][str_svid_param] = value

                    if len(item['publish_data']) > 0:
                        if not item['connection']:
                            item['connection'] = True
                            # print_device_event(
                            # item['device'].ip_addr, 'connected')
                            print_device_event_tmp(
                                str(item['device'].ip_addr), 'connected')
                        item['publish_data']['227'] = 1
                        item['rx_time'] = get_timestamp_ms()
                        str_tmp = json.dumps(item['publish_data'])
                        result = mqtt_client.publish(
                            str_mqtt_topic+item['mqtt_topic'], str_tmp)  # 發佈 mqtt
                       # print_log('%s: MQTT <- %s' % (get_str_time(), str_tmp))
                        # print_device_log(
                        # item['device'].ip_addr, '%s: MQTT <- %s' % (get_str_time(), str_tmp))
                        if result.rc != mqtt.MQTT_ERR_SUCCESS:
                            # 如果發布失敗，重新連結 MQTT 客戶端
                            mqtt_client.reconnect()
                        item['publish_data'].clear()

            if not item['connection'] and get_timestamp_ms() - item['tx_time'] > 5000:
                item['rx_time'] = item['tx_time']
                str_tmp = json.dumps({'227': 0})
                result = mqtt_client.publish(
                    str_mqtt_topic+item['mqtt_topic'], str_tmp)  # 發佈 mqtt
                # print_log('%s: MQTT <- %s' % (get_str_time(), str_tmp))
                # print_device_log(
                # item['device'].ip_addr, '%s: MQTT <- %s' % (get_str_time(), str_tmp))
                if result.rc != mqtt.MQTT_ERR_SUCCESS:
                    # 如果發布失敗，重新連結 MQTT 客戶端
                    mqtt_client.reconnect()
            # 檢查是否長時間沒收到封包, 超過5秒發出 227 斷線
            if item['connection'] and get_timestamp_ms() - item['rx_time'] > 5000:
                item['connection'] = False
                # print_device_event(item['device'].ip_addr, 'disconnected')
                print_device_event_tmp(
                    str(item['device'].ip_addr), 'disconnected')
        time.sleep(0.001)

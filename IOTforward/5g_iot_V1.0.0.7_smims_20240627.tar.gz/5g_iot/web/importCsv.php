<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>單一 PHP 檔案上傳 - 封装成 function</title>
</head>
<body>
     
<form action="/php/importCsv.php" method="post" enctype="multipart/form-data">
    <!-- 限制上傳檔案的最大值 -->
    <input type="hidden" name="MAX_FILE_SIZE" value="2097152">
 
    <!-- accept 限制上傳檔案類型 -->
    <input type="file" name="myFile" accept=".csv,.xls">
 
    <input type="submit" value="上傳檔案">
</form> 
</body>
</html>
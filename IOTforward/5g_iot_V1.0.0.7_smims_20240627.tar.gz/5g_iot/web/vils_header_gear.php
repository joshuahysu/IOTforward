

<!-- Main Header -->
<header class="main-header">


  <!-- Header Navbar -->
  <nav class="navbar navbar-static-top" role="navigation">
    <!-- Sidebar toggle button-->
    <!-- <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
      <span class="sr-only">Toggle navigation</span>
    </a> -->
    <!-- <a href="#" class="sidebar-toggle" role="button">
      <span class="sr-only">Toggle navigation</span>
    </a> -->

    <!-- Logo -->
    <!-- <?php
        echo "<span>";
        echo "  <img src='/images/". $main_logo_small_file ."' class='img_logo' alt='5G IOT Logo' id='logo'>";
        echo "</span>";
    ?> -->

    <!-- Navbar Right Menu -->
    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">

        <!-- Notifications: style can be found in dropdown.less -->
        <li onclick="full_csv_export();">
          <a href="#">
            <i id="full_export"  >儲存設定檔</i>
          </a>
        </li>
        <li onclick="full_csv_export_reboot();">
          <a href="#">
            <i id="full_export_reboot"  >儲存後重啟</i>
          </a>
        </li>
        <!-- logout -->
         <li>
           <a href="/logout.php">
             <i class="fa fa-sign-out" id="curUserName"></i>
           </a>
         </li>

        <!-- Control Sidebar Toggle Button -->
         <?php if($show_gear_button)
         {
             echo '<li>';
             echo '<a href="#control-sidebar-settings-tab" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>';
             echo '</li>';
         }
         ?>

      </ul>
    </div>

  </nav>
  <div class="loading-overlay" id="loadingOverlay">
  <div class="loading-spinner"></div>
</div>
</header>

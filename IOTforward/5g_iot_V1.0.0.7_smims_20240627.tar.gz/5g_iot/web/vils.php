<?php
include('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">
<?php
include('vils_html_head.php');
echo '<body class="hold-transition skin-blue sidebar-mini">';
?>

<div class="wrapper">

  <?php
  $show_gear_button = false;
  include('vils_header_gear.php');
  include('left_side_bar.php');
  ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <section class="content" style="margin:0; padding:10; border:0 none;">
      <div class="row">
        <!-- Left col -->
        <div class="col-md-12 col-sm-12" id="main_left_frame">
          <iframe id="contentIframe" src="" onLoad="" style="width:100%; height:85vh; margin:0; padding:0; border:0 none;"></iframe>
        </div>
        <!-- /.Left col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


  <!-- Main Footer -->
  <footer class="main-footer" style="padding-bottom:30px;">
    <!-- To the right -->
    <div class="pull-left hidden-xs">
      &nbsp;系統時間: <span id="system_time"></span>
    </div>

    <div class="pull-left hidden-xs">
      &nbsp;CPU: <span id="system_cpu"></span>
    </div>

    <div class="pull-left hidden-xs">
      &nbsp;RAM: <span id="system_ram"></span>
    </div>

    <div class="pull-left hidden-xs">
      &nbsp;ver. <?php echo $web_version ?>
    </div>

    <!-- Default to the left -->
    <div>
      <strong><?php echo $main_copyright_name ?></strong> <?php echo $main_copyright ?>
    </div>
  </footer>

</div>
<!-- ./wrapper -->

<script>
  var accountid = "<?php echo $_SESSION["accountid"] ?>";
  var accountname = "<?php echo $_SESSION["accountname"] ?>";

  var type = "<?php echo $_SESSION["type"] ?>";
  var userid = "<?php echo $_SESSION["userid"] ?>";
</script>

<script src="/js/global.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/vils_src/00-vils.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<!-- <script src="/js/vils.min.js?date=<?php echo $UPDATE_DATE; ?>"></script> -->

<!-- <script src="/js/vils_src/00-vils.js?date=<?php echo $UPDATE_DATE; ?>"></script>
  <script src="/js/vils_src/01-checkeventfired.js?date=<?php echo $UPDATE_DATE; ?>"></script> -->

</body>

</html>
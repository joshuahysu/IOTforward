<?php
include ('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
    <link href="/css/vils.min.css" rel="stylesheet">
    <link href="/css/main.css" rel="stylesheet">
    <title></title>

    <style>

        .form-control {
            border-radius: 5px;
        }

        select {
            border-radius: 5px;
            width: 100px;
            margin-left: 5px;
        }

        input[type=text] {
            border-color: #AAA;
        }

        .devrow {
            margin: 10px;
        }

        .devrow input[type=text] {
            text-align: right;
        }


    </style>

  </head>

        <div class="row" id="section_group_edit" style="display:block;">
          <div class="col-md-12">
            <!-- Event Settings -->
            <div class="box" id="section_group_edit_box">
              <div class="box-header with-border">
                <h3 class="box-title"><?php echo "環境設定";?></h3>
                <input type="button" value="存檔" onclick="update_config();return false;" />
                <input type="button" value="啟動服務" onclick="system_start();return false;" />
                <input type="button" value="停止服務" onclick="system_stop();return false;" />
                <input type="button" value="SIM check ON" onclick="SIM_check_on();return false;" />
                <input type="button" value="SIM check OFF" onclick="SIM_check_off();return false;" />
                <input type="button" value="Simulator ON" onclick="Simulator_on();return false;" />
                <input type="button" value="Simulator OFF" onclick="Simulator_off();return false;" />
                <input type="button" value="StartTcpdump" onclick="StartTcpdump();return false;" />
                <input type="button" value="Sudo Reboot" onclick="SudoReboot();return false;" />
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                    <div class="row c_box">
                      <h4 class="c_header">Local</h4>
                      <div class="col-md-12">
                          <div class="row">
                              <div class="col-md-4">
                                  <label>Local IP</label>
                                  <input type="text" class="form-control" id="ui_localip" />
                              </div>
                              <div class="col-md-4">
                                  <label>Local Mask</label>
                                  <input type="text" class="form-control" id="ui_localmask" />
                              </div>
                              <div class="col-md-4">
                                  <label>Gateway</label>
                                  <input type="text" class="form-control" id="ui_localgateway" />
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="row c_box">
                      <h4 class="c_header">SECS/GEM INFO</h4>
                      <div class="col-md-12">
                          <div class="row">
                              <div class="col-md-4">
                                  <label>IP [本機IP位置]</label>
                                  <input type="text" class="form-control" id="ui_ip" />
                              </div>
                              <div class="col-md-4">
                                  <label>FDC Port</label>
                                  <input type="text" class="form-control" id="ui_fdcport" />
                              </div>
                              <div class="col-md-4">
                                  <label>FAC Port</label>
                                  <input type="text" class="form-control" id="ui_itport" />
                              </div>
                              <div class="col-md-4">
                                  <label>MDLN</label>
                                  <input type="text" class="form-control" id="ui_mdln" />
                              </div>
                              <div class="col-md-4">
                                  <label>Session ID</label>
                                  <input type="text" class="form-control" id="ui_sessionid" />
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="row c_box">
                      <h4 class='c_header'>MQTT設定</h4>
                      <div class="col-md-12">
                          <div class="row">
                              <div class="col-md-4">
                                  <label>MQTTAddress</label>
                                  <input type="text" class="form-control" id="ui_mqttaddr" />
                              </div>
                              <div class="col-md-4">
                                  <label>MQTTport</label>
                                  <input type="text" class="form-control" id="ui_mqttport" />
                              </div>
                              <div class="col-md-4">
                                  <label>MQTTUser</label>
                                  <input type="text" class="form-control" id="ui_mqttuser" />
                              </div>
                              <div class="col-md-4">
                                  <label>MQTTPassword</label>
                                  <input type="text" class="form-control" id="ui_mqttpwd" />
                              </div>
                              <div class="col-md-4">
                                  <label>MQTTPrefix</label>
                                  <input type="text" class="form-control" id="ui_mqttprefix" />
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="row c_box">
                      <div class="col-md-12 c_box" >
                          <h5 class='c_header'>設備收發時間(ms)</h5>
                          <div class="row devrow">
                              <div class="col-md-3" style="text-align:right;">
                                  <label>EBARA 預設值1000</label>
                              </div>
                              <div class="col-md-9">
                                  <input type="text" class="form-control" id="ui_ebara" />
                              </div>
                          </div>
                          <div class="row devrow">
                              <div class="col-md-3" style="text-align:right;">
                                  <label>EDWARDS 預設值500</label>
                              </div>
                              <div class="col-md-9">
                                  <input type="text" class="form-control" id="ui_edwards" />
                              </div>
                          </div>
                          <div class="row devrow">
                              <div class="col-md-3" style="text-align:right;">
                                  <label>KSY_MU_TS 預設值1000</label>
                              </div>
                              <div class="col-md-9">
                                  <input type="text" class="form-control" id="ui_ksy_mu_ts" />
                              </div>
                          </div>
                          <div class="row devrow">
                              <div class="col-md-3" style="text-align:right;">
                                  <label>KSY_SDE_SDT_SDX_SDH 預設值1000</label>
                              </div>
                              <div class="col-md-9">
                                  <input type="text" class="form-control" id="ui_ksy_sde_sdt_sdx_sdh" />
                              </div>
                          </div>
                          <div class="row devrow">
                              <div class="col-md-3" style="text-align:right;">
                                  <label>Fins 預設值1000</label>
                              </div>
                              <div class="col-md-9">
                                  <input type="text" class="form-control" id="ui_fins" />
                              </div>
                          </div>
                      </div>
                      <div class="col-md-12 c_box">
                          <div class="row">
                              <div class="col-md-3">
                                  <label>APN KEY</label>
                                  <input type="text" id="ui_factory" />
                              </div>
                              <div class="col-md-3">
                                  <label>廠區DPMID</label>
                                  <input type="text" id="ui_dpmids" />
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <!-- /.box-body -->

            </div>
            <!-- /.box-->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

    <script>
        var project_id = <?php echo $project_id ?>;
        var accountid = "<?php echo $_SESSION["accountid"] ?>";
        var accountname = "<?php echo $_SESSION["accountname"] ?>";
        var groupid = "<?php echo $_SESSION["groupid"] ?>";
    </script>

    <script src="/js/global.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
    <script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
    <script src="/js/config_src/00-config.js?date=<?php echo $UPDATE_DATE;?>"></script>

</html>

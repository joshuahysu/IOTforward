// 點擊按鈕時下載csv
const btn = document.getElementById('export_devsvid_csv');
btn.addEventListener('click', () => {
try {
    DownLoad_Svid_Param_Map("loaddevsviddata=1","AllDevsvid"); 
} catch(err) {
    window.alert(err)
} 
})

// 點擊按鈕時下載csv
document.getElementById('export_devsvid_csv_new').addEventListener('click', () => {
try {
    DownLoad_Svid_Param_Map("loaddevsviddata_new=1","AllDevsvid_new"); 
} catch(err) {
    window.alert(err)
} 
})

function DownLoad_Svid_Param_Map($function,$fileName)
{
    let val = $("#ui_dev").val();
    let targetURL = gl_target_server + '/php/systemImport.php';

    let p = $.getJSON(targetURL, $function + val, data => {})
        .success((data) => {
        let exportDatas=[];
        console.log(data);
        let name="";
        $.each(data, (index, item) => {
        if(index!="def"){
        name=index;
        //console.log(index);
    }
    })
        //console.log(data);
      $.each(data, (index, item) => {
        //newItem客製自訂格式
        //console.log(item);
        let newItem={
          id:(item['id'] !== null) ? item['id'].toString() : "",
          uid:(item['uid'] !== null) ? item['uid'].toString() : "",
          class:item['class']||"",
          parameterid:item['parameterid']||"",
          remark:item['remark']||"",
          category:item['category']||"",
          tagname:item['tagname']||"",
          serveraddress:item['serveraddress']||"",
          serverfunctioncode:item['serverfunctioncode']||"",
          address:item['address']||"",
          startbit:item['startbit']||"",
          endbit:item['endbit']||"",
          num:item['num']||"",
          readfreq:item['readfreq']||"",
          functioncode:item['functioncode']||"",
          scaletype:item['scaletype']||"",
          scalemultiple:item['scalemultiple']||"",
          scaleoffset:item['scaleoffset']||"",
          unit:item['unit']||"",
          max:(item['max'] !== null) ? item['max'].toString() : "",
          min:(item['min'] !== null) ? item['min'].toString() : "",
          signed:item['signed']||"",
          endian:(item['endian'] !== null) ? item['endian'].toString() : "",
          valuetype:(item['valuetype'] !== null) ? item['valuetype'].toString() : "",
          intnum:(item['intnum'] !== null) ? item['intnum'].toString() : "",
          fixed:item['fixed']||"",
          mergemode:(item['mergemode'] !== null) ? item['mergemode'].toString() : "",
          'private':(item['private'] !== null) ? item['private'].toString() : ""
        }
        //console.log(newItem);
        exportDatas.push(newItem); 
      })

        buildData(exportDatas)
        .then(datas => {downloadCSV(datas,$fileName)
        }       
        )
        .catch(err => window.alert(err));
        }       
        )
        .error(err => {
            console.log(err);
        })
}



  // 當表單送出時執行的函式
  document.getElementById("importLinuxGar").addEventListener("submit", function(event) {
    // 取得進度條元素
    var progressBar = document.getElementById("progressBar");
    
    // 更新進度條的值（這裡示範的是假定表單送出需要一定時間）
    var progress = 0;
    var interval = setInterval(function() {
      progress += 2; // 假定每次增加x%
      progressBar.value = progress;
      
      // 如果進度達到100%，停止更新進度
      if (progress >= 100) {
        clearInterval(interval);
      }
    }, 1000); // 每秒更新一次進度條，你可以根據實際情況調整時間間隔

    // 可以在這裡做其他送出表單後的處理

    // 如果你不想要透過傳統的表單提交方式，也可以使用AJAX來處理表單送出
    // 這樣你就可以在不重新載入頁面的情況下更新進度條
    // 這個範例只是一個簡單的演示，實際上可能需要更多的程式碼來處理表單送出的各種情況
    // 比如驗證輸入、處理回應等等
    //event.preventDefault(); // 阻止表單的預設提交行為
  });

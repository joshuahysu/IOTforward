//account_box_body

var glAccountList = [];
var glFieldSet = [
    { "title": "帳號", "field": "account", "type": "input" },
    { "title": "密碼", "field": "pwd", "type": "pwd" },
    { "title": "確認密碼", "field": "checkpwd", "type": "pwd" },
    { "title": "建立時間", "field": "createtime", "type": "" },
    { "title": "修改時間", "field": "modifytime", "type": "" }
];

Load_AccountData();

function Load_AccountData() {

    let targetURL = gl_target_server + '/php/account.php';
    let p = $.getJSON(targetURL, 'fun=loadaccount', data => {
        glAccountList = data;
    })
        .success(() => {
            CreateAccountTable();
        })
        .error(err => {
            console.log(err);
        })

}

function CreateAccountTable() {
    let tbody = document.getElementById('account_table_body');
    let tr, td, tagi;

    $(tbody).children().remove();
    for (var i = 0; i < glAccountList.length; i++) {

        tr = document.createElement("tr");
        tr.setAttribute("data-key", glAccountList[i].id);
        tbody.appendChild(tr);

        td = document.createElement("td");
        tr.appendChild(td);
        tagi = document.createElement("i");
        tagi.setAttribute("class", "fa fa-trash-o");
        tagi.setAttribute("title", "delete");
        td.appendChild(tagi);

        tagi = document.createElement("i");
        tagi.setAttribute("class", "fa fa-edit");
        tagi.setAttribute("title", "edit")
        td.appendChild(tagi);

        td = document.createElement('td');
        td.textContent = glAccountList[i].userid;
        tr.appendChild(td);

        td = document.createElement("td");
        td.textContent = '·········';
        tr.appendChild(td);

        td = document.createElement('td');
        td.textContent = moment(glAccountList[i].createtime).format("YYYY/MM/DD HH:mm:ss");
        tr.appendChild(td);

        td = document.createElement('td');
        td.textContent = moment(glAccountList[i].modifytime).format("YYYY/MM/DD HH:mm:ss");
        tr.appendChild(td);

    }

}

function SaveData(mode) {

    let msg = '';
    let blnEdit = false;
    switch (mode) {
        case 'add':
            blnEdit = true;
            break;
        case 'edit':
            if (document.getElementById("dialog_edit_pwd").classList.contains('fa-reply'))
                blnEdit = true;
            break;
    }

    if ($("#dialog_id").val() == '' || $("#dialog_pwd").val() == '') {
        msg = '欄位不可空白！';
    } else if (blnEdit && $("#dialog_check_pwd").val() == '') {
        msg = '欄位不可空白！';
    } else if (blnEdit) {
        if ($('#dialog_pwd').val() != $('#dialog_check_pwd').val()) {
            msg = '密碼與確認密碼不符，請重新確定！';
        }
    }

    if (msg != '') {
        alert(msg);
    } else {
        let key = '-1';
        if (mode == 'edit')
            key = $('#dialog').attr('data-key');
        let userid = $('#dialog_id').val();
        let pwd = $('#dialog_pwd').val();

        $.ajax({
            method: "POST",
            dataType: 'json',
            url: gl_target_server + "/php/account.php",
            data: { "fun": "saveaccount", "id": key, "userid": userid, "pwd": pwd },
            success: data => {
                alert('存檔成功！');
                $("#dialog").dialog("close");
                Load_AccountData();
            },
            error: err => {
                alert('存檔失敗！');
                console.log(err);
            }
        })

    }

}

$(document).ready(function () {

    $("#dialog").dialog({
        autoOpen: false,
        resizable: false,
        draggable: false,
        modal: true,
        width: "400px",
        buttons: {
            "存檔": function () {
                let mode = $("#dialog").attr("data-mode");
                SaveData(mode);
            },
            "取消": function () {
                $(this).dialog("close");
            }
        }
    });

    $("#ui_add").click(e => {
        $('#dialog').attr("data-mode", "add");
        $('#dialog_check_pwd').val('');
        $('#dialog_edit_pwd').hide();
        $('#dialog_check_row').show();
        $("#dialog").dialog('open');
    });

    $("#dialog_show_pwd").click(e => {
        let blnShow = e.currentTarget.classList.contains("fa-eye");
        if (blnShow) {
            e.currentTarget.classList.remove("fa-eye");
            e.currentTarget.classList.add("fa-eye-slash");
            $('#dialog_pwd').attr("type", "password");
        } else {
            e.currentTarget.classList.remove("fa-eye-slash");
            e.currentTarget.classList.add("fa-eye");
            $('#dialog_pwd').attr("type", "input");
        }
    });

    $("#dialog_show_check_pwd").click(e => {
        let blnShow = e.currentTarget.classList.contains("fa-eye");
        if (blnShow) {
            e.currentTarget.classList.remove("fa-eye");
            e.currentTarget.classList.add("fa-eye-slash");
            $('#dialog_check_pwd').attr("type", "password");
        } else {
            e.currentTarget.classList.remove("fa-eye-slash");
            e.currentTarget.classList.add("fa-eye");
            $('#dialog_check_pwd').attr("type", "input");
        }
    });

    $("#account_table_body").on("click", ".fa-edit", e => {
        let tr = $(e.currentTarget).closest("tr")[0];
        let key = $(tr).attr("data-key");
        let data = glAccountList.filter(a => {
            return a.id == key;
        });

        if (data.length > 0) {
            data = data[0];
            $("#dialog_id").val(data.userid);
            $("#dialog_pwd").val(data.pwd);
            $('#dialog_check_row').hide();
            $("#dialog_check_pwd").val('');
            $('#dialog_edit_pwd').attr("class", "fa fa-edit").show();
            $("#dialog").attr("data-mode", "edit").attr("data-key", key);
            $("#dialog").dialog("open");
        }

    }).on("click", ".fa-trash-o", e => {

        if (confirm('是否確定刪除？')) {
            let tr = $(e.currentTarget).closest('tr')[0];
            let key = $(tr).attr('data-key');
            $.ajax({
                method: "POST",
                datatype: "json",
                url: gl_target_server + "/php/account.php",
                data: { "fun": "delaccount", "id": key },
                success: data => {
                    alert('刪除成功！');
                    Load_AccountData();
                },
                error: err => {
                    alert('刪除失敗！');
                    console.log(err);
                }
            });

        }

    });

    $('#dialog_edit_pwd').click(e => {
        let blnShow = e.currentTarget.classList.contains("fa-reply");
        if (blnShow) {
            e.currentTarget.classList.remove("fa-reply");
            e.currentTarget.classList.add("fa-edit");
            $('#dialog_check_row').hide();
        } else {
            e.currentTarget.classList.remove("fa-edit");
            e.currentTarget.classList.add("fa-reply");
            $('#dialog_check_row').show();
        }

    });

});

var modifyStatus = '';
var glTargetSelect = null;
var glMapFiles = [];
var glDevSvid = {};
var glFieldSetting = {
    "com": [
        { "title": "", "key": "editButton", "data": [], "type": "input", "field": "editButton", "class": "editButton"},
        { "title": "Name", "key": "name", "data": [], "type": "input", "field": "name", "ishide": "1", "notnull": "1" },
        { "title": "COM Port", "key": "sp", "data": com_ports_map, "type": "select", "field": "slaveport", "class": "info_block_0", "notnull": "1", "framestyle": "width:250px;max-width:250px;min-width:250px;" },
        { "title": "ChamberID", "key": "chamberid", "data": [], "type": "input", "field": "chamberid", "framestyle": "width:150px;max-width:150px;min-width:150px;", "class": "info_block_0", "notnull": "1" },
        { "title": "Host ModbusIP", "key": "serverip", "data": [], "type": "input", "field": "serverip", "class": "info_block_0", "framestyle": "width:180px;max-width:180px;min-width:180px;","default": "0.0.0.0", "ishide": "1" },
        { "title": "Host ModbusPort", "key": "serverport", "data": [], "type": "input", "field": "serverport", "class": "info_block_0", "framestyle": "width:100px;max-width:100px;min-width:100px;","default": "502", "ishide": "1" },
        { "title": "Host ModbusStationID", "key": "serverstationid", "data": [], "type": "input", "field": "serverstationid", "class": "info_block_0","default": "1", "ishide": "1" },
        { "title": "設備型號", "key": "maker", "data": dv_map, "type": "select", "field": "maker", "framestyle": "width:300px;max-width:300px;min-width:300px;", "notnull": "1" , "class": "info_block_3"},
        { "title": "ParameterID", "key": "parameterid", "data": [], "type": "input", "field": "parameterid", "framestyle": "width:50px;max-width:50px;min-width:50px;", "ishide": "1" },
        { "title": "DeviceType", "key": "devtype", "data": devType_map, "type": "select", "field": "devicetype", "ishide": "1", "default": "DPM" },
        { "title": "ConnectionType", "key": "connecttype", "data": connectType_map, "type": "select", "field": "connectiontype", "default": "COM", "ishide": "1" },
        { "title": "Serialporttype", "key": "serialporttype", "data": rs_map, "type": "select", "field": "serialporttype", "class": "info_block_1", "notnull": "1", "framestyle": "width:250px;max-width:250px;min-width:250px;" }, 
        { "title": "BaudRate", "key": "br", "data": br_map, "type": "select", "field": "baudrate", "class": "info_block_1", "notnull": "1", "framestyle": "width:180px;max-width:180px;min-width:180px;" },
        { "title": "DataBits", "key": "db", "data": db_map, "type": "select", "field": "databits", "class": "info_block_1", "notnull": "1", "framestyle": "width:90px;max-width:90px;min-width:90px;" },
        { "title": "Stop", "key": "stop", "data": sb_map, "type": "select", "field": "stop", "style": "width:50px;", "class": "info_block_1", "notnull": "1", "framestyle": "width:90px;max-width:90px;min-width:90px;" },
        { "title": "Parity", "key": "parity", "data": parity_map, "type": "select", "field": "parity", "class": "info_block_1", "notnull": "1", "framestyle": "width:90px;max-width:90px;min-width:90px;" },
        { "title": "Request Command", "key": "analogcode", "data": analog_map, "type": "select", "field": "analogcode", "class": "info_block_1", "notnull": "1", "framestyle": "width:150px;max-width:150px;min-width:150px;" },
        { "title": "ReaderCode", "key": "readercode", "data": readerCode_map, "type": "select", "field": "readercode", "class": "info_block_1", "notnull": "1", "framestyle": "width:250px;max-width:250px;min-width:250px;" },
        { "title": "MapFile", "key": "name", "data": glMapFiles, "type": "select", "field": "mapfile", "class": "info_block_2", "style": "max-width:80%;", "framestyle": "width:250px;max-width:250px;min-width:250px;", "notnull": "1" },
    ],
    "fins": [
        { "title": "", "key": "editButton", "data": [], "type": "input", "field": "editButton", "class": "editButton"},
        { "title": "Name", "key": "name", "data": [], "type": "input", "field": "name", "ishide": "1" },
        { "title": "ChamberID", "key": "chamberid", "data": [], "type": "input", "field": "chamberid", "class": "info_block_0", "framestyle": "width:150px;max-width:150px;min-width:150px;","default": "800", "ishide": "1" },
        { "title": "Host ModbusIP", "key": "serverip", "data": [], "type": "input", "field": "serverip", "class": "info_block_0", "framestyle": "width:180px;max-width:180px;min-width:180px;","default": "0.0.0.0" },
        { "title": "Host ModbusPort", "key": "serverport", "data": [], "type": "input", "field": "serverport", "class": "info_block_0", "framestyle": "width:100px;max-width:100px;min-width:100px;","default": "502" },
        { "title": "Host ModbusStationID", "key": "serverstationid", "data": [], "type": "input", "field": "serverstationid", "class": "info_block_0","default": "1" },
        { "title": "Modbus N Num", "key": "modbusn", "data": [], "type": "input", "field": "modbusn", "class": "info_block_0" },
        { "title": "PLC IP", "key": "deviceip", "data": [], "type": "input", "field": "deviceip", "class": "info_block_0", "framestyle": "width:180px;max-width:180px;min-width:180px;" },
        { "title": "PLC fins Port", "key": "deviceport", "data": [], "type": "input", "field": "deviceport", "class": "info_block_0", "framestyle": "width:100px;max-width:100px;min-width:100px;","default": "9600"  },
        { "title": "Fins_Destination", "key": "finsdestination", "data": [], "type": "input", "field": "finsdestination", "class": "info_block_0", "framestyle": "width:130px;max-width:130px;min-width:130px;", "default": "0" },
        { "title": "設備型號", "key": "maker", "data": dv_map, "type": "select", "field": "maker", "notnull": "1", "framestyle": "width:300px;max-width:300px;min-width:300px;" },
        { "title": "ParameterID", "key": "parameterid", "data": [], "type": "input", "field": "parameterid", "ishide": "1" },
        { "title": "DeviceType", "key": "devtype", "data": devType_map, "type": "select", "field": "devicetype", "ishide": "1" },
        { "title": "ConnectionType", "key": "connecttype", "data": connectType_map, "type": "select", "field": "connectiontype", "ishide": "1" },
        { "title": "MapFile", "key": "mapfile", "data": glMapFiles, "type": "select", "field": "mapfile", "class": "info_block_2", "framestyle": "width:250px;max-width:250px;min-width:250px;" },
    ],
    "modbus": [
        { "title": "", "key": "editButton", "data": [], "type": "input", "field": "editButton"},
        { "title": "Name", "key": "name", "data": [], "type": "input", "field": "name", "ishide": "1" },
        { "title": "ChamberID", "key": "chamberid", "data": [], "type": "input", "field": "chamberid", "class": "info_block_0", "framestyle": "width:150px;max-width:150px;min-width:150px;","default": "900", "ishide": "1" },
        { "title": "Host ModbusIP", "key": "serverip", "data": [], "type": "input", "field": "serverip", "class": "info_block_0", "framestyle": "width:180px;max-width:180px;min-width:180px;","default": "0.0.0.0" },
        { "title": "Host ModbusPort", "key": "serverport", "data": [], "type": "input", "field": "serverport", "class": "info_block_0", "framestyle": "width:100px;max-width:100px;min-width:100px;","default": "502" },
        { "title": "Host ModbusStationID", "key": "serverstationid", "data": [], "type": "input", "field": "serverstationid", "class": "info_block_0","default": "1" },
        { "title": "Modbus N Num", "key": "modbusn", "data": [], "type": "input", "field": "modbusn", "class": "info_block_0" },
        { "title": "PLC IP", "key": "deviceip", "data": [], "type": "input", "field": "deviceip", "class": "info_block_0", "framestyle": "width:180px;max-width:180px;min-width:180px;" },
        { "title": "PLC modbus Port", "key": "deviceport", "data": [], "type": "input", "field": "deviceport", "class": "info_block_0", "framestyle": "width:100px;max-width:100px;min-width:100px;","default": "502" },
        { "title": "PLC Modbus StationID", "key": "devicestationid", "data": [], "type": "input", "field": "devicestationid", "class": "info_block_0","default": "1" },
        { "title": "設備型號", "key": "maker", "data": dv_map, "type": "select", "field": "maker", "framestyle": "width:300px;max-width:300px;min-width:300px;" },
        { "title": "ParameterID", "key": "parameterid", "data": [], "type": "input", "field": "parameterid", "ishide": "1" },
        { "title": "DeviceType", "key": "devtype", "data": devType_map, "type": "select", "field": "devicetype", "ishide": "1" },
        { "title": "ConnectionType", "key": "connecttype", "data": connectType_map, "type": "select", "class": "info_block_1", "field": "connectiontype", "framestyle": "width:180px;max-width:180px;min-width:180px;", "notnull": "1" },
        { "title": "MapFile", "key": "mapfile", "data": glMapFiles, "type": "select", "field": "mapfile", "class": "info_block_2", "framestyle": "width:300px;max-width:300px;min-width:300px;" },
    ]
};
var glDevInfos = [];
var glDevDefs = [];
var displayCurType = '';

GetComports();

function GetComports() {
    let targetURL = gl_target_server + '/php/deviceinfo.php';
    let p = $.getJSON(targetURL, 'getComports=1', data => {
        $.each(data, (idx, port) => {
            if(idx<2){
            com_ports_map[`COM${idx+1}`] = port;  // rufus
            }
            else if(idx>9){
            com_ports_map[`N2 P${idx-9}`] = port;
            }
            else{
                com_ports_map[`N1 P${idx-1}`] = port;
            }

        });

        if (test_mode === '1') {
            com_ports_map[`vcom_ebara_esr_est_ev-s_ev-m`] = "/dev/vcom_ebara_esr_est_ev-s_ev-m";
            com_ports_map[`vcom_edwards`] = "/dev/vcom_edwards";
            com_ports_map[`vcom_ksy_mu_ts`] = "/dev/vcom_ksy_mu_ts";
            com_ports_map[`vcom_ksy_sde_sdt_sdx_sdh`] = "/dev/vcom_ksy_sde_sdt_sdx_sdh";
        }
    })
        .success(() => {
            querydeviceinfo();
            // GetChamberList();
        })
        .error(err => {
            console.log(err);
        })
}

function GetChamberList() {
    let targetURL = gl_target_server + '/php/deviceinfo.php';
    let p = $.getJSON(targetURL, 'loadchamber=1', data => {
        $.each(data, (idx, val) => {
            chamberid_map[val.chambername] = val.chamberkey;
        });
    })
        .success(() => {
            querydeviceinfo();
        })
}

function querydeviceinfo() {
    let targetURL = gl_target_server + "/php/deviceinfo.php";
    let p = $.getJSON(targetURL, "querydevinfo=1", data => {
        glDevInfos = [];
        $.each(data, (idx, info) => {
            switch (idx) {
                case "devinfos":
                    $.each(info, (i, v) => {
                        if ($('#ui_toolid').val() === '')
                            $('#ui_toolid').val(v.toolid);
                        if ($('#ui_dpmid').val() === '')
                            $('#ui_dpmid').val(v.dpmid);
                        glDevInfos[v.id] = v;
                    });
                    break;
                case "devdefs":
                    $.each(info, (i, v) => {
                        glDevDefs[v.id] = v;
                    });
                    break;
                case "mapfiles":
                    $.each(info, (i, v) => {
                        glMapFiles[i] = v.class;
                    })
                    break;
            }
        });
        SetDeviceMap();
    })
        .success(() => {
            createDevInfoTable();
        })
        .error(err => {
            console.log(err);
        })
}

function createDevInfoTable() {
    let thead, tbody;
    console.log(glDevInfos);
    for (var i = 0; i < 3; i++) {

        switch (i) {
            case 0:
                displayCurType = "com";
                break;
            case 1:
                displayCurType = "fins";
                break;
            case 2:
                displayCurType = "modbus";
                break;
        };

        // header
        thead = $(`#head_${displayCurType}`)[0];
        $(thead).children().remove();

        SetTableHead(thead, glFieldSetting[displayCurType]);

        // body
        tbody = $(`#body_${displayCurType}`)[0];
        $(tbody).children().remove();

        let datas = glDevInfos.filter(d => {
            return d.connectiontype.toLowerCase().indexOf(displayCurType) > -1;
        })

        if (datas.length > 0) {
            $.each(datas, (idx, data) => {
                if (data == undefined)
                    return;
                SetTableRow(tbody, glFieldSetting[displayCurType], data);
            })
        }

    };
}

function SetTableHead(body, fds) {
    var tr, th;
    tr = document.createElement("tr");
    body.appendChild(tr);

    th = document.createElement("th");
    tr.appendChild(th);

    $.each(fds, (idx, set) => {
        th = document.createElement("th");
        th.textContent = set.title;

        if (set.framestyle != undefined)
            th.setAttribute("style", set.framestyle);

        if (set.ishide != undefined && set.ishide == "1")
            th.style.display = "none";

        tr.appendChild(th);
    })

}

function SetTableRow(body, set, data) {
    let tr = document.createElement("tr");
    tr.setAttribute("data-key", data["id"]);
    tr.setAttribute("data-type", body.id.split("_")[1]);
    body.appendChild(tr);

    CreateViewRow(tr, set, data);
}

function CreateViewRow(tr, set, data) {
    let td, tag_i;

    td = document.createElement("td");
    tr.appendChild(td);

    tag_i = document.createElement("i");
    tag_i.setAttribute("class", "fa fa-trash-o");
    tag_i.setAttribute("title", "delete");
    td.appendChild(tag_i);

    $.each(set, (idx, set) => {
        let td = document.createElement("td");
        CreateViewCol(td, set, data);
        tr.appendChild(td);
    });

}

function CreateViewCol(td, set, data) {
    let tag_i, span;

    td.setAttribute("data-field", set.field);
    td.classList.add("over_content");

    if (set.class != undefined && set.class != '')
        td.classList.add(set.class);

    if (set.framestyle != undefined)
        td.setAttribute("style", set.framestyle);

    if (set.ishide != undefined && set.ishide == '1')
        td.style.display = "none";

    switch (set.field) {
        case "editButton":
        //case "slaveport":
        //case "baudrate":
        //case "mapfile":
            tag_i = document.createElement("i");
            tag_i.setAttribute("class", "fa fa-edit");//改成可編輯
            tag_i.setAttribute("title", "edit");
            td.appendChild(tag_i);
            break;
        // case "chamberid":
        //     if (displayCurType != 'com') {
        //         tag_i = document.createElement("i");
        //         tag_i.setAttribute("class", "fa fa-edit");
        //         tag_i.setAttribute("title", "edit");
        //         td.appendChild(tag_i);
        //     }
        //     break;
        case "connectiontype":
            if (displayCurType == 'modbus') {
                tag_i = document.createElement("i");
                tag_i.setAttribute("class", "fa fa-edit");
                tag_i.setAttribute("title", "edit");
                td.appendChild(tag_i);
            }
            break;
        case "maker":
            tag_i = document.createElement("i");
            tag_i.setAttribute("class", "fa fa-exchange");//改成可編輯
            tag_i.setAttribute("title", "edit");
            td.appendChild(tag_i);
            break;
    }

    if (data != undefined || data != '') {
        span = document.createElement("span");
        td.appendChild(span);

        switch (set.field) {
            case "mapfile":
            case "readercode":
                span.textContent = data[set.field];
                break;
            case "slaveport":
                Object.keys(com_ports_map).forEach((key, i) => {
                    if (com_ports_map[key] == data[set.field]) {
                        span.textContent = key;
                        return false;
                    }
                });
                break;
            default:
                span.textContent = data[set.field];
        }
        span.setAttribute("title", span.textContent);
    }
}

function Show_devtypes_new(type) {
    if (type == "com" && $(`#body_${type}`).children().length == Object.keys(com_ports_map).length) {
        alert("目前已達DPM裝置可設定最大數量！");
    }
    else {
        let tbody = $(`#body_${type}`)[0];

        //$(tbody).children(":not(.add)").hide();
        $('.nav-tabs').hide();

        let tr = document.createElement("tr");
        tr.setAttribute("class", "add");
        tr.setAttribute("data-type", type);
        tbody.appendChild(tr);

        let set = glFieldSetting[type];

        set.filter(e => {
            switch (e.field) {
                case 'readercode':
                    e.data = readerCode_map[type];
                    break;
                case 'maker':
                    e.data = dv_map[type];
                    break;
                case 'devicetype':
                    e.data = devType_map[type];
                    break;
                case 'connectiontype':
                    e.data = connectType_map[type];
                    break;
                case 'serialporttype':
                    e.data = rs_map[type];
                    break;
                    
            }
        });

        editRow(tr, set, null, true);
        DisplaySaveBtn();
    }

}

function editRow(tr, fds, data, add = false) {
    td = document.createElement("td");
    tr.appendChild(td);

    // Action Icon
    if (data == undefined) {
        tag_i = document.createElement("i");
        tag_i.setAttribute("class", "fa fa-trash-o");
        tag_i.setAttribute("title", "delete");
        td.appendChild(tag_i);
    } else {
        tag_i = document.createElement("i");
        tag_i.setAttribute("class", "fa fa-reply");
        tag_i.setAttribute("title", "");
        td.appendChild(tag_i);
    }

    $.each(fds, (idx, fd) => {
        let td = document.createElement("td");
        td.setAttribute("data-field", fd.field);
        td.classList.add("over_content");

        if (fd.framestyle != undefined)
            td.setAttribute("style", fd.framestyle);

        tr.appendChild(td);

        switch (fd.field) {
            case "slaveport":
            case "chamberid":
                td.classList.add("info_block_0");
                break;
            case "baudrate":
            case "databits":
            case "stop":
            case "parity":
            case "analogcode":
            case "readercode":
                td.classList.add("info_block_1");
                break;
            case "mapfile":
                td.classList.add("info_block_2");
                break;
        }

        if (fd.ishide != undefined && fd.ishide == '1')
            td.style.display = "none";

        if (!add) {
            switch (fd.field) {
                case "mapfile":
                    tag_i = document.createElement("i");
                    tag_i.setAttribute("class", "fa fa-edit editsvid");
                    tag_i.setAttribute("title", "Edit SVID");
                    td.appendChild(tag_i);
                    break;
            }
            CreateControl(td, fd, data);
        } else {
            switch (fd.field) {
                case "slaveport":
                case "chamberid":
                case "maker":
                case "serverip":
                case "serverport":
                case "modbusn":
                case "serverstationid":
                case "deviceip":
                case "deviceport":
                case "devicestationid":
                case "finsdestination": 
                case "serialporttype": 
                    CreateControl(td, fd, data);
                    break;
                case "connectiontype":
                    switch (tr.dataset["type"]) {
                        case "com":
                            td.textContent = "COM";
                            break;
                        case "fins":
                            td.textContent = "FINS";
                            break;
                        case "modbus":
                            // CreateControl(td, fd, data);
                            break;
                    }
                    break;
                case "devicetype":
                    switch (tr.dataset["type"]) {
                        case "com":
                            td.textContent = "DPM";
                            break;
                        default:
                            td.textContent = "LSC";
                    }
                    break;
            }
        }

    })

}

function CreateControl(col, set, data) {
    switch (set.type) {
        case "select":
            sel = document.createElement("select");
            sel.setAttribute("data-field", set.field);

            if (set.style != undefined)
                sel.setAttribute("style", set.style);

            col.appendChild(sel);

            if (set.notnull == undefined || set.notnull != "1") {
                op = document.createElement("option");
                op.textContent = "None";
                sel.appendChild(op);
            } else {
                let tr = $(col).closest("tr")[0];
                if (tr.classList.contains("add") && set.field == "maker") {
                    op = document.createElement("option");
                    op.textContent = "None";
                    sel.appendChild(op);
                }
            }

            switch (set.field) {
                case "slaveport":
                    let isSelected = false;
                    Object.keys(set.data).forEach((k, i) => {
                        op = document.createElement("option");
                        op.value = set.data[k];
                        op.textContent = k;

                        if (data != undefined && data[set.field] == set.data[k]) {
                            op.setAttribute("selected", "selected");
                            sel.setAttribute("data-oldval", set.data[k]);
                            isSelected = true;
                        } else {
                            let used = glDevInfos.filter(v => {
                                return v.id != set.data["id"] && v.slaveport == set.data[k];
                            });
                            if (used.length > 0) {
                                op.textContent += "[used]";
                                op.setAttribute("data-use", "1");
                            }
                        }
                        sel.appendChild(op);
                    });

                    let tr = $(col).closest("tr")[0];
                    if (tr.classList.contains("add") && !isSelected) {
                        $(sel).children("option[data-use!=1]")[0].setAttribute("selected", "selected");
                    }
                    break;

                default:
                    for (var k = 0; k < set.data.length; k++) {
                        op = document.createElement("option");
                        op.value = set.data[k];
                        op.textContent = set.data[k];

                        if (data != undefined) {
                            if (data[set.field] == set.data[k]) {
                                op.setAttribute("selected", "selected");
                                sel.setAttribute("data-oldval", set.data[k]);
                            }
                        } else {
                            if (set.default != undefined && set.default == set.data[k]) {
                                op.setAttribute("selected", "selected");
                                sel.setAttribute("data-oldval", set.data[k]);
                            }
                        }

                        sel.appendChild(op);
                    }
            }

            break;
        case "input":
            input = document.createElement("input");
            input.setAttribute("type", "text");
            input.setAttribute("data-field", set.field);
            input.classList.add(`ui_${set.key}`);

            if (set.style != undefined && set.style != '')
                input.setAttribute("style", set.style);

            if (data != undefined) {
                input.value = data[set.field];
                input.setAttribute("data-oldval", input.value);
            } else if (set.default != undefined) {
                input.value = set.default;
            }
            col.appendChild(input);
            break;
        case "file":
            let sp = document.createElement("span");
            if (data != undefined)
                sp.innerHTML = data[set.field];
            col.appendChild(sp);

            input = document.createElement("input");
            input.setAttribute("type", "file");
            input.setAttribute("data-field", set.field);
            input.classList.add(`ui_${set.key}`);
            col.appendChild(input);
            break;
    }
}


function checkUniqueModbusNValues() {

// 获取所有具有 "modbusn" data-field 属性的单元格
const modbusCells = document.querySelectorAll('[data-field="modbusn"]');

// 用于存储 "Modbus N Num" 列的所有值
const modbusValues = new Set();

// 遍历所有单元格，检查重复值并存储到 Set 中
for (const cell of modbusCells) {
  value = cell.textContent.trim(); // 获取单元格的文本内容，并去除首尾空格
  if(value=='' &&cell.querySelector('input[type="text"]')!=undefined){
    value=cell.querySelector('input[type="text"]').value;

    }
  if (modbusValues.has(value)) {
    return false; // 发现重复值，返回 false
  }
  if(value!=''){
  modbusValues.add(value); // 将值添加到 Set 中
}
}

// 没有发现重复值，返回 true
return true;
}



function SaveDevInfo() {
    let devInfos = {};
    let params = '';
    let key = -1;
    let writedev = '';
    let writesvid = '';
    let isUnRule = false;
    devInfos["toolid"] = document.getElementById("ui_toolid").value;
    devInfos["add"] = [];
    devInfos["edit"] = [];
    devInfos["writedev"] = [];

    if(!checkUniqueModbusNValues()){
        alert("請注意ModbusN有重復的值，可以存檔但請檢查");
        //return false;
    }
    
    if($("#body_com").children("tr").length>0 && devInfos["toolid"].length != 6){
        alert("toolid 必填且要有6碼");
        return false;
    }
    // var firstElement = $("li.active:first");
    // // 现在，你可以对 firstElement 变量中的元素进行操作
    // // 比如输出它的文本内容
    // console.log(firstElement.text());

    // if (devInfos["toolid"].length == 0 and ) {
    //     alert("toolid 必填");
    //     return false;
    // }

    if (CheckFieldNull())
        return false;

    if ($("select[data-field='slaveport'] option[data-use='1']:selected").length > 0) {
        alert("PORT已被使用！");
        return false;
    }

    $("select[data-field='readercode']").each((idx, sel) => {
        if ($(sel).val() == 'KSY_SDE_SDT_SDX_SDH') {
            let tr = sel.closest('tr');
            let code = $(tr).find("select[data-field='analogcode']");
            if (code.length > 0)
                code = code[0];
            if ($(code).val() == 'None') {
                alert('[KSY_SDE_SDT_SDX_SDH]設備[Request Command]不可為"None"!');
                isUnRule = true;
                return false;
            }
        }
    })

    if (isUnRule)
        return false;
    //讀取前端數值組成devInfos發送給後端
    $("tr.add").each((idx, tr) => {
        let type = tr.className;
        data = {};
        $(tr).children().each((i, td) => {
            let field = $(td).attr("data-field");
            let val = '';
            console.log(field);
            if (field == undefined||field =="editButton")
                return;

            switch (field) {
                case "connectiontype":
                    val = td.textContent;
                    if(val=='COM'){
                        if(devInfos["toolid"].length != 6){
                        alert("toolid 必填且要有6碼");
                        isUnRule=true;
                        return false;
                    }
                    }
                    break;                
                case "name":
                    val = $('input[data-field=chamberid]').val();
                    break;
                case "parameterid":
                    val = "999";
                    break;
                case "chamberid":                
                    val = $(td).children()[0].value.padStart(3, '0');
                    if(val.length>3){
                        alert("chamberid 不能超過3碼");
                        isUnRule=true;
                        return false;
                    }
                    break;
                case "slaveport":
                    //case "devicetype":
                    //if($(td).children()[0].value=="DPM" and devInfos["toolid"].length == 0)
                    //    //     alert("toolid 必填");
                    //     return false;
                    //
                case "maker":
                case "serverip":
                case "serverport":
                case "serverstationid":
                case "modbusn":
                case "deviceip":
                case "deviceport":
                case "devicestationid":
                case "finsdestination":
                    val = $(td).children()[0].value;
                    break;
                default:
                    if (input.tagName == 'I')
                        return;
                    val = td.textContent;
            }
            data[field] = val;
        })
        devInfos[type].push(data);
    });

    $("tr.edit").each((idx, tr) => {
        let type = tr.className;
        let key = tr.dataset["key"];
        let maker = null;
        data = {};

        $(tr).children().each((i, td) => {
            let field = $(td).attr("data-field");
            let val = '';
            console.log(field);
            if (field == undefined||field =="editButton")
                return;

            switch (field) {
                case "connectiontype":
                    val = td.textContent;
                    if(val=='COM'){
                        if(devInfos["toolid"].length != 6){
                        alert("toolid 必填且要有6碼");
                        isUnRule=true;
                        return false;
                    }
                    }
                    break; 
                case "name":
                    val = $('input[data-field=chamberid]').val();
                    break;
                case "parameterid":
                    val = "999";
                    break;
                case "chamberid":
                    val = $(td).children()[0].value.padStart(3, '0');
                    if(val.length>3){
                        alert("chamberid 不能超過3碼");
                        isUnRule=true;
                        return false;
                    }
                    break;
                case "slaveport":
                    // val =$(td).children().eq(1).val();
                    // break;                

                case "serverip":
                case "serverport":
                case "serverstationid":
                case "modbusn":
                case "deviceip":
                case "deviceport":
                case "devicestationid":
                case "finsdestination":
                    val = $(td).children()[0].value;
                    break;
                case "maker":
                    val =$(td).children().eq(1).val();
                    if (val == '')
                        val=$(td).children().eq(1).add("select[data-field='maker'] option:selected").val()
                    if (val == '')
                        return;
                    console.log(val);
                    break;
                default:
                    if (input.tagName == 'I')
                        return;
                    val = td.textContent;
            }
            data[field] = val;
        })

        devInfos[type][key] = data;
    });
    if (isUnRule)
        return false;
    console.log(JSON.stringify(devInfos));
    let targetURL = gl_target_server + "/php/deviceinfo.php";
    // console.log(params);
    $.ajax({
        method: "POST",
        dataType: 'json',
        url: targetURL,
        data: { 'func': 'savedevinfo', 'data': JSON.stringify(devInfos) },
        success: function (json) {

            if (!$.isEmptyObject(glDevSvid)) {

                $.ajax({
                    method: "POST",
                    dataType: 'json',
                    url: targetURL,
                    data: { 'func': 'savedevsvid', 'data': JSON.stringify(glDevSvid) },
                    success: function (json) {
                        SaveCompleted();
                    },
                    error: function (err) {
                        console.log(err);
                    }
                });

            } else {
                SaveCompleted();
            }

        },
        error: function (err) {
            console.log(err);
        }
    });

}

function SaveCompleted() {
    alert("存檔成功！");
    $('.nav-tabs').show();
    querydeviceinfo();
    ResetComportItem();
    ExportCsv();
}

function CheckFieldNull() {
    let type = '';
    let isRep = false;
    for (var i = 0; i < 3; i++) {
        switch (i) {
            case 0:
                type = 'com';
                break;
            case 1:
                type = 'fins';
                break;
            case 2:
                type = 'modbus';
                break;
        }

        let set = glFieldSetting[type].filter(f => {
            return f.notnull != undefined && f.notnull == "1";
        });

        if (set != null && set.length > 0) {
            $.each(set, (idx, s) => {
                if ($(`td[data-field='${s.field}']`).css("display") != "none") {
                    if ($(`td[data-field='${s.field}'] input`).length > 0) {
                        if ($(`td[data-field='${s.field}'] input`).val() == '') {
                            errMsg = `[${s.title}] 不可空白！`;
                            isRep = true;
                            return false;
                        }
                    }
                    if ($(`td[data-field='${s.field}'] select`).length > 0) {
                        for(var select_i=0;select_i<$(`td[data-field='${s.field}'] select`).length;select_i++)
                        if ($(`td[data-field='${s.field}'] select`).eq(select_i).val() == 'None') {
                            errMsg = `[${s.title}] 不可空白！`;
                            isRep = true;
                            return false;
                        }
                    }
                }
            })
        }

        if (isRep) {
            alert(errMsg);
            break;
        }
    }

    return isRep;
}

function ExportCsv() {
    targetURL = gl_target_server + "/php/export.php";
    var e = $.getJSON(targetURL, "getdevicecsv=1", data => {
        console.log(data);
    })
        .success(() => {

        })
        .error(err => {
            console.log("err=>" + err);
        })
}

function DisplaySaveBtn() {
    // if ($("tr.add, tr td.edit, tr td.add").length > 0) {
    //     $("#btn_save").show();
    //     $("#ui_toolid, #ui_dpmid").removeAttr("disabled");
    // }
    // else
    //     $("#btn_save").hide();
}

function SetDeviceMap() {
    let type;
    dv_map = {};
    for (var i = 0; i < 3; i++) {
        switch (i) {
            case 0:
                type = "com";
                break;
            case 1:
                type = "fins";
                break;
            case 2:
                type = "modbus";
                break;
        }
        console.log(glDevDefs);
        let data = glDevDefs.filter(d => {
            return d.connectiontype.toLowerCase().indexOf(type) > -1;
        });

        dv_map[type] = [];
        $.each(data, (idx, value) => {
            if (dv_map[type].indexOf(value.machinetype) < 0)
                dv_map[type].push(value.machinetype);
        });

    }
}

function SaveTempSvid() {
    let result = false;
    let mapfilename = $(document.getElementById("dialog_svid").contentWindow.document.body).find("#ui_saveas").val();
    let tbody = $(document.getElementById("dialog_svid").contentWindow.document.body).find("#ui_svid_body")[0];
    let fieldset = document.getElementById("dialog_svid").contentWindow.glFields;
    let datas = [];

    let errMsg = document.getElementById("dialog_svid").contentWindow.CheckFieldNull();
    if (errMsg != '') {
        alert(errMsg);
        return false;
    }

    $(tbody).find('tr').each((idx, tr) => {
        // let tr = $(chk).closest("tr")[0];
        let key = "";
        let param = {};
        $(tr).children().each((i, td) => {

            if ($(td).attr('data-field') == undefined)
                return;

            if ($(td).attr('data-field') == "parameterid")
                key = $(td).children()[0].value;

            switch ($(td).attr('data-field')) {
                case "ulma":
                    param["serverfunctioncode"] = transServerAddressData("save", parseInt($(td).children()[0].value[0]));
                    param["serveraddress"] = $(td).children()[0].value.substr(1);
                    break;
                case "dlma":
                    param["functioncode"] = transAddressData("save", parseInt($(td).children()[0].value[0]));
                    param["address"] = $(td).children()[0].value.substr(1);
                    break;
                case "uid":
                    param["uid"] = $(td).html();
                    break;
                default:
                    param[$(td).attr('data-field')] = $(td).children()[0].value;
            }
        });
        datas.push(param);

    });

    glDevSvid[mapfilename] = {};
    glDevSvid[mapfilename] = datas;

    let tmp = $(glTargetSelect).find(`option[value='${mapfilename}']`);
    if (tmp.length == 0) {
        let option = document.createElement("option");
        option.value = mapfilename;
        option.textContent = mapfilename;
        option.setAttribute("data-add", "1");
        option.setAttribute("selected", "selected");
        glTargetSelect.appendChild(option);
        $(glTargetSelect).change();
    }
    glTargetSelect = null;
    result = true;
    return result;
}

function ResetMakerName(tr) {
    // let tr = $(e.currentTarget).parents("tr")[0];
    let blnChange = false;
    let mode = $(tr).attr("class");
    $(tr).children("td.info_block_1, td.info_block_2").each((idx, td) => {
        let ctrl = null;

        if ($(td).children().length > 1)
            ctrl = $(td).children()[1];
        else
            ctrl = $(td).children()[0];

        if (ctrl.value != "None" && ctrl.value != ctrl.dataset["oldval"]) {
            blnChange = true;
            return false;
        }
    })

    if (mode == "add") {
        let sel = $(tr).children().find("select[data-field=maker]")[0];
        if (blnChange) {
            let op = document.createElement("option");
            op.value = `${moment().format("YYYYMMDDHHmmss")}_${sel.value}`;
            op.textContent = `${moment().format("YYYYMMDDHHmmss")}_${sel.value}`;
            op.setAttribute("selected", "selected");
            sel.appendChild(op);
        } else {
            let v = sel.value.split("_")[1];
            $(sel).find("option:selected").remove();
            $(sel).find(`option[value="${v}"]`)[0].selected = true;
        }

    } else {
        let span = $(tr).children("td[data-field=maker]").children("span")[0];
        if (blnChange) {
            if ($(span).attr("data-oldval") == undefined) {
                span.setAttribute("data-oldval", span.textContent);
                span.textContent = `${moment().format("YYYYMMDDHHmmss")}_${span.textContent}`;
            }
        } else {
            if ($(span).attr("data-oldval") != undefined) {
                span.textContent = span.dataset["oldval"];
                span.removeAttribute("data-oldval");
            }
        }
    }

}

function ResetComportItem() {
    GetComports();
}

function ResetSelectCtrls(useList) {
    $("select[data-field='slaveport'] option").each((idx, op) => {
        let sel = $(op).closest("select")[0];
        let po = op.textContent.replace("[used]", "");
        if (useList.includes(po) && $(sel).children(":selected")[0].textContent != po) {
            op.setAttribute("data-use", "1");
            op.textContent = po + "[used]";
        } else {
            op.removeAttribute("data-use");
            op.textContent = po;
        }
    });
}


function ClickEditButtonAction(tr) {
    let editButtonTds =$(tr).children(`.editButton`);
    $.each(editButtonTds, (idx, td) => {
        field = td.dataset["field"];
        td.textContent = "";
        td.classList.add("edit");
        switch (field) {
            case "editButton":
                tag_i = document.createElement("i");
                tag_i.setAttribute("class", "fa fa-reply");
                tag_i.setAttribute("title", "");
                td.appendChild(tag_i);
                break;
        }
    });
}


let g_fa_edit_clicked=false;
$(document).ready(function () {

    $("#dpm_list").on("click", ".fa-edit", e => {
        g_fa_edit_clicked=true;
        let tr = $(e.currentTarget).closest("tr")[0];
        let key = $(tr).data("key");
        let field = $(e.currentTarget).closest("td")[0].dataset["field"];
        let data = glDevInfos[key];
        let cls = '', tag_i;

        tr.classList.add("edit");
        displayCurType = $(tr).data("type");

        ClickEditButtonAction(tr)

        switch (field) {
            case "baudrate":
            case "connectiontype":
                cls = "info_block_1";
                break;
            case "mapfile":
                cls = "info_block_2";
                break;
            default:
                cls = "info_block_0";
        }

        let tds = $(tr).children(`.${cls}`);

        $.each(tds, (idx, td) => {
            field = td.dataset["field"];
            td.textContent = "";
            // let set = glFieldSetting[displayCurType].clone();
            let set = glFieldSetting[displayCurType].filter(f => {
                return f.field == field;
            })[0];

            switch (field) {
                case "readercode":
                case "connectiontype":
                    if (set.data[displayCurType] != undefined)
                        set.data = set.data[displayCurType];
                    break;
            }

            td.classList.add("edit");
            switch (field) {
                //case "slaveport":
                case "baudrate":
                case "mapfile":
                    tag_i = document.createElement("i");
                    tag_i.setAttribute("class", "fa fa-reply");
                    tag_i.setAttribute("title", "");
                    td.appendChild(tag_i);
                    break;
                // case "chamberid":
                //     if (displayCurType != "com") {
                //         tag_i = document.createElement("i");
                //         tag_i.setAttribute("class", "fa fa-reply");
                //         tag_i.setAttribute("title", "cancel");
                //         td.appendChild(tag_i);
                //     }
                //     break;
                case "connectiontype":
                    if (displayCurType == "modbus") {
                        tag_i = document.createElement("i");
                        tag_i.setAttribute("class", "fa fa-reply");
                        tag_i.setAttribute("title", "");
                        td.appendChild(tag_i);
                    }
                    break;
            }

            CreateControl(td, set, data);

            switch (field) {
                case "mapfile":
                    let tag_i = document.createElement("i");
                    tag_i.setAttribute("class", "fa fa-pencil");
                    tag_i.setAttribute("title", "edit");
                    td.appendChild(tag_i);
                    break;
            }

        });

        DisplaySaveBtn();

    }).on("click", ".fa-trash-o", e => {
        if (confirm("是否確定刪除？")) {

            let tr = $(e.currentTarget).parents("tr")[0];
            let key = $(tr).data('key');
            let targetURL = gl_target_server + "/php/deviceinfo.php";
            $.getJSON(targetURL, "deldevinfo=1&key=" + key, data => {
                console.log(data);
            })
                .success(() => {
                    $(tr).remove();
                    alert('刪除成功！');

                    if ($("tr.edit, tr.add").length == 0) {
                        $(".nav-tabs").show();
                        ResetComportItem();
                    }

                    // querydeviceinfo();
                    // if ($('tr.add').length == 0) {
                    //     $("tbody").children(":not(.add)").show();
                    //     $('.nav-tabs').show();
                    // }

                })
                .error(err => {
                    console.log(`err=>${err}`);
                })

        }
    }).on("click", ".fa-reply", e => {
        location.reload();
        //按回覆後直接存檔
        // $('#btn_save').trigger('click');

        // let tr = $(e.currentTarget).closest("tr")[0];
        // let key = $(tr).data("key");
        // let field = $(e.currentTarget).parents("td")[0].dataset["field"];
        // let data = glDevInfos.filter(d => {
        //     return d.id == key;
        // })[0];
        // let cls = '';

        // displayCurType = $(tr).data("type");

        // switch (field) {
        //     case "baudrate":
        //         cls = "info_block_1";
        //         break;
        //     case "mapfile":
        //         cls = "info_block_2";
        //         break;
        //     default:
        //         cls = "info_block_0";
        // }

        // let tds = $(tr).children(`.${cls}`);
        // $.each(tds, (idx, td) => {
        //     let set = glFieldSetting[displayCurType].filter(f => {
        //         return f.field == td.dataset["field"];
        //     })[0];
        //     td.textContent = "";
        //     td.classList.remove("edit");
        //     CreateViewCol(td, set, data);
        // })

        // if ($(tr).children("td.edit").length == 0)
        //     $(tr).removeClass("edit");


        // //針對設備型號刪除  td.classList.remove("edit"); 大家好我是拼裝車.....
        // let tds1 = $(tr).children(`.info_block_3`);
            
        //     $.each(tds1, (idx, td) => {
        //         let set = glFieldSetting[displayCurType].filter(f => {
        //             return f.field == td.dataset["field"];
        //         })[0];

        //         let data1 = glDevInfos.filter(d => {
        //             return d.maker == $(td).children().eq(1).add("select[data-field='maker'] option:selected").val();
        //         })[0];

        //         td.textContent = "";
        //         td.classList.remove("edit");
        //         CreateViewCol(td, set, data1);
        //     })

        // ResetMakerName(tr);

        // DisplaySaveBtn();
        // g_fa_edit_clicked=false;

    }).on("change", "select[data-field='slaveport']", e => {
        let selected = $(`select option[value='${e.currentTarget.value}']`)[0];
        if (selected.dataset['use'] == '1') {
            alert('此PORT已被使用，請選擇其他PORT！');
            $(e.currentTarget).val("None");
        } else {
            let useList = [];
            $("select option:selected").each((idx, op) => {
                useList.push(op.textContent);
            })
            $("td[data-field='slaveport'] span").each((idx, sp) => {
                useList.push(sp.textContent);
            })
            ResetSelectCtrls(useList);
        }
    }).on("click", "select[data-field='slaveport']", e => {
        //click就要確認port是否有被占用
            let useList = [];
            $("select option:selected").each((idx, op) => {
                useList.push(op.textContent);
            })
            $("td[data-field='slaveport'] span").each((idx, sp) => {
                useList.push(sp.textContent);
            })
            ResetSelectCtrls(useList);
        
    }).on("click", ".fa-exchange", e => {
        if(g_fa_edit_clicked){
        let tr = $(e.currentTarget).closest("tr")[0];
        let key = $(tr).data("key");
        let type = $(tr).data("type");
        let td = $(e.currentTarget).closest("td")[0];
        td.textContent = "";
        td.classList.add("edit");

        let tag_i = document.createElement("i");
        tag_i.setAttribute("class", "fa fa-reply");
        tag_i.setAttribute("title", "");
        td.appendChild(tag_i);

        let data = glDevInfos[key];
        let set = glFieldSetting[type].filter(f => {
            return f.field == "maker";
        })[0];

        set.data = dv_map[type];
        CreateControl(td, set, data);
    }

    }).on("change", "select[data-field='maker']", e => {
        //設備型號 修改
        let tr = $(e.currentTarget).closest("tr")[0];
        let td = $(e.currentTarget).closest("td")[0];
        let type = tr.dataset["type"];
        let val = e.currentTarget.value;
        let oldVal = e.currentTarget.dataset["oldval"];
        let def = glDevDefs.filter(v => {
            return v.machinetype == val;
        })[0];
        let old = glDevInfos.filter(v => {
            return v.id = tr.dataset["key"];
        });
        if (old.length > 0)
            old = old[0];

        $.each(glFieldSetting[type], (i, v) => {

            if (v.ishide != undefined && v.ishide == "1")
                return;

            switch (v.field) {
                case "editButton":
                case "name":
                case "slaveport":
                case "maker":
                case "chamberid":
                case "serverip":
                case "serverport":
                case "serverstationid":
                case "modbusn":
                case "deviceip":
                case "deviceport":
                case "devicestationid":
                case "finsdestination":
                    break;
                default:
                    if (td.classList.contains("edit")) {
                        let contentCtrl;
                        let d;
                        if (oldVal == val) {
                            d = def[v.field];
                            // joshua 20240116d = old[v.field];
                        } else {
                            d = def[v.field]
                        }

                        if ($(tr).children(`td[data-field=${v.field}]`).children("select").length > 0) {
                            contentCtrl = $(tr).children(`td[data-field=${v.field}]`).children("select")[0];
                            $(contentCtrl).val(d);
                        } else {
                            contentCtrl = $(tr).children(`td[data-field=${v.field}]`).children("span")[0];
                            contentCtrl.textContent = d;
                        }
                    }
                    else {
                        let tdn = $(tr).children(`td[data-field=${v.field}]`)[0]
                        tdn.textContent = def[v.field];
                        //當設備型號 修改時輸出
                        //BaudRate	DataBits	Stop	Parity	Request Command	ReaderCode	MapFile
                        console.log(tdn.textContent);
                    }
            }
        });

    }).on("click", ".fa-pencil", e => {
        let tr = $(e.currentTarget).closest("tr")[0];
        let td = $(e.currentTarget).closest("td")[0];
        let mapfile = $(td).find("select[data-field=mapfile]")[0].value;
        let key = tr.dataset["key"];

        glTargetSelect = $(td).find("select[data-field='mapfile']")[0];
        console.log("click.fa-pencil");
        if (mapfile == "none")
            alert("請選擇欲修改的MapFile!");
        else {
            let dialog_frame = document.getElementById("dialog_svid");
            dialog_frame.setAttribute("src", `/devsvid.php?mapfile=${mapfile}&key=${key}`);
            $("#dialog").dialog("open");
        }

    }).on("change", "td.info_block_1 select, td.info_block_1 input, td.info_block_2 select", e => {
        ResetMakerName($(e.currentTarget).closest("tr")[0]);
    }).on("change", "input.ui_chamberid", e => {
        let val = e.currentTarget.value;
        let datas = [];
        $("td[data-field='chamberid']").each((idx, td) => {
            let tag = td.children[0];
            switch (tag.tagName) {
                case "SPAN":
                    datas.push((tag.textContent).padStart(3, '0'));
 
                    //datas.push(tag.textContent);
                    break;
                case "INPUT":
                    datas.push((tag.value).padStart(3, '0'));
                //datas.push(tag.value);
                    break;
            }
        });

        let rep = datas.filter(v => {
            return v == val;
        });

        if (rep.length > 1) {
            e.currentTarget.value = '';
            alert('chamberID已存在，請重新輸入！');
        }

    });

    $("#dialog").dialog({
        modal: true,
        autoOpen: false,
        title: "修改SVID",
        width: "90%",
        height: 700,
        dialogClass: "dlg-no-close",
        buttons: {
            "確定": function () {
                if (SaveTempSvid())
                    $("#dialog").dialog("close");
                // console.log("edit");
            },
            "取消": function () {
                $("#dialog").dialog("close");
            }
        }
    });
})

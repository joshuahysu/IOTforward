var glDevdefDatas = [];
var glMapFiles = [];
var base01=['0','1'];
var fins_endian_map=['0','1'];
var glFieldSetting = {
    "com": [
        {"title": "設備型號", "key": "dv", "data":[], "type": "input", "field": "machinetype", "show": "", "style": "width: 100%;"},
        {"title": "DeviceType", "key": "dvtype", "data":devType_map, "type": "select", "field": "devicetype", "show": "", "default": "DPM", "ishide":"1"},
        {"title": "連線類型", "key": "connecttype", "data":connectType_map, "type": "select", "field": "connectiontype", "show": "", "default": "COM", "ishide":"1"},
        {"title": "serial port類型", "key": "serialporttype", "data":rs_map, "type": "select", "field": "serialporttype", "show": "", "default": "RS-232"},
        {"title": "BaudRate", "key": "br", "data":br_map, "type": "select", "field": "baudrate", "show": "com", "default": "9600"},
        {"title": "DataBits", "key": "db", "data":db_map, "type": "select", "field": "databits", "show": "com"},
        {"title": "Stop", "key": "stop", "data":sb_map, "type": "select", "field": "stop", "show": "com", "style":"max-width: 50px;"},
        {"title": "Parity", "key": "parity", "data":parity_map, "type": "select", "field": "parity", "show": "com"},
        {"title": "Request Command", "key": "ac", "data":analog_map, "type": "select", "field": "analogcode", "show": "", "style":"max-width: 50px;"},
        {"title": "Reader Code", "key": "readercode", "data":[], "type": "select", "field": "readercode", "show": ""},
        {"title": "Mapfile", "key": "mapfile", "data":glMapFiles, "type": "select", "field": "mapfile", "show": ""},
    ],
    "fins": [
        {"title": "設備型號", "key": "dv", "data":[], "type": "input", "field": "machinetype", "show": "", "style": "width: 100%;"},
        {"title": "DeviceType", "key": "dvtype", "data":devType_map, "type": "select", "field": "devicetype", "show": "", "default": "LSC", "ishide":"1"},
        {"title": "連線類型", "key": "connecttype", "data":connectType_map, "type": "select", "field": "connectiontype", "show": "", "default": "FINS", "ishide":"1"},
        // {"title": "Request Command", "key": "readercode", "data":readerCode_map, "type": "select", "field": "readercode", "show": ""},
        {"title": "Mapfile", "key": "mapfile", "data":glMapFiles, "type": "select", "field": "mapfile", "show": ""},
        {"title": "Endian(1=big,0=little)", "key": "fins_endian", "data":fins_endian_map, "type": "select", "field": "fins_endian", "show": "", "default": "1"},
   
    ],
    "modbus": [
        {"title": "設備型號", "key": "dv", "data":[], "type": "input", "field": "machinetype", "show": "", "style": "width: 100%;"},
        {"title": "DeviceType", "key": "dvtype", "data":devType_map, "type": "select", "field": "devicetype", "show": "", "default": "LSC", "ishide":"1"},
        {"title": "連線類型", "key": "connecttype", "data":connectType_map, "type": "select", "field": "connectiontype", "show": ""},
        // {"title": "Request Command", "key": "readercode", "data":readerCode_map, "type": "select", "field": "readercode", "show": ""},
        {"title": "Mapfile", "key": "mapfile", "data":glMapFiles, "type": "select", "field": "mapfile", "show": ""},
        {"title": "01base", "key": "base01", "data":base01, "type": "select", "field": "base01", "show": "", "default": "1"},
    ]
};

QueryDatas();

function QueryDatas()
{
    let targetURL = gl_target_server + "/php/devtypes.php";
    glDevdefDatas = [];
    $.getJSON(targetURL, "queryconfig=1", data => {

        $.each(data['defdev'], (index, item) => {
            glDevdefDatas[item.id] = item;
        });

        $.each(data['mapfiles'], (index, item) => {
            glMapFiles[index] = item.class;
        })
    })
    .success(() => {
        CreateDevdefTable();
    })
    .error(err => {
        console.log(err);
    })
}

function CreateDevdefTable()
{
    $("#dpm_list tbody").children().remove();

    for (var i = 0; i < 3; i++) {
        let type = "";
        switch (i) {
            case 0:
                type = "com";
                break;
            case 1:
                type = "fins";
                break;
            case 2:
                type = "modbus";
                break;
        }

        // head
        let listHead = $(`#head_${type}`)[0];
        $(listHead).children().remove();

        SetTableHead(listHead, glFieldSetting[type]);

        let datas = glDevdefDatas.filter(d => {
            return d.connectiontype.toLowerCase().indexOf(type) > -1;
        })

        if (datas.length > 0) {
            let listBody = $(`#body_${type}`)[0];
            $.each(datas, (idx, data) => {
                // console.log(fds);
                if (data == undefined)
                    return;
                SetTableRow(listBody, glFieldSetting[type], data);
            });
        }

    }

}

function SetTableHead(body, fds)
{
    var tr, th;
    tr = document.createElement("tr");
    body.appendChild(tr);

    th = document.createElement("th");
    tr.appendChild(th);

    $.each(fds, (idx, d) => {
        th = document.createElement("th");
        th.textContent = d.title;

        if (d.ishide != undefined && d.ishide == "1")
            th.style.display = "none";

        tr.appendChild(th);
    })

}

function SetTableRow(body, set, data)
{
    let tr = document.createElement("tr");
    tr.setAttribute("data-key", data["id"]);
    tr.setAttribute("data-type", body.id.split("_")[1]);
    body.appendChild(tr);

    CreateViewRow(tr, set, data);
}

function CreateViewRow(tr, set, data)
{
    let td, tag_i;

    td = document.createElement("td");
    tr.appendChild(td);

    tag_i = document.createElement("i");
    tag_i.setAttribute("class", "fa fa-edit");
    tag_i.setAttribute("title", "edit");
    td.appendChild(tag_i);

    tag_i = document.createElement("i");
    tag_i.setAttribute("class", "fa fa-trash-o");
    tag_i.setAttribute("title", "delete");
    td.appendChild(tag_i);

    $.each(set, (idx, set) => {

        td = document.createElement("td");
        td.setAttribute("data-field", set.field);

        if (set.ishide != undefined && set.ishide == "1")
            td.style.display = "none";

        if (data != undefined || data != '')
        {
            td.textContent = data[set.field];
        }

        tr.appendChild(td);

    });

}

function Show_devtypes_new(type)
{
    let tbody = $(`#body_${type}`)[0];
    let tr = document.createElement("tr");
    tr.setAttribute("class", "add");
    tr.setAttribute("data-type", type);
    tbody.appendChild(tr);

    let set = glFieldSetting[type];
    set.filter(v => {
        switch (v.field) {
            case "machinetype":
                v.data = dv_map[type];
                break;
            case "devicetype":
                v.data = devType_map[type];
                break;
            case "connectiontype":
                v.data = connectType_map[type];
                break;
            case "serialporttype":
                v.data = rs_map[type];
                break;
            case "readercode":
                v.data = readerCode_map[type];
                break;
        }
    });

    editRow(tr, set);
    DisplaySaveBtn();
}

function editRow(tr, fds, data)
{
    td = document.createElement("td");
    tr.appendChild(td);

    // Action Icon
    if (data == undefined)
    {
        tag_i = document.createElement("i");
        tag_i.setAttribute("class", "fa fa-trash-o");
        tag_i.setAttribute("title", "delete");
        td.appendChild(tag_i);

    } else {
        tag_i = document.createElement("i");
        tag_i.setAttribute("class", "fa fa-reply");
        tag_i.setAttribute("title", "cancel");
        td.appendChild(tag_i);
    }

    $.each(fds, (idx, fd) => {
        let td = document.createElement("td");
        tr.appendChild(td);

        if (fd.ishide != undefined && fd.ishide == "1")
            td.style.display = "none";

        CreateControl(td, fd, data);

    })

}

function CreateControl(col, set, data)
{
    let lbl, input, option;

    switch (set.type) {
        case "select":
            input = document.createElement("select");
            input.setAttribute("class", `ui_${set.key}`);
            input.setAttribute("data-field", set.field);
            col.appendChild(input);

            for (var j = 0; j < set.data.length; j++) {
                option = document.createElement("option");
                option.value = set.data[j];
                option.textContent = set.data[j];

                if (set.field == "connectiontype")
                {
                    switch (set.data[j]) {
                        case "COM":
                            option.setAttribute("class", "COM");
                            break;
                        case "FINS":
                            option.setAttribute("class", "FINS");
                            break;
                        case "Modbus TCP":
                        case "Modbus RTU":
                            option.setAttribute("class", "MODBUS");
                            break;
                    }
                }

                if (data != undefined) {
                    if (data[set.field] == set.data[j])
                    {
                        option.setAttribute("selected", "selected");
                    }
                } else {
                    if (set.default != undefined && set.default != "" && set.data[j] == set.default) {
                        option.setAttribute("selected", "selected");
                    }
                }

                // if (data != undefined && data[set.field] == set.data[j]) {
                //     option.setAttribute("selected", "selected");
                // } else if (set.default != undefined && set.default != "" && set.data[j] == set.default) {
                //     option.setAttribute("selected", "selected");
                // }

                input.appendChild(option);
            }
            break;
        case "input":
            input = document.createElement("input");
            input.setAttribute("type", "text");
            input.setAttribute("data-field", set.field);
            input.setAttribute("class", `ui_${set.key}`);

            if (set.style != undefined)
                input.setAttribute("style", set.style);

            if (data != undefined) {
                input.value = data[set.field];
            } else if (set.default != undefined && set.default != "") {
                input.value = set.default;
            }

            col.appendChild(input);
            break;
        case "file":
            let sp = document.createElement("span");
            if (data != undefined)
                sp.innerHTML = data[set.field];
            col.appendChild(sp);

            input = document.createElement("input");
            input.setAttribute("type", "file");
            input.setAttribute("data-field", set.field);
            input.setAttribute("class", `ui_${set.key}`);
            if (data != undefined)
                input.setAttribute("data-old", data[set.field]);

            col.appendChild(input);
            break;
    }

}
function containsSpecialCharacters(fileName) {
    // 定義要檢查的特殊字符
    const specialChars = /[/\\?#%]/;
    // 使用 test 方法檢查字串是否包含特殊字符
    return specialChars.test(fileName);
  }
function SaveDev()
{
    let isRep = false;
    let isNull = false;
    let isUnRule = false;
    $("input[data-field='machinetype']").each((idx, input) => {
        let tr = $(input).closest("tr")[0];
        let cls = tr.className;
        let key = tr.dataset['key'];
        let machiname = input.value;
        let d;

        if (machiname == '') {
            alert(`設備型號不可空白！`);
            isNull = true;
            return false;
        }
        else if(containsSpecialCharacters(machiname)){
            alert('設備型號不可有！/[/\\?#%]/');
            isNull = true;
            return false;
        }

        switch (cls) {
            case "add":
                d = glDevdefDatas.filter(f => {
                    return f.machinetype == machiname;
                })
                if (d.length > 0)
                    isRep = true;
                break;
            case "edit":
                d = glDevdefDatas.filter(f => {
                    return f.machinetype == machiname && f.id != key;
                })
                if (d.length > 0)
                    isRep = true;
                break;
        }

        if (isRep)
        {
            alert(`設備型號 [${machiname}] 已存在，請重新設定！`);
            return false;
        }

    })

    $("select[data-field='readercode']").each((idx, sel) => {
        if ($(sel).val() == 'KSY_SDE_SDT_SDX_SDH') {
            let tr = sel.closest('tr');
            let code = $(tr).find("select[data-field='analogcode']");
            if (code.length > 0)
                code = code[0];
            if ($(code).val() == 'None') {
                alert('[KSY_SDE_SDT_SDX_SDH]設備[Request Command]不可為"None"!');
                isUnRule = true;
                return false;
            }
        }
    })

    if (!isNull && !isRep && !isUnRule)
        SaveDevDef();

}

function SaveDevDef()
{
    let els = {};
    els["add"] = [];
    els["edit"] = [];
    data = {};

    $("tr.edit, tr.add").each((idx, tr) => {
        let classType = tr.className;
        data = {};
        $(tr).children().each((i, td) => {
            let input = $(td).children()[0];

            if (input.tagName == 'I')
                return;
            if (input.tagName == 'SPAN')
                input = $(td).children()[1];

            let field = $(input).attr("data-field");
            let val = $(input).val();

            data[field] = val;
        });

        switch (classType) {
            case "edit":
                els[classType][$(tr).attr("data-key")] = data;
                break;
            case "add":
                els[classType].push(data);
                break;
        }

    });

    console.log(JSON.stringify(els));
    let targetURL = gl_target_server + "/php/devtypes.php";
    let param = "savedevdef=1&data=" + encodeURIComponent(JSON.stringify(els));
    //console.log(param);
    let p = $.getJSON(targetURL, param, data => {
        console.log(data);
    })
    .success(() => {
        alert("存檔成功！");
        QueryDatas();
    })
    .error(err => {
        console.log(err);
    })
}

function DisplaySaveBtn()
{
    if ($("tr.edit, tr.add").length > 0)
        $("#btn_save").show();
    else {
        $("#btn_save").hide();
    }
}

$(document).ready(function (){

    $("#dpm_list").on("click", ".fa-edit", e => {
        let tr = $(e.currentTarget).parents("tr")[0];
        let key = $(tr).data("key");
        let type = $(tr).data("type");
        let data = glDevdefDatas[key];

        let set = glFieldSetting[type];
        set.filter(v => {
            switch (v.field) {
                case "machinetype":
                    v.data = dv_map[type];
                    break;
                case "devicetype":
                    v.data = devType_map[type];
                    break;
                case "connectiontype":
                    v.data = connectType_map[type];
                    break;
                case "serialporttype":
                    v.data = rs_map[type];
                    break;    
                case "readercode":
                    v.data = readerCode_map[type];
                    break;
            }
        });

        $(tr).children().remove();
        $(tr).attr("class", "edit");
        editRow(tr, set, data);
        DisplaySaveBtn();
    }).on("click", ".fa-trash-o", e => {
        if (confirm("是否確定刪除？")) {
            let tr = $(e.currentTarget).parents("tr")[0];
            let key = $(tr).data("key");
            let type = $(tr).attr("class");

            if (type == 'add')
            {
                $(tr).remove();
                DisplaySaveBtn();
            }
            else
            {
                let targetURL = gl_target_server + "/php/devtypes.php";
                let p = $.getJSON(targetURL, "deletedevdef=1&key=" + key, data => {
                    console.log(data);
                })
                .success(() => {
                    alert("刪除成功！");
                    $(tr).remove();

                    glDevdefDatas = glDevdefDatas.filter(v => {
                        return v.id != key
                    });

                    DisplaySaveBtn();
                })
                .error(err => {
                    console.log(err);
                })
            }
        }
    }).on("change", ".ui_dv", e => {
        let tr = $(e.currentTarget).closest("tr")[0];
        let analog = $(tr).find("input[data-field=analogcode]")[0];
        switch (e.currentTarget.value) {
            case "Kashiyama SDE(A&K)":
            case "Kashiyama SDE(X&K)":
            case "Kashiyama SDE(a&k)":
            case "Kashiyama_SDT/SDX/SDH":
                analog.value = "";
                analog.setAttribute("disabled", "disabled");
                break;
            default:
                analog.removeAttribute("disabled");
        }
    }).on("click", ".fa-reply", e => {
        let tr = $(e.currentTarget).closest("tr")[0];
        let key = $(tr).data("key");
        let type = $(tr).data("type");
        let data = glDevdefDatas.filter(d => {
            return d.id == key;
        });

        $(tr).children().remove();
        $(tr).removeClass("edit");
        CreateViewRow(tr, glFieldSetting[type], data[0]);
        DisplaySaveBtn();
    });

})

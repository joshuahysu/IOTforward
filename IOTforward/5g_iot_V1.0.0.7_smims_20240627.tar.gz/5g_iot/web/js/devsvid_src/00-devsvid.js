// 點擊按鈕時下載
const btn = document.getElementById('download');
btn.addEventListener('click', () => {
try {
    DownLoad_Svid_Param_Map(); 
} catch(err) {
    window.alert(err)
} 
})
function DownLoad_Svid_Param_Map()
{
    let val = $("#ui_dev").val();
    let targetURL = gl_target_server + '/php/devsvid.php';

    let p = $.getJSON(targetURL, "loaddevsviddata=1&key=" + val, data => {
    })
        .success((data) => {
        let exportDatas=[];
        console.log(data);
        let name="";
        $.each(data, (index, item) => {
        if(index!="def"){
        name=index;
        console.log(index);
    }
    })
        console.log(data);
      $.each(data[name], (index, item) => {
        //newItem客製自訂格式
        //if(item.MODBUS_SIMULATOR)
        console.log(item);
        let newItem={
            id:(item['id'] !== null) ? item['id'].toString() : "",
            uid:(item['uid'] !== null) ? item['uid'].toString() : "",
            class:item['class']||"",
            parameterid:item['parameterid']||"",
            remark:item['remark']||"",
            category:item['category']||"",
            tagname:item['tagname']||"",
            serveraddress:item['serveraddress']||"",
            serverfunctioncode:item['serverfunctioncode']||"",
            address:item['address']||"",
            startbit:item['startbit']||"",
            endbit:item['endbit']||"",
            num:item['num']||"",
            readfreq:item['readfreq']||"",
            functioncode:item['functioncode']||"",
            scaletype:item['scaletype']||"",
            scalemultiple:item['scalemultiple']||"",
            scaleoffset:item['scaleoffset']||"",
            unit:item['unit']||"",
            max:(item['max'] !== null) ? item['max'].toString() : "",
            min:(item['min'] !== null) ? item['min'].toString() : "",
            signed:item['signed']||"",
            endian:(item['endian'] !== null) ? item['endian'].toString() : "",
            valuetype:(item['valuetype'] !== null) ? item['valuetype'].toString() : "",
            intnum:(item['intnum'] !== null) ? item['intnum'].toString() : "",
            fixed:item['fixed']||"",
            mergemode:(item['mergemode'] !== null) ? item['mergemode'].toString() : "",
            'private':(item['private'] !== null) ? item['private'].toString() : ""
          }
          //console.log(newItem);
          exportDatas.push(newItem); 
      })

        buildData(exportDatas)
        .then(datas => {downloadCSV(datas,"devsvid")
        }       
        )
        .catch(err => window.alert(err));
        }       
        )
        .error(err => {
            console.log(err);
        })
  }


var glMode = 'Model';
var glModbusFieldShow = false;
var glFinsFieldShow = false;
var glCurSvidSample = '';
var glDevinfoDatas = [];
var glSvidSamples = [];
var glSvidPriSamples = [];
var glDevDefSvidData = [];
var glDevSvidData = [];
var glFields = [
    {"title":"UID", "key":"uid", "data":[], "type":"", "field":"uid", "notnull":"1", "framestyle":"width:50px;"},
    {"title":"SVID_ParaID", "key":"parameterid", "data":[], "type":"input", "field":"parameterid", "notnull":"1", "framestyle":"width:85px;"},
    {"title":"Parameter", "key":"remark", "data":[], "type":"input", "field":"remark", "framestyle":"width:135px;max-width:135px;", "notnull":"1"},
    {"title":"原廠參數名稱/fins點位", "key":"tagname", "data":[], "type":"input", "field":"tagname", "framestyle":"min-width:120px;width:120px;"},
    {"title":"Scale Type", "key":"scaletype", "data":scaleType_map, "type":"select", "field":"scaletype", "default":"0", "notnull":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"X", "key":"scalemultiple", "data":[], "type":"input", "field":"scalemultiple", "default":"1", "notnull":"1", "framestyle":"min-width:60px;width:60px;"},
    {"title":"＋", "key":"scaleoffset", "data":[], "type":"input", "field":"scaleoffset", "default":"0", "notnull":"1", "framestyle":"min-width:60px;width:60px;"},
    {"title":"單位", "key":"unit", "data":[], "type":"input", "field":"unit", "framestyle":"min-width:60px;width:60px;"},
    {"title":"Max", "key":"max", "data":[], "type":"input", "field":"max", "default":"32767", "notnull":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"Min", "key":"min", "data":[], "type":"input", "field":"min", "default":"-32768", "notnull":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"小數位", "key":"fixed", "data":[], "type":"input", "field":"fixed", "default":"0", "notnull":"1", "framestyle":"min-width:60px;width:60px;"},
    {"title":"Modbus Slave Address", "key":"ulma", "data":[], "type":"input", "field":"ulma", "ishide":"1", "notnull":"1", "framestyle":"min-width:75px;width:75px;"},
    {"title":"Modbus Master Address", "key":"dlma", "data":[], "type":"input", "field":"dlma", "ishide":"1", "default":"4N001", "framestyle":"min-width:75px;width:75px;"},
    {"title":"ReadFreq", "key":"readfreq", "data":[], "type":"input", "field":"readfreq", "default":"1000", "ishide":"1", "notnull":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"StartBit", "key":"startbit", "data":[], "type":"input", "field":"startbit", "ishide":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"EndBit", "key":"endbit", "data":[], "type":"input", "field":"endbit", "ishide":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"Num(modbus word數量)", "key":"num", "data":[], "type":"input", "field":"num","default":"1", "ishide":"1", "notnull":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"Signed(正負數)", "key":"signed", "data":[], "type":"input", "field":"signed", "default":"1", "ishide":"1", "notnull":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"fins Datatype", "key":"mergemode", "data":fins_merge_mode_map, "type":"select", "field":"mergemode", "ishide":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"endian", "key":"endian", "data":endian_map, "type":"select", "field":"endian","default":"1", "ishide":"1", "notnull":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"valuetype", "key":"valuetype", "data":[], "type":"input", "field":"valuetype", "default":"1", "ishide":"1", "notnull":"1", "framestyle":"min-width:80px;width:80px;"},
    {"title":"intnum", "key":"intnum", "data":[], "type":"input", "field":"intnum", "ishide":"1", "framestyle":"min-width:80px;width:80px;"}
];

var glDefFields = [
    {"title":"SVID_ParaID", "key":"parameterid", "data":[], "type":"input", "field":"parameterid"},
    {"title":"點位名稱", "key":"remark", "data":[], "type":"input", "field":"remark"},
];

// 創建一個<select>元素
var selectElement = document.getElementById('changeTableColumnValue');

// 使用JavaScript迴圈遍歷glFields陣列中的每個物件
glFields.forEach(function(field) {
    switch(field.title){
    case "UID":        
        return;        
    case "SVID_ParaID":
        return;
    case "Parameter":
        return;  
    case "原廠參數名稱/fins點位":
        return;
    case "Modbus Slave Address":
        return;
    case "Modbus Master Address":
        return;                           
    }
    // 創建一個<option>元素
    var optionElement = document.createElement('option');
    // 設置選項的顯示文字為物件的title屬性
    optionElement.textContent = field.title;
    // 設置選項的值為物件的field屬性
    optionElement.setAttribute('value', field.field);
    // 將選項添加到<select>元素中
    selectElement.appendChild(optionElement);
});

// 在表單提交前添加一個隱藏的 input 元素，包含額外的參數
document.getElementById("changeTableColumnValueForm").addEventListener("submit", function(event) {
    var extraParam = document.createElement("input");
    extraParam.setAttribute("type", "hidden");
    extraParam.setAttribute("name", "filename"); // 參數名稱
    extraParam.setAttribute("value", $('#ui_dev').val()); // 參數值
    this.appendChild(extraParam);
});



Load_Svid_Param_Map();

if (glMapFile == "")
    SelectedDevinfo();

function Load_Svid_Param_Map()
{
    let targetURL = gl_target_server + '/php/devsvid.php';
    let p = $.getJSON(targetURL, 'loadsvidparam=1', data => {
        svid_map = [];
        $.each(data, (idx, val) => {
            svid_map[val.parameterid] = val.remark;
        });
    })
    .success(() => {
        if (glMapFile == '')
            Load_svidsemple();
        else {
            glMode = 'Edit';
            ShowTargetMapFile();
        }
    })
}

function Load_svidsemple()
{
    let targetURL = gl_target_server + '/php/devsvid.php';
    let p = $.getJSON(targetURL, 'loadsvidsemple=1', data => {
        glSvidSamples = [];
        glSvidPriSamples = [];
        $.each(data, (idx, info) => {
            if (info.private == '1')
                glSvidPriSamples[info.class] = info;
            else
                glSvidSamples[info.class] = info;
        })
    })
    .success(() => {
        SetDevInfos();
        SetPriDevInfos();
    })
    .error(err => {
        console.log(err);
    })
}

function SetDevInfos()
{
    let sel = document.getElementById("ui_dev");
    let option;

    $(sel).children().remove();

    option = document.createElement("option");
    option.textContent = "None";
    sel.appendChild(option);

    Object.keys(glSvidSamples).forEach((key, v) => {
        option = document.createElement("option");
        option.value = key;
        option.textContent = key;
        sel.appendChild(option);
    });

}

// function SetPriDevInfos()
// {
//     let sel = document.getElementById("ui_dev_pri");
//     let option;

//     $(sel).children().remove();

//     option = document.createElement("option");
//     option.textContent = "None";
//     sel.appendChild(option);

//     Object.keys(glSvidPriSamples).forEach((key, v) => {
//         option = document.createElement("option");
//         option.value = key;
//         option.textContent = key;
//         sel.appendChild(option);
//     });

// }

function ChangeSvidSample() {

    let val = $("#ui_dev").val();
    // $("#ui_dev_pri").val("None");
    
    SelectedDevinfo(val);
}

// function ChangePriSvidSample() {

//     let val = $("#ui_dev_pri").val();
//     $("#ui_dev").val("None");

//     SelectedDevinfo(val);
// }


function SelectedDevinfo(val)
{
    glFinsFieldShow = false;
    glModbusFieldShow = false;
    glCurSvidSample = val;
    if (val == null || val == '' || val == 'None')
        $('#btn_save, #btn_del').hide();
    else
        $('#btn_save, #btn_del').show();

    if (glMapFile != '')
        val = glMapFile;

    let targetURL = gl_target_server + "/php/devsvid.php";
    glDevDefSvidData = [];
    glDevSvidData = [];
    let p = $.getJSON(targetURL, "loaddevsviddata=1&key=" + val, data => {
        $.each(data, (idx, param) => {
            switch (idx) {
                case "def":
                    $.each(param, (i, p) => {
                        glDevDefSvidData[p.id] = p;
                    });
                    break;
                default:
                    $.each(param, (i, p) => {
                        glDevSvidData[p.id] = p;
                    });
            }
        })
    })
    .success(() => {
        $('#svid_datas').show();
        if (glMode == 'Edit') {
            $('#svid_datas').removeClass("c_box");
            if (parent.glDevSvid[glMapFile] != undefined)
                glDevSvidData = parent.glDevSvid[glMapFile];
        }

        $('#ui_svid_body').children().remove();

        ShowSvidHead();
        ShowSvidData();

        if (glMode == "Edit")
            CreateFootData();

        ShowDefSvid();
        CheckContentDiff();
    })
    .error(err => {
        console.log(err);
    })
}

function ShowSvidHead()
{
    let head = document.getElementById("ui_svid_head");
    let type = $("#ui_dev option:selected").attr("data-type");
    let row, col, div;

    $(head).children().remove();

    row = document.createElement("tr");
    head.appendChild(row);

    col = document.createElement("th");
    row.appendChild(col);

    $.each(glFields, (k, set) => {
        col = document.createElement("th");
        col.textContent = set.title;
        col.setAttribute("data-field", set.field);
        if (set.framestyle != undefined)
            col.setAttribute("style", set.framestyle);
        if (set.ishide != undefined)
            col.style.display = "none";
        if (set.field == 'scaleoffset')
            col.style.fontSize = "19px";
        row.appendChild(col);
    });

    col = document.createElement("th");
    col.style.background = "#FFF";
    col.style.width = "90px";
    col.style.minWidth = "90px";
    if (glMode == "Edit")
        col.style.padding = "0px 10px";
    row.appendChild(col);

    //Modbus More
    div = document.createElement("div");
    div.textContent = "Modbus More";
    div.setAttribute("class", "action_more");
    div.setAttribute("onclick", "ShowMore(this, 'modbus')")
    div.style.height = "50px";
    div.style.lineHeight = "50px";
    div.style.fontSize ="16px";
    div.style.width = "130px";
    col.appendChild(div);

    //Fins More
    div = document.createElement("div");
    div.textContent = "Fins More";
    div.setAttribute("class", "action_more");
    div.setAttribute("onclick", "ShowMore(this,'fins');");
    div.style.height = "50px";
    div.style.lineHeight = "50px";
    div.style.fontSize ="16px";
    div.style.width = "130px";
    col.appendChild(div);

}

function ShowSvidData()
{
    let body = document.getElementById("ui_svid_body");
    console.log(glDevSvidData);
    $.each(glDevSvidData, (idx, param) => {
        if (param === undefined)
            return;
        createDataRow(body, param);
    })
}

function createDataRow(body, param)
{
    let row, col, tag_i;
    let isOnly = false;
    let defData = [];

    if (param != null) {
        defData = glDevDefSvidData.filter(d => {
            return d.parameterid == param.parameterid;
        });
    }

    if (defData.length == 0)
        isOnly = true;

    row = document.createElement("tr");
    if (isOnly)
        row.setAttribute("class", "only_dev_svid");
    body.appendChild(row);

    //Action Field
    col = document.createElement("td");
    row.appendChild(col);

    tag_i = document.createElement("i");
    tag_i.setAttribute("class", "fa fa-trash-o");
    tag_i.setAttribute("title", "Remove");
    col.appendChild(tag_i);

    //Data Fields
    $.each(glFields, (idx, set) => {

        col = document.createElement("td");
        col.setAttribute("data-field", set.field);
        if (defData != null && defData.length > 0)
        {
            switch (set.field) {
                case "ulma":
                    if (defData[0]["serverfunctioncode"] != null)
                        col.setAttribute("data-defData", transServerAddressData("view", parseInt(defData[0]["serverfunctioncode"])) + defData[0]["serveraddress"]);
                    break;
                case "dlma":
                    if (defData[0]["functioncode"] != null)
                        col.setAttribute("data-defData", transAddressData("view", parseInt(defData[0]["functioncode"])) + defData[0]["address"]);
                    break;
                default:
                    col.setAttribute("data-defData", (defData[0][set.field] == null ? '' : defData[0][set.field]));
            }
        }
        if (set.framestyle != undefined)
            col.setAttribute("style", set.framestyle);
        if (set.ishide != undefined) {

            switch (set.field) {
                case "mergemode":
                    if (!glFinsFieldShow)
                        col.style.display = "none";
                    break;
                case "ulma":
                case "dlma":
                case "readfreq":
                case "endbit":
                case "startbit":
                case "num":
                case "signed":
                    if (!glModbusFieldShow)
                        col.style.display = "none";
                    break;
                default:
                    col.style.display = "none";
            }
        }
        row.appendChild(col);

        if (glMode == 'Model' && (set.field == 'parameterid' || set.field == 'remark' || set.field == 'uid'))
        {
            col.setAttribute("class", "over_content");
            switch (set.field) {
                case "ulma":
                    col.textContent = transServerAddressData("view", parseInt(param["serverfunctioncode"])) + param["serveraddress"];
                    break;
                case "dlma":
                    col.textContent = transAddressData("view", parseInt(param["functioncode"])) + param["address"];
                    break;
                case "uid":
                    col.textContent = param[set.field];
                    break;
                default:
                    col.textContent = param[set.field];
            }
            col.setAttribute("title", col.textContent);
        }
        else
        {
            switch (set.field) {
                case 'uid':
                    col.textContent = param[set.field];
                    break;
                default:
                    CreateControl(col, set, param);
            }
        }

    });

}

function CreateControl(col, set, param)
{
    let input;
    switch (set.type) {
        case 'input':
            input = document.createElement("input");
            input.setAttribute("type", "text");

            if (set.field == "parameterid")
                input.setAttribute("maxlength", "3");

            if (set.default != null)
                input.value = set.default;

            if (param != null) {
                switch (set.field) {
                    case "ulma":
                        if (param["serverfunctioncode"] != null)
                            input.value = transServerAddressData("view", parseInt(param["serverfunctioncode"])) + param["serveraddress"];
                        break;
                    case "dlma":
                        if (param["functioncode"] != null)
                            input.value = transAddressData("view", parseInt(param["functioncode"])) + param["address"];
                        break;
                    default:
                        if (param[set.field] != '')
                            input.value = param[set.field];
                }
            }

            col.appendChild(input);
            break;
        case 'select':
            input = document.createElement("select");

            switch (set.field) {
                case "scaletype":
                    input.style.width = "80px";
                    break;
            }

            col.appendChild(input);

            $.each(set.data, (index, item) => {
                option = document.createElement("option");
                option.value = index;
                option.textContent = item;

                if (param != null)
                {
                    if (index == param[set.field]) {
                        option.setAttribute("selected", "selected");
                    }
                }
                else
                {
                    if (set.default != null && set.default == index) {
                        option.setAttribute("selected", "selected");
                    }
                }

                input.appendChild(option);
            });
            break;
    }

}

function CreateFootData()
{
    let foot = $("#ui_svid_param tfoot")[0];

    let tr = document.createElement("tr");
    foot.appendChild(tr);

    let td = document.createElement("td");
    td.setAttribute("class", "tfootAction");
    tr.appendChild(td);

}

function ShowDefSvid()
{
    let row, col, tag_i;

    //Head
    let head = document.getElementById("ui_def_svid_head");
    $(head).children().remove();
    row = document.createElement("tr");
    head.appendChild(row);

    col = document.createElement("th");
    row.appendChild(col);

    $.each(glDefFields, (idx, set) => {
        col = document.createElement("th");
        col.textContent = set.title;
        row.appendChild(col);
    });

    //Body
    let body = document.getElementById("ui_def_svid_body");
    $(body).children().remove();

    $.each(glDevDefSvidData, (idx, val) => {

        if (val == undefined)
            return;

        //Action Field
        row = document.createElement("tr");
        row.setAttribute("data-key", val.uid);
        body.appendChild(row);

        col = document.createElement("td");
        row.appendChild(col);

        tag_i = document.createElement("i");
        tag_i.setAttribute("class", "fa fa-arrow-circle-left");
        tag_i.setAttribute("title", "Insert");
        col.appendChild(tag_i);

        //Data Fields
        $.each(glDefFields, (idx, set) => {
            col = document.createElement("td");
            col.textContent = val[set.field];
            row.appendChild(col);
        });

    })
}

function saveSvid(name)
{
    let errMsg = CheckFieldNull();
    if (errMsg != '') {
        alert(errMsg);
        return false;
    }

    let fileName = $('#ui_dev').val();
    if (name != undefined && name != '')
        fileName = name;
    let datas = {};

    console.log(glMode);

    switch (glMode) {
        case "Model":
            datas = CollectDataByModel();
            break;
        case "Edit":
            datas = CollectDataByEdit();
            break;
    }
    console.log(JSON.stringify(datas));
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/devsvid.php",
        data: {'func': 'savesvid', 'filename': fileName, 'data': JSON.stringify(datas)},
        success: function ( json ) {

            targetURL = gl_target_server + "/php/export.php";
            var e = $.getJSON(targetURL, "getorigincsv=1", data => {
                console.log(data);
            })
            .success(() => {

            })
            .error(err => {
                console.log("err=>" + err.toString());
            })

            alert("存檔成功！");
            $('#ui_dev').children().remove();
            $('#ui_saveas').val('');
            glFinsFieldShow = false;
            glModbusFieldShow = false;
            Load_Svid_Param_Map();
            SelectedDevinfo();
        },
        error: function (err) {
            console.log(err);
        }
    } );
}
function containsSpecialCharacters(fileName) {
    // 定義要檢查的特殊字符
    const specialChars = /[/\\?#%]/;
    // 使用 test 方法檢查字串是否包含特殊字符
    return specialChars.test(fileName);
  }

function saveasSvid()
{
    let fileName = $("#ui_saveas").val();
    if (fileName === undefined || fileName === '')
        alert('請輸入新檔名！');
    else if(containsSpecialCharacters(fileName)){
        alert('檔名不能包含'+'/[/\\?#%]/');
    }
    else {
        let isRep = false;
        Object.keys(glSvidSamples).forEach((k, v) => {
            if (k == fileName) {
                alert("範本名稱已存在，請重新設定！")
                isRep = true;
            }
        });

        if (!isRep)
            saveSvid(fileName);
    }
}

function delSvidModel()
{
    if (confirm(`是否確定要刪除 [${glCurSvidSample}] Model Map?`))
    {
        $.ajax( {
            method: "POST",
            dataType: 'json',
            url: gl_target_server + '/php/devsvid.php',
            data: {'func': 'delSvidModel', 'modelname': `${glCurSvidSample}`},
            success: function (json) {
                alert("刪除成功！");
                $('#ui_dev').children().remove();
                $('#ui_saveas').val('');
                Load_Svid_Param_Map();
                SelectedDevinfo();
            },
            error: function (err) {
                alert("刪除失敗！");
                console.log(err);
            }
        });
    }
}

function CheckFieldNull()
{
    let errMsg = '';
    let set = glFields.filter(f => {
        return f.notnull != undefined && f.notnull == "1";
    });

    $.each(set, (idx, s) => {
        if ($(`td[data-field='${s.field}']`).css("display") != "none") {
            if ($(`td[data-field='${s.field}'] input`).length > 0) {
                if ($(`td[data-field='${s.field}'] input`).val() == '') {
                    errMsg = `[${s.title}] 不可空白！`;
                    return false;
                }
            }
        }
    });
    return errMsg;
}

function CollectDataByModel()
{
    let datas = {};
    let content = '';

    $('#ui_svid_body tr').each((idx, tr) => {
        let key = "";
        let param = {};
        
        $(tr).children().each((i, td) => {

            if ($(td).attr('data-field') == undefined)
                return;

            content = td.textContent;
            if ($(td).attr('data-field') == "uid"){
                key = content;
            }
            switch ($(td).attr('data-field')) {
                case "ulma":
                    param["serverfunctioncode"] = transServerAddressData("save", parseInt($(td).children()[0].value[0]));
                    param["serveraddress"] = $(td).children()[0].value.substr(1);
                    break;
                case "dlma":
                    param["functioncode"] = transAddressData("save", parseInt($(td).children()[0].value[0]));
                    param["address"] = $(td).children()[0].value.substr(1);
                    break;
                case "uid":
                case "parameterid":
                case "remark":
                    param[$(td).attr('data-field')] = content;
                    break;
                default:
                    param[$(td).attr('data-field')] = $(td).children()[0].value;
            }

        });
       datas[key] = [];
       datas[key].push(param);
    });
    return datas;
}

function CollectDataByEdit()
{
    let datas = {};

    $('#ui_svid_body tr').each((idx, tr) => {
        let key = "";
        let param = {};
        $(tr).children().each((i, td) => {

            if ($(td).attr('data-field') == "uid")
                key = $(td).children()[0].value;

            switch ($(td).attr('data-field')) {
                case "ulma":
                    param["serverfunctioncode"] = transServerAddressData("save", parseInt($(td).children()[0].value[0]));
                    param["serveraddress"] = $(td).children()[0].value.substr(1);
                    break;
                case "dlma":
                    param["functioncode"] = transAddressData("save", parseInt($(td).children()[0].value[0]));
                    param["address"] = $(td).children()[0].value.substr(1);
                    break;
                default:
                    param[$(td).attr('data-field')] = $(td).children()[0].value;
            }
        });
        datas[key] = [];
        datas[key].push(param);
    });
    return datas;
}

function ShowTargetMapFile()
{
    $("#section_group_edit.box-header").hide();
    $("#svid_title, #svid_header").hide();
    SelectedDevinfo();

    let div = $("#ui_new_mapfile_name")[0];

    let lbl = document.createElement("label");
    lbl.textContent = "MapFile Name：";
    div.appendChild(lbl);

    let input = document.createElement("input");
    input.setAttribute("type", "text");
    input.id = "ui_saveas";
    input.style.width = "80%";

    if ($(parent.glTargetSelect).find(":selected").attr("data-add") == "1")
        input.value = $(parent.glTargetSelect).find(":selected").val();
    else
        input.value = `${moment().format("YYYYMMDDHHmmss")}_${glMapFile}`;
    div.appendChild(input);

    let tfoot = $("#ui_svid_param tfoot")[0];
    $(tfoot).children().remove();

}

function CheckContentDiff()
{
    $('#ui_svid_body input').each((idx, ctrl) => {
        let tr = $(ctrl).closest("tr")[0];
        let td = $(ctrl).closest("td")[0];
        let def = td.dataset['defdata'];
        let field = td.dataset['field'];
        let val = $(ctrl).val();

        if (field == "tagname")
            return;
        else if (tr.classList.contains("only_dev_svid"))
            return;

        if (glMode != 'Model') {
            if (val != def)
                td.classList.add("diff_dev_svid");
            else
                td.classList.remove("diff_dev_svid");
        }
    })
}

function add_svid()
{
    let body = document.getElementById("ui_svid_body");
    createDataRow(body);
}

function ShowMore(e, cls)
{
    // $(e).hide();
    switch (cls) {
        case 'fins':
            $("th[data-field='mergemode'], td[data-field='mergemode']").toggle();
            glFinsFieldShow = !glFinsFieldShow;
            break;
        case 'modbus':
            $("th[data-field='ulma'], td[data-field='ulma']").toggle();
            $("th[data-field='dlma'], td[data-field='dlma']").toggle();
            $("th[data-field='readfreq'], td[data-field='readfreq']").toggle();
            $("th[data-field='startbit'], td[data-field='startbit']").toggle();
            $("th[data-field='endbit'], td[data-field='endbit']").toggle();
            $("th[data-field='num'], td[data-field='num']").toggle();
            $("th[data-field='signed'], td[data-field='signed']").toggle();
            $("th[data-field='endian'], td[data-field='endian']").toggle();
            $("th[data-field='valuetype'], td[data-field='valuetype']").toggle();
            $("th[data-field='intnum'], td[data-field='intnum']").toggle();
            glModbusFieldShow = !glModbusFieldShow
            break;
    }
}

$(document).ready(() => {

    $("#ui_svid_body").on("blur", "td[data-field='parameterid'] input", e => {
        let tr = $(e.currentTarget).closest("tr")[0];
        let val = e.currentTarget.value;
        let isRep = false;

        for (var i = 0; i < 3 - val.length; i++) {
            e.currentTarget.value = "0" + e.currentTarget.value;
        }

        $("#ui_svid_body td[data-field='parameterid']").each((idx, td) => {
            let curTr = $(td).closest("tr")[0];
            let curVal = $(td).children()[0].value;
            if (tr.rowIndex == curTr.rowIndex)
                return;

            if (val == parseInt(curVal))
            {
                alert(`Parameterid [${curVal}] 已存在!`)
                isRep = true;
                return false;
            }
        })

        if (isRep)
        {
            e.currentTarget.value = "";
        }
        else
        {
            let remark = $(tr).find("td[data-field=remark]")[0].children[0];
            $(remark).val(svid_map[e.currentTarget.value]);
        }

    }).on("click", ".fa-trash-o", e => {
        let tr = $(e.currentTarget).closest("tr")[0];
        tr.remove();
    }).on("change", "input, select", e => {
        CheckContentDiff();
    });

    $("#ui_def_svid_body").on("click", ".fa-arrow-circle-left", e => {
        let key = $(e.currentTarget).closest("tr")[0].dataset["key"];
        let isRep = false;

        $("#ui_svid_body td[data-field=uid]").each((idx, td) => {
            if ($(td).text() == key)
            {
                alert("該Parameter已存在！");
                isRep = true;
                return false;
            }
        })

        if (!isRep)
        {
            let body = document.getElementById("ui_svid_body");
            let data = glDevDefSvidData.filter(v => {
                return v.uid == key;
            })[0];
            createDataRow(body, data);
        }
    });

})

  function readCsv() {
    const file = $("#uploadFile")[0].files[0];
    if (file.type != "text/csv") {
      alert("文件類型錯誤");
      return;
    }
    var reader = new FileReader();
    const data = [];

    reader.onload = function () {
      const result = reader.result;
      console.log(result);
      //let lines = result.split("\r\n");
      let lines = result.split("\n");
      //console.log(lines[0]);
      var title=lines[0].split(",");
      lines.map(function (item, index) {

        if(index===0)
            return;
        var line = item.split(",");

        const data1 = {};
        line.forEach(function(element, index, array) { 
            if(index==3){
                if (line[index].length < 3) {
                    line[index] = '0'.repeat(3 - line[index].length) + line[index];
                }
            }
            data1[title[index]]=line[index]
        });
        if(data1.id=='')
            return;
        data.push(data1);
       
      });
      console.log(data);
      let body = document.getElementById("ui_svid_body");
      $.each(data, (idx, param) => {
        if (param === undefined)
            return;
        createDataRow(body, param);
    })
    };
    reader.readAsText(file);
  }
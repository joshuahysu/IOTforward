var gl_system_time;
var gl_system_cpu;
var gl_system_ram;

load_system_info();
load_system_time();
show_devinfo();
function show_account()
{
    document.getElementById('contentIframe').src = "/index.php/account";
    show_treeview('system');
}

function show_config()
{
    document.getElementById('contentIframe').src = "/index.php/setconfig";
    show_treeview('system');
}

function show_defsvid()
{
    document.getElementById('contentIframe').src = "/index.php/defsvid";
    show_treeview('device');
}

function show_devtypes()
{
    document.getElementById('contentIframe').src = "/index.php/devtypes";
    show_treeview('device');
}

function show_devinfo()
{
    document.getElementById('contentIframe').src = "/index.php/devinfo";
    show_treeview('device');
}

function show_systemImport()
{
    document.getElementById('contentIframe').src = "/index.php/systemImport";
    show_treeview('device');
}

function show_devsvid()
{
    document.getElementById("contentIframe").src = "/index.php/devsvid";
    show_treeview('device');
}

function show_datamonitor()
{
    document.getElementById("contentIframe").src = "/index.php/datamonitoring";
    show_treeview('log');
}

function show_filesystem()
{
    document.getElementById("contentIframe").src = "/index.php/filesystem";
    show_treeview('log');
}

function show_datamonitorModbus()
{
    document.getElementById("contentIframe").src = "/index.php/datamonitorModbus";
    show_treeview('log');
}

function show_service_monitor()
{
    document.getElementById("contentIframe").src = "/index.php/servicemonitor";
    show_treeview('log');
}

function show_eventlog()
{
    document.getElementById("contentIframe").src = "/index.php/eventlog";
    show_treeview('log');
}

function show_treeview(type)
{
    $('.treeview').removeClass('active');

    switch (type) {
        case 'system':
            document.getElementById('treeview_system').classList.add('active');
            break;
        case 'device':
            document.getElementById('treeview_device').classList.add('active');
            break;
        case 'log':
            document.getElementById('treeview_log').classList.add('active');
            break;
    }

    document.getElementById("main_left_frame").setAttribute("class","col-md-12 col-sm-12");

}

function send_pushnotification(projectid, nodeid, title, message)
{
    document.getElementById('contentIframe').src = "/index.php/vilspushnotification/"+project_id+"?nodeid="+nodeid+"&title="+title+"&message="+message;
    show_treeview('pushnotification');
}

function update_system_time()
{
    gl_system_time.add(1, 'seconds');
    document.getElementById("system_time").innerHTML = gl_system_time.format('YYYY/MM/DD HH:mm:ss');

    setTimeout(update_system_time, 1000);
}

function load_system_time() {
    var targetURL = gl_target_server + "/php/pkgversion.php";
    $.getJSON(targetURL, 'fun=fetchsystemtime', function(data)
    {
        gl_system_time = moment(data.systime);
        document.getElementById("system_time").innerHTML = gl_system_time.format('YYYY/MM/DD HH:mm:ss');

    }).complete(function() {
        setTimeout(update_system_time, 1000);
    });
}

function load_system_info()
{
    var targetURL = gl_target_server + "/php/pkgversion.php";
    $.getJSON(targetURL, 'fun=pcinfo', function(data)
    {

        gl_system_cpu = data.cpu;
        document.getElementById("system_cpu").innerHTML = gl_system_cpu;

        gl_system_ram = data.ram;
        document.getElementById("system_ram").innerHTML = gl_system_ram;

    }).complete(function() {
        setTimeout(load_system_info, 1000);
    });
}

function full_csv_export() {
    var targetURL = gl_target_server + "/php/export.php";
    $.getJSON(targetURL, 'full=1', data => {
        console.log(data);
    }).complete(() => {
        alert('匯出完畢！');
    }).fail((jqXHR, textStatus, errorThrown) => {
        console.error('Error: ' + textStatus, errorThrown);
    })

    
}

function system_start_vils()
{
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/config.php",
        data: {'func': 'startdevsystem'},
        success: function(json) {
            hideLoadingOverlay();
            alert('啟動完成！');
        },
        error: function (err) {
            alert('啟動失敗！');
            // console.log(err);
        }
    } );

}

var _loadingHtml=''

function showLoadingOverlay() {
    document.getElementById('loadingOverlay').style.display = 'flex';
  }

  function hideLoadingOverlay() {
    document.getElementById('loadingOverlay').style.display = 'none';
  }



function full_csv_export_reboot()
{
    if (confirm("是否確定停止服務？"))
    {
        showLoadingOverlay();
        //1.關閉程式
        $.ajax( {
            method: "POST",
            dataType: 'json',
            url: gl_target_server + "/php/config.php",
            data: {'func': 'stopdevsystem'},
            success: function(json) {           
                //2.程式關閉成功後輸出excel      
                var targetURL = gl_target_server + "/php/export.php";
                $.getJSON(targetURL, 'full=1', data => {
                    console.log(data);
                    //3.程式重啟
                    system_start_vils();
                }).complete(() => {

                }).error(err => {
                    console.log(err);
                })
            },
            error: function (err) {
                alert('停止失敗！');

            }
        });

    }
}

var refreshSession = function ()
{
    var targetURL = gl_target_server + "/php/refresh_session.php";

    var time = 600000; // 10 mins
    setTimeout(function (){
        $.ajax({
               url: targetURL,
               cache: false,
               complete: function () {refreshSession();}
            });
        },
        time
    );
};

// Call in page
// refreshSession();

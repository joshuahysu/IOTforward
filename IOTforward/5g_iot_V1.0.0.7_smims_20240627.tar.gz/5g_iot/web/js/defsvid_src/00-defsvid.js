
// 點擊按鈕時下載
const btn = document.getElementById('download');
btn.addEventListener('click', () => {
try {
    DownLoadSvidData(); 
} catch(err) {
    window.alert(err)
} 
})

var glSvidDatas = [];
let glFields = [
    { "title": "UID", "key": "uid", "data": [], "type": "td", "field": "uid", "framestyle": "max-width:50px;width:50px;" },
    { "title": "SVID_ParaID", "key": "parameterid", "data": [], "type": "input", "field": "parameterid", "framestyle": "max-width:130px;width:130px;" },
    { "title": "Parameter", "key": "remark", "data": [], "type": "input", "field": "remark", "framestyle": "max-width:135px;width:135px;" },
    { "title": "Category", "key": "remark", "data": [], "type": "input", "field": "category", "framestyle": "max-width:135px;width:135px;", "ishide": "1" },
    //{"title":"Scale Type", "key":"scaletype", "data":scaleType_map, "type":"select", "field":"scaletype", "framestyle":"max-width:95px;width:95px;"},
    // {"title":"X", "key":"scalemultiple", "data":[], "type":"input", "field":"scalemultiple", "framestyle":"max-width:100px;width:100px;"},
    // {"title":"＋", "key":"scaleoffset", "data":[], "type":"input", "field":"scaleoffset", "framestyle":"max-width:100px;width:100px;"},
    // {"title":"單位", "key":"unit", "data":[], "type":"input", "field":"unit", "framestyle":"max-width:50px;width:50px;"},
    // {"title":"Max", "key":"max", "data":[], "type":"input", "field":"max", "framestyle":"max-width:50px;width:50px;"},
    // {"title":"Min", "key":"min", "data":[], "type":"input", "field":"min", "framestyle":"max-width:50px;width:50px;"},
    // {"title":"小數位", "key":"fixed", "data":[], "type":"input", "field":"fixed", "framestyle":"max-width:50px;width:50px;"},
    // {"title":"Modbus Slave Address", "key":"ulma", "data":[], "type":"input", "field":"ulma", "framestyle":"max-width:120px;width:120px;"},
    // {"title":"Modbus Master Address", "key":"dlma", "data":[], "type":"input", "field":"dlma", "framestyle":"max-width:120px;width:120px;", "ishide":"1"},
    // {"title":"ReadFreq", "key":"readfreq", "data":[], "type":"input", "field":"readfreq", "framestyle":"max-width:50px;width:50px;"},
    // {"title":"Num", "key":"num", "data":[], "type":"input", "field":"num", "framestyle":"max-width:50px;width:50px;"},
    // {"title":"Signed", "key":"signed", "data":signed_map, "type":"select", "field":"signed", "framestyle":"max-width:50px;width:50px;"}
];

QuerySvidData();

function QuerySvidData() {
    let targetURL = gl_target_server + "/php/defsvid.php";
    glSvidDatas = [];
    let p = $.getJSON(targetURL, "querydefsvid=1", data => {
        $.each(data, (index, item) => {
            glSvidDatas[item.id] = item;
        })
    })
        .success(() => {
            SetSvidHeadRows();
            SetSvidDataRows();
        })
        .error(err => {
            console.log(err);
        })
}

function SetSvidHeadRows() {
    let head = document.getElementById("svid_head");
    $(head).children().remove();

    let row = document.createElement("tr");
    head.appendChild(row);

    let col;

    //Action field
    col = document.createElement("th");
    row.appendChild(col);

    $.each(glFields, (idx, data) => {
        col = document.createElement("th");
        col.textContent = data.title;
        if (data.framestyle != undefined)
            col.setAttribute("style", data.framestyle);
        if (data.ishide != undefined)
            col.style.display = "none";
        row.appendChild(col);
    });
}

function SetSvidDataRows() {
    let tbody = document.getElementById("svid_body");
    $(tbody).children().remove();
    let tr;

    $.each(glSvidDatas, (idx, data) => {

        if (data == undefined)
            return;

        tr = document.createElement("tr");
        tr.setAttribute("data-key", data["id"]);
        tbody.appendChild(tr);

        SetSvidDataRow(tr, data);

    })
}

function SetSvidDataRow(tr, data) {
    let td, tag_i;

    td = document.createElement("td");
    tr.appendChild(td);

    tag_i = document.createElement("i");
    tag_i.setAttribute("class", "fa fa-edit");
    tag_i.setAttribute("title", "edit");
    td.appendChild(tag_i);

    tag_i = document.createElement("i");
    tag_i.setAttribute("class", "fa fa-trash-o");
    tag_i.setAttribute("title", "delete");
    td.appendChild(tag_i);

    $.each(glFields, (idx, fd) => {
        let val = '';
        td = document.createElement("td");
        td.setAttribute("class", "over_content");
        td.setAttribute("data-field", fd.field);
        if (fd.framestyle != undefined)
            td.setAttribute("style", fd.framestyle);
        if (fd.ishide != undefined)
            td.style.display = "none";
        switch (fd.field) {
            case "scaletype":
                td.textContent = fd.data[data[fd.field]];
                td.setAttribute("data-key", data[fd.field]);
                break;
            case "ulma":
                val = transServerAddressData("view", parseInt(data["serverfunctioncode"]));
                td.textContent = val + data["serveraddress"];
                td.setAttribute("data-key", data[fd.field]);
                break;
            case "dlma":
                val = transAddressData("view", parseInt(data["functioncode"]));
                td.textContent = val + data["address"];
                td.setAttribute("data-key", data[fd]);
                break;
            default:
                td.textContent = data[fd.field];
                break;
        }
        td.setAttribute("title", td.textContent);
        tr.appendChild(td);
    })

}

function createNewRow(key) {
    let dialogBody = document.getElementById("svid_body");
    let row, col, lbl, input, img, option;
    let data;

    if (key != undefined && key != '') {
        data = glSvidDatas[key];
        row = $(`tr[data-key=${key}]`)[0];
        row.classList.add("editrow");
        $(row).children().remove();
    } else {
        row = document.createElement("tr");
        row.classList.add("newrow");
        dialogBody.appendChild(row);
    }

    //Action Field
    col = document.createElement("td");
    row.appendChild(col);

    img = document.createElement('i');
    img.classList.add('fa');

    if (data != null) {
        img.classList.add('fa-reply');
        img.setAttribute("title", "cancel");
    } else {
        img.classList.add('fa-trash-o');
    }
    col.appendChild(img);

    //Data Field
    $.each(glFields, (idx, set) => {

        col = document.createElement("td");
        col.setAttribute("data-ctrltype", set.type);
        col.setAttribute("data-field", set.field);

        if (set.ishide != undefined)
            col.style.display = "none";

        row.appendChild(col);

        switch (set.type) {
            case "input":
                input = document.createElement("input");
                input.setAttribute("type", "text");
                input.setAttribute("class", `ui_${set.field}`);

                if (set.style != '')
                    input.setAttribute("style", set.style);

                if (set.field == 'parameterid')
                    input.setAttribute("maxlength", "3");

                if (data != null) {
                    switch (set.field) {
                        case "ulma":
                            val = parseInt(data["serverfunctioncode"]);
                            val = transServerAddressData("view", val);
                            input.value = val + data["serveraddress"];
                            break;
                        case "dlma":
                            val = parseInt(data["functioncode"]);
                            val = transAddressData("view", val);
                            input.value = val + data["address"];
                            break;
                        default:
                            input.value = data[set.field];
                    }
                }
                col.appendChild(input);

                break;
            case "select":
                input = document.createElement("select");
                // input.setAttribute("class", "col-md-7");

                if (set.style != '')
                    input.setAttribute("style", set.style);
                col.appendChild(input);

                $.each(set.data, (index, item) => {
                    option = document.createElement("option");
                    option.value = index;
                    option.textContent = item;

                    if (data != null && index.toString() == data[set.field]) {
                        option.setAttribute("selected", "selected");
                    }
                    input.appendChild(option);
                });
                break;
        }

    });
    LastUID();
    //ResetUID();
    $("#btn_save").show();

}



function SaveSvidData() {

    // if ($('#svid_body .errorInput').length > 0) {
    //     alert('SVID_ParaID重複！');
    //     return false;
    // }

    let count = $(".newrow,.editrow").length;
    let dialogBody = document.getElementById("svid_body");
    let aryNewDatas = {};
    let item = {};
    let row, col;

    aryNewDatas['new'] = [];
    aryNewDatas["edit"] = [];
    aryNewDatas["uid"] = [];

    $(".newrow").each((idxr, row) => {
        item = {};
        $(row).children().each((idxc, col) => {
            let type = $(col).data("ctrltype");
            let field = $(col).data("field");
            if (type == "img")
                return;

            switch (field) {
                case "ulma":
                    val = parseInt($($(col).children()).val()[0]);
                    let svfncode = transServerAddressData("save", val);
                    item["serverfunctioncode"] = svfncode;
                    item["serveraddress"] = $($(col).children()).val().substr(1);
                    break;
                case "dlma":
                    val = parseInt($($(col).children()).val()[0]);
                    let fncode = transAddressData("save", val);
                    item["functioncode"] = fncode;
                    item["address"] = $($(col).children()).val().substr(1);
                    break;
                case "uid":
                    item[field] = $(col).html();
                    break;
                default:
                    item[field] = $($(col).children()).val();
            }

        });
        aryNewDatas['new'].push(item);
    });

    $(".editrow").each((idxr, row) => {
        item = {};
        $(row).children().each((idxc, col) => {
            let type = $(col).data("ctrltype");
            let field = $(col).data("field");
            let val = "";
            if (type == "img")
                return;

            switch (field) {
                case "ulma":
                    val = parseInt($($(col).children()).val()[0]);
                    let svfncode = transServerAddressData("save", val);
                    item["serverfunctioncode"] = svfncode;
                    item["serveraddress"] = $($(col).children()).val().substr(1);
                    break;
                case "dlma":
                    val = parseInt($($(col).children()).val()[0]);
                    let fncode = transAddressData("save", val);
                    item["functioncode"] = fncode;
                    item["address"] = $($(col).children()).val().substr(1);
                    break;
                case "uid":
                    item[field] = $(col).html();
                    break;
                default:
                    item[field] = $($(col).children()).val();
            }

        })
        item['id'] = $(row).data("key");
        item['uid']=glSvidDatas[item['id']].uid
 
        aryNewDatas['edit'].push(item);
    })

    let uids = {};
    $('#svid_body tr td[data-field="uid"]').each((idx, td) => {
        let key = $(td).closest('tr')[0].dataset["key"];
        if(glSvidDatas[key]!=undefined){
        uids[key] =glSvidDatas[key].uid}
        else{
        uids[key] = td.textContent;}
    });
    aryNewDatas["uid"] = uids;

    console.log(JSON.stringify(aryNewDatas));

    $.ajax({
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/defsvid.php",
        data: { 'func': 'savedefsvid', 'data': JSON.stringify(aryNewDatas) },
        success: function (json) {
            alert("存檔成功！");
            $("#btn_save").hide();
            QuerySvidData();
        },
        error: function (err) {
            console.log(err);
        }
    });

}

function changetrmode(tr, type) {
    let key = $(tr).data('key');
    let data = glSvidDatas[key];

    switch (type) {
        case "edit":
            createNewRow(key);
            break;
        case "view":
            $(tr).children().remove();
            SetSvidDataRow(tr, data);
            break;
    }
}

function ResetUID() {
    let tbody = document.getElementById("svid_body");
    for (var i = 0; i < tbody.children.length; i++) {
        let tr = tbody.children[i];
        let td = tr.children[1];
        td.textContent = i + 1;
    }
}
function LastUID() {
    let tbody = document.getElementById("svid_body");
        let tr = tbody.children[tbody.children.length-1];
        let td = tr.children[1];
        td.textContent = parseInt(tbody.children[tbody.children.length-2].children[1].textContent) + 1;
    
}

$(document).ready(function () {

    $("#svid_body").on("click", ".fa-trash-o", e => {
        let row = $(e.currentTarget).closest("tr")[0];
        if ($(row).attr("class") == "newrow") {
            $(row).remove();
        }
        else {
            if (confirm("是否確定刪除？")) {
                let tr = $(e.currentTarget).parents("tr")[0];
                let key = $(tr).data('key');
                let targetURL = gl_target_server + "/php/defsvid.php";
                $.getJSON(targetURL, "deletedefsvid=1&setkey=" + key, data => {
                    console.log(data);
                })
                    .success(() => {
                        $(tr).remove();
                        $("#btn_save").hide();
                        alert('刪除成功！');
                        QuerySvidData();
                        ResetUID();
                    })
                    .error(err => {
                        console.log(`err=>${err}`);
                    })
            }
        }
    }).on("click", ".fa-edit", e => {
        let tr = $(e.currentTarget).parents("tr")[0];
        changetrmode(tr, "edit");
        $("#btn_save").show();
    }).on("click", ".fa-reply", e => {
        let tr = $(e.currentTarget).parents("tr")[0];
        $(tr).removeClass("editrow");
        changetrmode(tr, "view");
    })

    $("#svid_body").on("blur", ".ui_parameterid", e => {
        let val = e.currentTarget.value;
        let trIdx = $(e.currentTarget).closest("tr")[0].rowIndex;
        let isRep = false;
        e.currentTarget.classList.remove("errorInput");
        for (var i = 0; i < 3 - val.length; i++) {
            e.currentTarget.value = "0" + e.currentTarget.value;
        }

    })
})

function DownLoadSvidData() {
    let targetURL = gl_target_server + "/php/defsvid.php";
  
    let p = $.getJSON(targetURL, "querydefsvid=1", data => {
    })
        .success((data) => {
        let svidDatas=[];
  
      $.each(data, (index, item) => {
        //newItem客製自訂格式
        //console.log(item);
        let newItem={
            id:(item['id'] !== null) ? item['id'].toString() : "",
            uid:(item['uid'] !== null) ? item['uid'].toString() : "",
            class:item['class']||"",
            parameterid:item['parameterid']||"",
            remark:item['remark']||"",
            category:item['category']||"",
            tagname:item['tagname']||"",
            serveraddress:item['serveraddress']||"",
            serverfunctioncode:item['serverfunctioncode']||"",
            address:item['address']||"",
            startbit:item['startbit']||"",
            endbit:item['endbit']||"",
            num:item['num']||"",
            readfreq:item['readfreq']||"",
            functioncode:item['functioncode']||"",
            scaletype:item['scaletype']||"",
            scalemultiple:item['scalemultiple']||"",
            scaleoffset:item['scaleoffset']||"",
            unit:item['unit']||"",
            max:(item['max'] !== null) ? item['max'].toString() : "",
            min:(item['min'] !== null) ? item['min'].toString() : "",
            signed:item['signed']||"",
            fixed:item['fixed']||"",
            mergemode:(item['mergemode'] !== null) ? item['mergemode'].toString() : "",
            'private':(item['private'] !== null) ? item['private'].toString() : ""
          }
          //console.log(newItem);
        svidDatas.push(newItem); 
      })

        buildData(svidDatas)
        .then(svidDatas => {downloadCSV(svidDatas,"defsvid")
        }       
        )
        .catch(err => window.alert(err));
        }       
        )
        .error(err => {
            console.log(err);
        })
  }

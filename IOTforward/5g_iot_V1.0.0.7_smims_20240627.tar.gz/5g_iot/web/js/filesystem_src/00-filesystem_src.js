dataSet=[];
table =null;
let targetURL = gl_target_server + "/php/filesystem.php";

const columnTitles = [
    { title: 'File name',className: 'dt-left' },
    { title: 'download', className: 'dt-right' },  
];

const searchInputs = $('#fileTable thead tr:eq(1)').html();

   // 初始化和重新加载表格的函数
   function initializeTable(data) {

    // 初始化 DataTable
    table = new DataTable('#fileTable', {
        columns: columnTitles,
        data: data,        
        order: [[4, 'asc']], // 默认按第5列（Modbus Slave Address）升序排序
        pageLength: 30, // 默认显示 30行,
        dom: 'rtip', // 隐藏 lengthMenu 控件，保留其他控件 (l: lengthMenu, r: processing, t: table, i: info, p: pagination)  
        initComplete: function () {
            $('#fileTable thead tr:eq(1)').html(searchInputs);
           // 重新绑定事件监听器
           bindSearchEventListeners();
        }
    });
}

// 初次初始化表格
initializeTable(dataSet);
getLogfiles();
    // 绑定搜索事件监听器
    function bindSearchEventListeners() {
        $('#fileTable').on('keyup change clear', 'thead input', function() {
            const columnIdx = $(this).closest('th').index();
            const table = $('#fileTable').DataTable();
            if (table.column(columnIdx).search() !== this.value) {
                table
                    .column(columnIdx)
                    .search(this.value)
                    .draw();
            }
        });
    }
    function getLogfiles()
    {
        dataTableArray=[];
        let p = $.getJSON(targetURL, "getLogfiles=1")
        .done(data => {
            $.each(data, (key, param) => {
                tempArray = [];
                tempArray.push(param[0]);//名稱
                tempArray.push(param[1]); 
                dataTableArray.push(tempArray);
            });

            reloadDataTable(dataTableArray);
        })
        .fail((jqXHR, textStatus, errorThrown) => {
            console.error('getJSON request failed: ' + textStatus, errorThrown);
        });
    }

    // 定义一个函数，用于重新加载 DataTable 的数据
    function reloadDataTable(newData) {
        // 保存当前页数
        var currentPage = table.page();

        // 清空现有数据
        //table.clear().destroy();
        table.clear();
        // // 添加新数据并绘制表格
        table.rows.add(newData).draw();

        //$('#monitorTable').DataTable().clear().destroy(); // 清除和销毁旧的DataTable实例
        //initializeTable(newData); // 重新初始化表格

        // 跳转回之前记录的页数
        table.page(currentPage).draw(false);
    }

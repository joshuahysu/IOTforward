let targetURL = gl_target_server + "/php/datamonitorModbus.php";
dataSet=[];
let dataTableArray = [];
table =null;

const columnTitles = [
    { title: 'Modbus Slave value', className: 'dt-right' },
    { title: 'SVID_ParaID', className: 'dt-right' },
    { title: 'Parameter', className: 'dt-right' },
    { title: '原廠參數名稱/fins點位', className: 'dt-right' },
    { title: 'Modbus Slave Address', className: 'dt-right SlaveAddress' },
    { title: 'Modbus Master Address', className: 'dt-right' },
    { title: 'startbit', className: 'dt-right' },
    { title: 'endbit', className: 'dt-right' }    
];

const searchInputs = $('#monitorTable thead tr:eq(1)').html();

   // 初始化和重新加载表格的函数
   function initializeTable(data) {

    // 初始化 DataTable
    table = new DataTable('#monitorTable', {
        columns: columnTitles,
        data: data,
        order: [[4, 'asc']], // 默认按第5列（Modbus Slave Address）升序排序
        pageLength: 30, // 默认显示 30行,
        dom: 'rtip', // 隐藏 lengthMenu 控件，保留其他控件 (l: lengthMenu, r: processing, t: table, i: info, p: pagination)  
        initComplete: function () {
            $('#monitorTable thead tr:eq(1)').html(searchInputs);
           // 重新绑定事件监听器
           bindSearchEventListeners();
        }
    });
}

// 初次初始化表格
initializeTable(dataSet);

    // 绑定搜索事件监听器
    function bindSearchEventListeners() {
        $('#monitorTable').on('keyup change clear', 'thead input', function() {
            const columnIdx = $(this).closest('th').index();
            const table = $('#monitorTable').DataTable();
            if (table.column(columnIdx).search() !== this.value) {
                table
                    .column(columnIdx)
                    .search(this.value)
                    .draw();
            }
        });
    }

LoadDevinfo()

function LoadDevinfo(val)
{
    glDevinfo=[];
    let p = $.getJSON(targetURL, "loaddevinfo=1&key=" + val)
    .done(data => {
        $.each(data, (idx, info) => {
            glDevinfo[info.chamberid] = info;
        });
        SetDevInfos();
    })
    .fail((jqXHR, textStatus, errorThrown) => {
        console.error('getJSON request failed: ' + textStatus, errorThrown);
    });
}
function SetDevInfos() {
    let sel = document.getElementById("ui_dev");
    let option;

    $(sel).children().remove();

    option = document.createElement("option");
    option.textContent = "None";
    sel.appendChild(option);

    Object.keys(glDevinfo).forEach((key) => {
        option = document.createElement("option");
        option.value = key;
        option.textContent = `${key} ${glDevinfo[key].deviceip} ${glDevinfo[key].mapfile}`;
        sel.appendChild(option);
    });        
}

function ChangeDev() {
    let key = $("#ui_dev").val();
    LoadDevSvid(glDevinfo[key].mapfile,glDevinfo[key].modbusn);
}

function LoadDevSvid(val, modbusn) {
    glDevDefSvidData = [];
    glDevSvidData = [];
    let p = $.getJSON(targetURL, "loaddevsviddata=1&key=" + val + "&modbusn=" + modbusn)
        .done(data => {
            $.each(data, (idx, param) => {
                switch (idx) {
                    case "def":
                        $.each(param, (i, p) => {
                            glDevDefSvidData[idx] = p;
                        });
                        break;
                    default:
                        $.each(param, (i, p) => {
                            glDevSvidData[i] = p;
                        });
                }
            });

            dataTableArray = [];
            $.each(glDevSvidData, (key, param) => {

                tempArray = [];
                tempItem = glDevSvidData[key];

                tempArray.push("");
                tempArray.push(tempItem.parameterid);
                tempArray.push(tempItem.remark); //名稱

                tempArray.push(tempItem.tagname); //原廠參數名稱/fins點位
                //dataTableArray.push(tempItem.serverfunctioncode);

                tempArray.push(ParseFuntioncode(tempItem.serverfunctioncode)+tempItem.serveraddress);
                //dataTableArray.push(tempItem.functioncode);
                tempArray.push(ParseFuntioncode(tempItem.functioncode)+ParseAddress(tempItem.address));

                tempArray.push(tempItem.startbit);
                tempArray.push(tempItem.endbit);
                dataTableArray.push(tempArray);
            });

            //將讀到的Svid給Datatable
            
            ReloadDataTable(dataTableArray);

        })
        .fail((jqXHR, textStatus, errorThrown) => {
            console.error('getJSON request failed: ' + textStatus, errorThrown);
        });
}
function ParseFuntioncode(functioncode)
{
    switch (functioncode) {
        case "1":
            return "0";           
        case "2":
            return "1";
        case "3":
            return "4";
        case "4":
            return "3";   

    }
}

function ParseAddress(address){    
    result=String(Number(address)+1);
    return result.padStart(address.length, '0');
}
function sendGetRequest() {
    StopTimer();

    // #region 搜尋html畫面上需要詢問的點位
    $('td[class*="SlaveAddress"]').each(function() {
        // 打印匹配元素的文本内容 這裡會顯示出slaveraddress
        //console.log($(this).text());
        // 你可以在这里进行其他操作   
        slaveraddress=$(this).text();
        
        //紀錄要被修改的dataTableArray是哪個
        $.each(dataTableArray,key => {
            if(dataTableArray[key][4]==slaveraddress){
                readmodbus(key);
            } 
        })

    });
    // #endregion
    //顯示在datatable
    ReloadDataTable(dataTableArray);
    StartTimer();
}


function readmodbus(dataTableArrayKey){

    sendAddress=0;
    let url = gl_target_server + "/php/phpmodbus-master/ycs/readModbus.php";
    if (slaveraddress.charAt(0) === '4') {
        sendAddress= slaveraddress.slice(1);
    }
    //取得選取的serverstationid

    let p = $.getJSON(url, `readmodbus=1&address=${sendAddress}&serverstationid=${glDevinfo[$("#ui_dev").val()].serverstationid}`)
        .done(data => {
            $.each(data, (key, value) => {
                dataTableArray[dataTableArrayKey][0] = value; 
            });
        })
        .fail((jqXHR, textStatus, errorThrown) => {
            console.error('getJSON request failed: ' + textStatus, errorThrown);
        });
    
}

// 创建一个变量来保存定时器的 ID
var timerId;
sendGetRequest();
StartTimer();
// 启动定时器
function StartTimer() {
    timerId = setInterval(sendGetRequest, 2000); // 每隔 x 秒发送一次 GET 请求
}

// 停止定时器
function StopTimer() {
    clearInterval(timerId); // 清除定时器
}

// 定义一个函数，用于重新加载 DataTable 的数据
function ReloadDataTable(newData) {
    // 保存当前页数
    var currentPage = table.page();

    // 清空现有数据
    //table.clear().destroy();
    table.clear();
    // // 添加新数据并绘制表格
    table.rows.add(newData).draw();

    //$('#monitorTable').DataTable().clear().destroy(); // 清除和销毁旧的DataTable实例
    //initializeTable(newData); // 重新初始化表格

    // 跳转回之前记录的页数
    table.page(currentPage).draw(false);
}

function Load_Svid_Param_Map()
{
    let targetURL = gl_target_server + '/php/devsvid.php';
    let p = $.getJSON(targetURL, 'loadsvidparam=1')
        .done(data => {
            svid_map = [];
            $.each(data, (idx, val) => {
                svid_map[val.parameterid] = val.remark;
            });
            if (glMapFile == '')
                Load_svidsemple();
            else {
                glMode = 'Edit';
                ShowTargetMapFile();
            }
        })
        .fail((jqXHR, textStatus, errorThrown) => {
            console.error('getJSON request failed: ' + textStatus, errorThrown);
        });
    
}

function Load_svidsemple()
{
    let targetURL = gl_target_server + '/php/devsvid.php';
    let p = $.getJSON(targetURL, 'loadsvidsemple=1')
        .done(data => {
            glSvidSamples = [];
            glSvidPriSamples = [];
            $.each(data, (idx, info) => {
                if (info.private == '1')
                    glSvidPriSamples[info.class] = info;
                else
                    glSvidSamples[info.class] = info;
            });
            SetDevInfos();
            SetPriDevInfos();
        })
        .fail((jqXHR, textStatus, errorThrown) => {
            console.error('getJSON request failed: ' + textStatus, errorThrown);
        });
    
}
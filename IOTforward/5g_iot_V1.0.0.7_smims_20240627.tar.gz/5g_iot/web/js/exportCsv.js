  // 轉成 CSV 並下載
  const downloadCSV = (data,fileName) => {
    let csvContent = '';
    Array.prototype.forEach.call(data, d => {
      let dataString = d.join(',') + '\n';
      csvContent += dataString;
    })



  // 获取当前时间
  var currentTime = new Date();
  var year = currentTime.getFullYear();
  var month = currentTime.getMonth() + 1; // 月份是从0开始的，所以要加1
  var day = currentTime.getDate();
  var hours = currentTime.getHours();
  var minutes = currentTime.getMinutes();
  var seconds = currentTime.getSeconds();
  
  // 格式化时间，确保单个数字部分前面有0
  month = (month < 10 ? "0" : "") + month;
  day = (day < 10 ? "0" : "") + day;
  hours = (hours < 10 ? "0" : "") + hours;
  minutes = (minutes < 10 ? "0" : "") + minutes;
  seconds = (seconds < 10 ? "0" : "") + seconds;
  
  var timeString = year +month+ day + hours+ minutes + seconds;  

      // 下載的檔案名稱
    fileName = fileName+timeString;
    // 建立一個 a，並點擊它
    let link = document.createElement('a');
    link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURI(csvContent));
    link.setAttribute('download', fileName);
    link.click();
  }

  // 整理資料
  const buildData = data => {

    return new Promise((resolve, reject) => {
      // 最後所有的資料會存在這
      let arrayData = [];

      try {
        // 取 data 的第一個 Object 的 key 當表頭
        let arrayTitle = Object.keys(data[0]);

        arrayData.push(arrayTitle);

        // 取出每一個 Object 裡的 value，push 進新的 Array 裡
        Array.prototype.forEach.call(data, d => {
          let items = [];
          Array.prototype.forEach.call(arrayTitle, title => {
            let item = d[title] || '';
            //item=item.replace(/"/g, '');
            items.push(item);
          });
          arrayData.push(items)
        });
      } catch(err) {
        reject(err)
      }

      resolve(arrayData);
    })

  }
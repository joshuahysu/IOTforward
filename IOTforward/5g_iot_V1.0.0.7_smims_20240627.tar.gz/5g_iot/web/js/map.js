var scaleType_map = {
    "0": "先乘後加",
    "1": "先加後乘"
};
var dv_map = {
    "com": [
        "EBARA_ESR/EST/EV-S/EV-M",
        "Kashiyama_MU/TS",
        "Kashiyama_MU/TS(-)",
        "Kashiyama SDE(A&K)",
        "Kashiyama SDE(X&K)",
        "Kashiyama SDE(a&k)",
        "EDW iQ/iH/iL",
        "EDW iGX/GX",
        "EDW IXH / IXM",
        "Kashiyama_SDT/SDX/SDH",
        "EDW iXL"
    ],
    "fins":[],
    "modbus":[]
};
var devType_map = {
    "com": ["DPM"],
    "fins": ["LSC"],
    "modbus": ["LSC"]
};
var connectType_map = {
    "com": ["COM"],
    "fins": ["FINS"],
    "modbus": ["Modbus TCP","Modbus RTU"]
};
var rs_map = {
    "com": ["RS-232","RS-422","RS-485"],
}
var pt_map = [
    "RS232",
    "RS485",
    "RS422"
];
var br_map = [
    "600",
    "1200",
    "1800",
    "2400",
    "4800",
    "9600",
    "19200",
    "38400",
    "57600",
    "115200",
    "230400",
    "460800",
    "500000",
    "576000",
    "921600"
];
var parity_map = [
    "None",
    "Odd",
    "Even",
    "Space",
    "Mark"
];
var db_map = [
    "5","6","7","8"
];
var sb_map = [
    "1","2"
];
var readerCode_map = {
    "com":[
        "EBARA_ESR_EST_EV-S_EV-M",
        "EDWARDS",
        "KSY_MU_TS",
        "KSY_SDE_SDT_SDX_SDH",
    ],
    "fins":[],
    "modbus": []
};
var fins_merge_mode_map = {
    "0":"uint16",
    "1":"int16",
    "2":"uint32",
    "3":"int32",
    "4":"float4",
    "5":"float8",
    "6":"uint64",
    "7":"int64"
};

var endian_map={
    "0":"0",
    "1":"1"
}


var chamberid_map = {};
var svid_map = {};
var com_ports_map = {};
var analog_map = [
    "None",
    "AK",
    "XK",
    "ak",
];
var signed_map = [
    "0",
    "1"
];

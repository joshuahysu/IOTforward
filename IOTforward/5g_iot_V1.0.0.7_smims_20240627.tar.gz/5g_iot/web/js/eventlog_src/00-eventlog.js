
var glDeviceItems = [];
var glLogDatas = {};
var glStartDate = moment().format('YYYYMMDD');
var glEndDate = moment().format('YYYYMMDD');
var glDefaultFile = "";
var glCurFileName = "";
var glRecatch = false;

getPHPGlStartDate();

getDeviceItems();
getLogFileDatas();

function getPHPGlStartDate()
{
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/eventlog.php",
        data: {'func': 'getPHPGlStartDate'},
        success: data => {
            glStartDate=data;
        },
        error: function (err) {
            console.log(err);
        }
    });
}
function getDeviceItems()
{
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/eventlog.php",
        data: {'func': 'loaddeviceitems'},
        success: data => {
            glDeviceItems = [];
            $.each(data, (idx, d) => {
                glDeviceItems.push(d);
            })
            CreateDeviceItems();
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function CreateDeviceItems()
{
    let ui;
    let dpm_ul = document.getElementById("dpm_device");
    let fins_ul = document.getElementById("fins_device");
    let modbus_ul = document.getElementById("modbus_device")

    $.each(glDeviceItems, (idx, d) => {

        switch (d.connectiontype) {
            case 'COM':
                ui = dpm_ul;
                break;
            case 'FINS':
                ui = fins_ul;
                return;//現在先關閉
                break;
            default:
                ui = modbus_ul;
                return;//現在先關閉
        }

        let li = document.createElement("li");
        li.classList.add("logitem");
        ui.appendChild(li);

        let a = document.createElement("a");
        a.href = "#";
        a.setAttribute("onclick", `showLogFiles(this, '${d.key}');`);
        li.appendChild(a);

        let i = document.createElement("i");
        i.setAttribute("class", "fa fa-file");
        a.appendChild(i);

        let sp = document.createElement("span");
        switch (d.devicetype) {
            case 'DPM':
                let tmp = '';
                if (d.key.indexOf('vcom') > -1) {
                    sp.textContent = d.key.replace('/dev/', '');
                } else {
                    for (var j = d.key.length - 1;j>=0;j--) {
                        if ($.isNumeric(d.key[j])) 
                            tmp = d.key[j] + tmp;
                    }
                    sp.textContent = `COM${parseInt(tmp) + 1}`;
                    }
                break;
            default:
                sp.textContent = d.key;
        }
        a.appendChild(sp);

        i = document.createElement("i");
        i.setAttribute("class", "fa fa-angle-right");
        i.style.display = "none";
        a.appendChild(i);

    });
}

function getLogFileDatas()
{
    let fileName = glCurFileName;
    let lastline = '0';
    let data = {};

    //fileName = `${fileName}_${glStartDate}.txt`;

    if (fileName.indexOf('log') > -1) {
        $.ajax( {
            method: "POST",
            dataType: 'json',
            url: gl_target_server + "/php/eventlog.php",
            data: {'func': 'loadlogfiledata', 'filename': fileName, 'lastline': lastline},
            success: data => {
                let textArea = document.getElementById("ui_monitor");
                textArea.textContent = '';
                $.each(data, (idx, d) => {
                    // glLogDatas[fileName]['data'].push(d);
                    textArea.textContent += d;
                })
    
                if (textArea.textContent == '')
                    textArea.textContent = "No Log Data...";
    
            },
            error: function (xhr, status, error) {
                document.getElementById("ui_monitor").textContent = "No Log Data...";
                console.log('失敗:');
                console.log('XMLHttpRequest:', xhr);
                console.log('狀態碼:', xhr.status);
                console.log('錯誤訊息:', error);
            }
        });
    } else if (fileName != '') {

        $.ajax({
            method: "GET",
            url: gl_target_server + "/php/eventlog.php?loadlogfiledata=1&cmd=" + fileName,
            success: data => {
                //console.log(data);
                let textArea = document.getElementById("ui_monitor");
                if (glRecatch) {
                    textArea.textContent = '';
                    glRecatch = false;
                } 
                let content = textArea.textContent;
                if (content.split('\n').length >= 30) {
                    // console.log('over 30');
                    content = content.split('\n');
                    content.splice(29, 1);
                    content = content.join('\n')
                    textArea.textContent = content;
                }
                textArea.textContent = data + "\n" + textArea.textContent;
            },
            error: function (xhr, status, error) {
                document.getElementById("ui_monitor").textContent = "No Log Data...";
                console.log('失敗:');
                console.log('XMLHttpRequest:', xhr);
                console.log('狀態碼:', xhr.status);
                console.log('錯誤訊息:', error);
            }
        })


    }

    if (glLogDatas[fileName] != undefined) {
        lastline = glLogDatas[fileName]['lastline'];
    }


    setTimeout(() => {
        getLogFileDatas();
    }, 1000)

}

function showLogFiles(obj, type)
{
    document.getElementById("ui_monitor").textContent ="";
    switch (type) {
        case "adlink_uptime":
            glCurFileName = "adlink_uptime";
            break;
        case "adlink_activate":
            glCurFileName = "adlink_activate";
            break;
        case "secsgemservice":
            glCurFileName = `log_HsmsSs_equip_info_${glStartDate}.log`;
            break;
        case "modbusservice":
            glCurFileName = `log_modbusservice_${glStartDate}.txt`;
            break;
        case "secsgemservice_pkt":
            glCurFileName = `log_pkts_${glStartDate}.txt`;
            break;
        case "5grouter":
            glCurFileName = `log_5g_router_info.txt`;
            break;
        case "alarmfunction":
            glCurFileName = `alarmfunction.txt`;
            break;    
            
        default:
            let tmp = type.replace('/dev/', '');
            tmp = type.replace('tcp://', '');
            glCurFileName = `logfile_${tmp}_${glStartDate}.csv`;
    }
    glRecatch = true;
    $(".fa-angle-right").hide();
    $(obj).find(".fa-angle-right").show();
}

$(document).ready(() => {

    $(".fa-angle-right").hide();

    $("#ui_date").daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
        locale: {
            format: "YYYY/MM/DD",
            daysOfWeek: ["日", "一", "二", "三", "四", "五", "六"],
            monthNames : ["1月", "2月", "3月", "4月", "5月", "6月","7月", "8月", "9月", "10月", "11月", "12月"],
        },
        startDate: glStartDate,
    }).on("apply.daterangepicker", (ev, picker) => {
        let newDate = picker.startDate.format("YYYYMMDD");
        if (newDate != glStartDate) {
            glStartDate = newDate;
            glRecatch = true;
        }
    });

})

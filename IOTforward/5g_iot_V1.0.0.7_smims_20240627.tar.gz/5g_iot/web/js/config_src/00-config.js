var glConfigData;

getConfigData();

function getConfigData() {
    var targetURL = gl_target_server + "/php/config.php";
    var p = $.getJSON(targetURL, "queryconfig=1", (data) => {

        $.each(data, (index, ev) => {
            glConfigData = ev;
        })
    })
    .success(() => {
        setDatas();
    })
    .error(err => {
        console.log("err=>" + err);
    })
}

function setDatas() {
    $('#ui_ip').val(glConfigData.ip);
    $('#ui_fdcport').val(glConfigData.fdcport);
    $('#ui_itport').val(glConfigData.itport);
    $('#ui_mdln').val(glConfigData.mdln);
    $('#ui_sessionid').val(glConfigData.sessionid);
    $('#ui_mqttaddr').val(glConfigData.mqttaddress);
    $('#ui_mqttport').val(glConfigData.mqttport);
    $('#ui_mqttuser').val(glConfigData.mqttuser);
    $('#ui_mqttpwd').val(glConfigData.mqttpassword);
    $('#ui_mqttprefix').val(glConfigData.mqttprefix);
    $('#ui_factory').val(glConfigData.factory);
    $('#ui_ebara').val(glConfigData.ebara_time);
    $('#ui_edwards').val(glConfigData.edwards_time);
    $('#ui_ksy_mu_ts').val(glConfigData.ksy_mu_time);
    $('#ui_ksy_sde_sdt_sdx_sdh').val(glConfigData.ksy_time);
    $('#ui_fins').val(glConfigData.fins_time);
    $('#ui_localip').val(glConfigData.localip);
    $('#ui_localmask').val(glConfigData.localmask);
    $('#ui_localgateway').val(glConfigData.localgateway);
    let dpmids = JSON.parse(glConfigData.dpmids);
    $('#ui_dpmids').val(dpmids[glConfigData.factory]);

}

function update_config() {

    var dpmids = JSON.parse(glConfigData.dpmids);
    dpmids[$('#ui_factory').val()] = document.getElementById("ui_dpmids").value;

    if(document.getElementById("ui_localmask").value.charAt(document.getElementById("ui_localmask").value.length - 1)!=='0'){
        alert("mask 最後一碼必須為0");
        return;
    }
    var set = {
        "localip": document.getElementById("ui_localip").value,
        "localmask": document.getElementById("ui_localmask").value,
        "localgateway": document.getElementById("ui_localgateway").value,
        "ip": document.getElementById("ui_ip").value,
        "fdcport": document.getElementById("ui_fdcport").value,
        "itport": document.getElementById("ui_itport").value,
        "mdln": document.getElementById("ui_mdln").value,
        "sessionid": document.getElementById("ui_sessionid").value,
        "mqttaddress": document.getElementById("ui_mqttaddr").value,
        "mqttport": document.getElementById("ui_mqttport").value,
        "mqttuser": document.getElementById("ui_mqttuser").value,
        "mqttpassword": document.getElementById("ui_mqttpwd").value,
        "mqttprefix": document.getElementById("ui_mqttprefix").value,
        "ebara_time": document.getElementById("ui_ebara").value,
        "edwards_time": document.getElementById("ui_edwards").value,
        "ksy_mu_time": document.getElementById("ui_ksy_mu_ts").value,
        "ksy_time": document.getElementById("ui_ksy_sde_sdt_sdx_sdh").value,
        "fins_time": document.getElementById("ui_fins").value,
        "factory": $('#ui_factory').val(),
        "dpmids": JSON.stringify(dpmids),
    };
    var targetURL = gl_target_server + "/php/config.php";
    set = "saveconfig=1&data=" + encodeURIComponent(JSON.stringify(set));
    // console.log(set);
    var p = $.getJSON(targetURL, set, (data) => {
        console.log(data);
    })
    .success(() => {
        alert('存檔成功！');
        getConfigData();

        targetURL = gl_target_server + "/php/export.php";
        var e = $.getJSON(targetURL, "getservercsv=1", data => {
            console.log(data);
        })
        .success(() => {

        })
        .error(err => {
            console.log("err=>" + err);
        })

    })
    .error(err => {
        console.log("err=>" + err);
    })

}

function system_start()
{
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/config.php",
        data: {'func': 'startdevsystem'},
        success: function(json) {
            alert('啟動完成！');
            // console.log(json);
        },
        error: function (err) {
            alert('啟動失敗！');
            // console.log(err);
        }
    } );

}

function system_stop()
{
    if (confirm("是否確定停止服務？"))
    {
        $.ajax( {
            method: "POST",
            dataType: 'json',
            url: gl_target_server + "/php/config.php",
            data: {'func': 'stopdevsystem'},
            success: function(json) {
                alert('停止完成！');
                // console.log(json);
            },
            error: function (err) {
                alert('停止失敗！');
                // console.log(err);
            }
        });
    }
}

function SudoReboot()
{
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/config.php",
        data: {'func': 'SudoReboot'},
        success: function(json) {
            alert('停止完成 請稍等！');
        },
        error: function (err) {
            alert('請稍等！');
        }
    });    
}

function Simulator_on(){
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/config.php",
        data: {'func': 'SimulatorOn'},
        success: function(json) {
            alert('Simulator_On完成！');
            // console.log(json);
        },
        error: function (err) {
            alert('停止失敗！');
            console.log(err);
        }
    });
}


function Simulator_off(){
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/config.php",
        data: {'func': 'SimulatorOff'},
        success: function(json) {
            alert('Simulator_Off完成');
            // console.log(json);
        },
        error: function (err) {
            alert('停止失敗！');
            console.log(err);
        }
    });
}


function SIM_check_on(){
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/config.php",
        data: {'func': 'SIMCheckOn'},
        success: function(json) {
            alert('SIM_Check_On完成！');
            // console.log(json);
        },
        error: function (err) {
            alert('停止失敗！');
            console.log(err);
        }
    });
}


function SIM_check_off(){
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/config.php",
        data: {'func': 'SIMCheckOff'},
        success: function(json) {
            alert('SIM_Check_Off完成！');
            // console.log(json);
        },
        error: function (err) {
            alert('停止失敗！');
            console.log(err);
        }
    });
}


function StartTcpdump(){
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/config.php",
        data: {'func': 'StartTcpdump'},
        success: function(json) {
            alert('Start Tcpdump啟動！');
            // console.log(json);
        },
        error: function (err) {
            alert('啟動失敗！');
            console.log(err);
        }
    });
}

$(document).ready(function(e) {
    $("#ui_factory").change(e => {
        let dpmids = JSON.parse(glConfigData.dpmids);
        if (dpmids[$(e.currentTarget).val()] != null)
            $("#ui_dpmids").val(dpmids[$(e.currentTarget).val()]);
        else
            $("#ui_dpmids").val('');
    })
})

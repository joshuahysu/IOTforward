function transAddressData(targetType, data) {
    let val = '';
    switch (targetType) {
        case "save":
            switch (data) {
                case 0: //Coils
                    val = 1;
                    break;
                case 1: //Discrete Inputs
                    val = 2;
                    break;
                case 3: //Input Registers
                    val = 4;
                    break;
                case 4: //Holding Registers
                    val = 3;
                    break;
            }
            break;
        case "view":
            switch (data) {
                case 1: //Coils
                    val = 0;
                    break;
                case 2: //Discrete Inputs
                    val = 1;
                    break;
                case 4: //Input Registers
                    val = 3;
                    break;
                case 3: //Holding Registers
                    val = 4;
                    break;
            }
            break;
    }
    return val;
}

function transServerAddressData(targetType, data) {
    let val = '';
    switch (targetType) {
        case "save":
            switch (data) {
                case 0: //Coils
                    val = 0;
                    break;
                case 1: //Discrete Inputs
                    val = 1;
                    break;
                case 3: //Input Registers
                    val = 2;
                    break;
                case 4: //Holding Registers
                    val = 3;
                    break;
            }
            break;
        case "view":
            switch (data) {
                case 0: //Coils
                    val = 0;
                    break;
                case 1: //Discrete Inputs
                    val = 1;
                    break;
                case 2: //Input Registers
                    val = 3;
                    break;
                case 3: //Holding Registers
                    val = 4;
                    break;
            }
            break;
    }
    return val;
}

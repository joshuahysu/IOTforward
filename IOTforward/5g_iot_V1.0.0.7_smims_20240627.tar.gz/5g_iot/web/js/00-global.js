var gl_target_server =  window.location.protocol+"//" + window.location.hostname + ":" + window.location.port;
var gl_websocket_server = "ws://" + window.location.hostname;
//var protocol = window.location.protocol;
// if (protocol === "https:")
//     gl_websocket_server = "wss://" + window.location.hostname;
// console.log("gl_websocket_server:"+gl_websocket_server);

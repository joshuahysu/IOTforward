
var glDeviceItems = [];
var glLogDatas = {};
var glStartDate = moment().format('YYYYMMDD');
var glEndDate = moment().format('YYYYMMDD');
var glDefaultFile = "";
var glCurFileName = "";
var glRecatch = false;
var glMode = '';

getDeviceItems();
getLogFileDatas();

function getDeviceItems()
{
    $.ajax( {
        method: "POST",
        dataType: 'json',
        url: gl_target_server + "/php/datatmpmonitor.php",
        data: {'func': 'loaddeviceitems'},
        success: data => {
            glDeviceItems = [];
            $.each(data, (idx, d) => {
                glDeviceItems.push(d);
            })
            // if (test_mode === '1') {
            //     glDeviceItems.push({ id: "/dev/vcom_ebara_esr_est_ev-m", name:"vcom_ebara_esr_est_ev-m", devicetype: "DPM" });
            //     glDeviceItems.push({ id: "/dev/vcom_edwards EDW IGX/GX", name:"vcom_edwards EDW IGX/GX", devicetype: "DPM" });
            //     glDeviceItems.push({ id: "/dev/vcom_edwards", name:"vcom_edwards", devicetype: "DPM" });
            //     glDeviceItems.push({ id: "/dev/vcom_ksy_mu_ts", name:"vcom_ksy_mu_ts", devicetype: "DPM" });
            //     glDeviceItems.push({ id: "/dev/vcom_sde_sdt_sdx_sdh ak", name:"vcom_sde_sdt_sdx_sdh ak", devicetype: "DPM" });
            //     glDeviceItems.push({ id: "/dev/vcom_ksy_sde_sdt_sdx_sdh", name:"vcom_ksy_sde_sdt_sdx_sdh", devicetype: "DPM" });
            // }
            CreateDeviceItems();
        },
        error: function (err) {
            console.log(err);
        }
    });
}

function CreateDeviceItems()
{
    let dpmList = document.getElementById("dpm_device");
    let finsList = document.getElementById("fins_device");
    let modbusList = document.getElementById("modbus_device");
    let ul, li, a, i, sp;
    let name = '';
    $.each(glDeviceItems, (idx, item) => {
        name = '';
        switch (item.devicetype) {
            case 'DPM':
                ul = dpmList;
                if (item.name.indexOf("vcom") > -1) {
                    name = item.name.replace('/dev/', '');
                } else {
                    for (var i = item.name.length - 1; i > -1; i--) {
                        if ($.isNumeric(item.name.substr(i, 1))){
                            name = item.name.substr(i, 1) + name;
                        }
                   }
                   if (name.length > 0)
                       name = `COM${parseInt(name) + 1}`;
                   else
                       name = item.name;
                }
                break;
            case 'LSC':
                switch (item.connectiontype) {
                    case 'FINS':
                        ul = finsList;
                        break;
                    default:
                        ul = modbusList;
                }
                name = item.name;
                break;
        }
        li = document.createElement("li");
        ul.appendChild(li);

        a = document.createElement("a");
        a.href = "#";
        a.setAttribute("onclick", `ShowSnapShot(this, '${item.devicetype}', '${item.id}');`);
        li.appendChild(a);

        i = document.createElement("i");
        i.setAttribute("class", "fa fa-file");
        a.appendChild(i);

        sp = document.createElement("span");
        sp.textContent = name;
        a.appendChild(sp);

        i = document.createElement("i");
        i.setAttribute("class", "fa fa-angle-right");
        a.appendChild(i);

        // <li ><a href='#' onclick='showLogFiles(this, "secsgemservice");return false;'><i class='fa fa-file'></i><span>SECSGEM Service</span><i class="fa fa-angle-right"></i></a></li>
    });


}

function getLogFileDatas()
{
    let fileName = glCurFileName;
    let lastline = '0';
    let data = {};

    switch (glMode) {
        case "shot":
            let url = `${window.location.protocol}//${window.location.hostname}:9098/device/${fileName}`;
            $.getJSON(url, function(data, status) {
                PutTextArea(JSON.stringify(data));
                // console.log(data);
            }).error(err => {
                PutTextArea(err.responseText);
                // console.log(err);
            });

            break;
        case "log":
            fileName = `log_${fileName}_${glStartDate}.txt`;
            alert(fileName);
            if (glLogDatas[fileName] != undefined) {
                lastline = glLogDatas[fileName]['lastline'];
            }

            $.ajax( {
                method: "POST",
                dataType: 'json',
                url: gl_target_server + "/php/datatmpmonitor.php",
                data: {'func': 'loadlogfiledata', 'filename': fileName, 'lastline': lastline},
                success: data => {
                    let textArea = document.getElementById("ui_monitor");
                    if (glLogDatas[fileName] == undefined) {
                        glLogDatas[fileName] = {};
                        glLogDatas[fileName]['data'] = [];
                        glLogDatas[fileName]['lastline'] = 0;
                    }

                    // console.log(data.lastline);
                    glLogDatas[fileName]['lastline'] = data.lastline;

                    if (glRecatch) {
                        textArea.textContent = '';
                        glRecatch = false;
                        if (glLogDatas[fileName]['data'].length > 0) {
                            $.each(glLogDatas[fileName]['data'], (idx, d) => {
                                textArea.textContent = d + textArea.textContent;
                            })
                        }
                    }

                    $.each(data.datas, (idx, d) => {
                        textArea.textContent = d + textArea.textContent;
                    })

                    if (textArea.textContent == '')
                        textArea.textContent = "No Log Data...";

                    //ShowLogDatas();
                },
                error: function (err) {
                    console.log(err);
                }
            });
            break;
    }

    setTimeout(() => {
        getLogFileDatas();
    }, 1000)

}

function ShowSnapShot(obj, type, id)
{
    glMode = 'shot';
    glRecatch = true;
    glCurFileName = `${type}/${id}`;
    $(".fa-angle-right").hide();
    $(obj).find(".fa-angle-right").show();

    // let url = `http://192.168.0.157:9098/device/${type}/${id}`;
    // $.post(url, function(data, status) {
    //
    //     console.log(data);
    // }).error(err => {
    //     console.log(err);
    // });
}

function showLogFiles(obj, type)
{
    switch (type) {
        case "Fins":
            glCurFileName = "log_fins2mqtt";
            break;
        default:
            glCurFileName = type;
    }
    glRecatch = true;
    $(".fa-angle-right").hide();
    $(obj).find(".fa-angle-right").show();
}

function PutTextArea(text)
{
    let textArea = document.getElementById("ui_monitor");
    if (text.indexOf("\n") < 0)
        text += "\n";

    let content = textArea.textContent;
    if (content.split('\n').length >= 30)
    {
        textArea.textContent = '';
        content = content.split('\n');
        content.slice(29, 1);
        content = content.join('\n');
        textArea.textContent = content;
    }

    textArea.textContent = text + textArea.textContent;
}

$(document).ready(() => {

    $(".fa-angle-right").hide();

    $("#ui_date").daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
        locale: {
            format: "YYYY/MM/DD",
            daysOfWeek: ["日", "一", "二", "三", "四", "五", "六"],
            monthNames : ["1月", "2月", "3月", "4月", "5月", "6月","7月", "8月", "9月", "10月", "11月", "12月"],
        },
        startDate: glStartDate,
    }).on("apply.daterangepicker", (ev, picker) => {
        let newDate = picker.startDate.format("YYYYMMDD");
        if (newDate != glStartDate) {
            glStartDate = newDate;
            glRecatch = true;
        }
    });

})

<?php

    if (!isset($_SESSION))
    {
      session_start();
    }

    $web_version = '1.0.0.7 Bulid 0619';
    $UPDATE_DATE = '20240301';
    $TEST_MODE = '1';//讓虛擬com可以在web上被選擇

    $com_ports_setting_path = "/opt/5g_iot/setting/";
    $dev_config_path = "/opt/5g_iot/config/";
    $dev_config_mapfile_path = "/opt/5g_iot/config/mapfile/";
    $dev_secsgem_config_path = "/opt/5g_iot/secsgem/config/";
    $dev_modbus_config_path = "/opt/5g_iot/ModbusServerService/config/";
    $dev_ip_setting_path = "/opt/5g_iot/config/";

    $main_show_logo = "1";
    $main_logo_small_file = "5G_logo_淺.png";

    $log_file_path = "/opt/5g_iot/log/";

?>

<?php
session_start();

$path = ltrim($_SERVER['REQUEST_URI'], '/');    
$elements = explode('/', $path);                

require_once("config.php");
require_once("./php/common.php");
require_once("./php/sqlite3.php");

$login_account = '';
$login_password = '';
$login_enter_error = false;

if (!empty($_POST)) {
    if (isset($_POST['account']) && isset($_POST['password'])) {
        $valid = true;

        $login_account = $_POST['account'];
        $login_account = str_replace(' ', '', $login_account);

        $login_password = $_POST['password'];
        $login_password = str_replace(' ', '', $login_password);

        if (!getServerInfo($login_account, $login_password)) {
            $login_enter_error = true;
            $valid = false;
        } else {
            // 寫入 Session 變數值
            $_SESSION['userid'] = $login_account;
            $_SESSION['login_time'] = date('Y-m-d h:i:s');
            // 重導到相關頁面
            header("Location: /index.php");
            exit;
        }
    }
}

function getServerInfo($userid, $pwd)
{
    $result = false;
    $sql = "select id from userdata where userid = '" . $userid . "' and pwd = '" . $pwd . "'; ";
    $db = new SqliteDB("./sqlite/5giot.db");
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        $result = true;
    }
    $db->closeSqlite();
    return $result;
}

?>

<!DOCTYPE HTML>
<html lang="en">
<?php
include('vils_html_head.php');
?>

<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <img src="/images/<?php echo $main_logo_small_file ?>" style="width:360px;" />
        </div>

        <!-- /.login-logo -->
        <div class="login-box-body" style="background-color: inherit;">
            <?php
            if ($login_enter_error) {
                echo '<div align="center"><h4><span class="label label-danger">帳號或密碼錯誤!請重新輸入.</span></h4></div>';
            }
            ?>

            <p class="login-box-msg"><?php echo $login_sign_in_comment; ?></p>

            <form action="/login.php" method="post">
                <div class="form-group has-feedback">
                    <input type="text" name="account" style="width:100%;background-color:#506670;color:#FFF;" class="form-control" value="<?php echo $login_account; ?>" placeholder="請輸入帳號">
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" name="password" style="border-radius: 5px;border:1px solid #000;background-color:#506670;color:#FFF;" class="form-control" value="<?php echo $login_password; ?>" placeholder="請輸入密碼">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <button type="submit" style="border-radius: 5px;" class="btn btn-primary btn-block btn-flat pull-right">登入</button>
                    </div>
                </div>
            </form>

        </div>
        <!-- /.login-box-body -->
    </div>
    <!-- /.login-box -->

    <script src="/js/global.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
    <script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
    <!-- <script src="/js/vils.min.js?date=<?php echo $UPDATE_DATE; ?>"></script> -->

</body>

</html>
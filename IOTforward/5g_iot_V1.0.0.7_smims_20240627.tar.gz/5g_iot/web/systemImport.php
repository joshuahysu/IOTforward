<?php
include ('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">
 <head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
   <link href="/css/vils.min.css" rel="stylesheet">
   <link href="/css/main.css?data=<?php echo $UPDATE_DATE; ?>" rel="stylesheet">
   <link href="/css/jquery_ui_v1.13.2.css" rel="stylesheet">
   <title></title>

   <style>

       .c_box_dpmitem {
           margin: 10px 0px;
       }

       .device_setting input[type=text] {
           margin-left: 5px;
           width: 250px !important;
       }

       #dpm_list tbody td {
           padding: 10px 5px;
       }

       #dpm_list tbody td {
           padding: 10px 5px;
       }

       #dpm_list tbody td:first-child {
        text-align: center;
       }

       #dpm_list tbody td i {
           margin: 0px 3px;
           cursor: pointer;
       }

       .device_setting {
           margin: 0px;
       }

       .info_block_0
       {
           background-color: rgba(190,190,190,0.4);
       }

       .info_block_1
       {
           background-color: rgba(190,190,190,0.7);
       }

       .info_block_2
       {
           background-color: rgba(190,190,190,0.8);
       }
   </style>

 </head>
        <div class="row" id="section_group_edit" style="display:block;">
          <div class="col-md-12">
           <!-- Event Settings -->
            <div class="box" id="section_group_edit_box">
             <div class="box-header with-border"><h3 class="box-title">匯入匯出設備設定檔</h3></div>
             <!-- /.box-header -->
             <div class="box-body" id="account_box_body">
              匯出 Parameter總表+設備Parameter Model Map
              <form action="/php/systemImport.php" method="post" enctype="multipart/form-data">
              <label for="csvFile">Choose CSV file:</label>
              <input type="file" name="uploadFile" id="csvFile" accept=".csv">
              <button type="submit" name="submitType" value="uploadCsv"style="width:120px;height:40px;border:2px #9999FF dashed;">匯入csv</button>
              </form>

              <button id="export_devsvid_csv" type="button" style="width:120px;height:40px;border:2px #9999FF dashed;">匯出csv</button>


              <br><br><br>
              匯入單台設備Parameter Model Map
              <form action="/php/systemImport.php" method="post" enctype="multipart/form-data">
              <label for="csvFile">Choose CSV file:</label>
              <input type="file" name="uploadFile" id="csvFile" accept=".csv">
              <button type="submit" name="submitType" value="uploadOneDeviceCsv"style="width:120px;height:40px;border:2px #9999FF dashed;">匯入csv</button>
              </form>
              
              <br><br><br>
              設備Parameter Model Map (新)
              <form action="/php/systemImport.php" method="post" enctype="multipart/form-data">
              <label for="csvFile">Choose CSV file:</label>
              <input type="file" name="uploadFile" id="csvFile" accept=".csv">
              <button type="submit" name="submitType" value="uploadAllDeviceCsv"style="width:120px;height:40px;border:2px #9999FF dashed;">匯入csv</button>
              </form>
              <button id="export_devsvid_csv_new" type="button" style="width:120px;height:40px;border:2px #9999FF dashed;">匯出csv</button>

              <br><br><br>
              匯出 DB
              <form action="/php/systemImport.php" method="post" enctype="multipart/form-data">
              <label for="dbFile">Choose DB file:</label>
              <input type="file" name="uploadFile" id="dbFile" accept=".db">
              <button type="submit" name="submitType" value="uploadDb"style="width:120px;height:40px;border:2px #9999FF dashed;">匯入db</button>
              </form>
              <form action="/php/systemImport.php" method="post" enctype="multipart/form-data">
              <button type="submit" name="submitType" value="downloadDB"style="width:120px;height:40px;border:2px #9999FF dashed;">匯出db</button>
              </form>


             </div>
       
            </div>
            <!-- /.box-body -->
            </div>
           <!-- /.box-->
          </div>
         <!-- /.col -->
        </div>
        <!-- /.row -->

       <div class="row" style="display:block;">
         <div class="col-md-12">
           <!-- Event Settings -->
           <div class="box">
             <div class="box-header with-border">
               <h3 class="box-title">匯入linux更新檔</h3>
             </div>
             <!-- /.box-header -->
             <div class="box-body">

            <form id="importLinuxGar" action="/php/systemImport.php" method="post" enctype="multipart/form-data">
            <progress id="progressBar" max="100" value="0"></progress>
            <input type="file" name="uploadFile" id="uploadLinuxGarFile" accept=".gz">
            <button type="submit" name="submitType" value="importLinuxGar"style="width:120px;height:40px;border:2px #9999FF dashed;">Upload</button>
            </form>            
            <!-- <button id="1223" type="button" style="width:120px;height:40px;border:2px #9999FF dashed;">匯出csv</button> -->
        </div>
            <!-- /.box-body -->
           </div>
           <!-- /.box-->
         </div>
         <!-- /.col -->
       </div>
       <!-- /.row -->


   <script src="/js/exportCsv.js"></script>
   <script src="/js/global.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/common.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/map.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/systemImport/00-systemImport.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script>
        var test_mode = '<?php echo $TEST_MODE; ?>';
   </script>

</html>
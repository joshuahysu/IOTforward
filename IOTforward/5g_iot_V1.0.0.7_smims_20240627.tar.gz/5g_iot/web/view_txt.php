<?php

// 檢查是否有傳遞檔案名稱參數
if (isset($_GET['file'])) {
    // 檔案完整路徑
    $filePath =$_GET['file'];
    //echo $filePath;

    // 檢查檔案是否存在並可讀
    if (file_exists($filePath) && is_readable($filePath)) {
        if (strpos($filePath, '.pcap') !== false) {
            //echo "字串中包含'.pcap'";
            DownloadFile($filePath);
            //ReadPcapFile($filePath);
        }
        elseif(isset($_GET['download']))
        {
            DownloadFile($filePath);
        }
        else {
            //echo "字串中不包含'.pcap'";
            // 讀取檔案內容並輸出到瀏覽器
            header('Content-Type: text/plain');
            readfile($filePath);
        } 
    } else {
        echo "無法讀取檔案。";
    }
}
 else {
    echo "缺少檔案參數。";
}

function ReadPcapFile($filePath){
    $command = "sudo tcpdump -r $filePath -c 5 && sudo pkill tcpdump"; // 執行的指令
    $output = array(); // 存放指令執行的輸出

    // 執行指令
    exec($command, $output);

    // 輸出指令執行結果到網頁
    foreach ($output as $line) {
        echo htmlspecialchars($line) . "<br>"; // 使用htmlspecialchars()函式轉換特殊字元，避免XSS攻擊
    }
}

function DownloadFile($file){
// 檢查檔案是否存在
if (file_exists($file)) {
    // 設置 HTTP 響應的 Content-Type
    header('Content-Type: application/octet-stream');
    // 設置 Content-Disposition 標頭，以便瀏覽器將檔案下載為附件
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    // 清除緩衝區
    ob_clean();
    // 將檔案輸出到 HTTP 響應
    readfile($file);
    // 終止腳本
    exit;
} else {
    // 如果檔案不存在，返回 404 錯誤
    header("HTTP/1.0 404 Not Found");
    echo "檔案不存在";
    exit;
}

}




?>

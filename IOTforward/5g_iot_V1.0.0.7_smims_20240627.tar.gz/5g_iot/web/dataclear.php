<?php
include ('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
    <link href="/css/vils.min.css" rel="stylesheet">
    <link href="/css/main.css" rel="stylesheet">
    <title></title>

    <style>

        .form-control {
            border-radius: 5px;
        }

        select {
            border-radius: 5px;
            width: 100px;
            margin-left: 5px;
        }

        input[type=text] {
            border-color: #AAA;
        }

        .devrow {
            margin: 10px;
        }

        .devrow input[type=text] {
            text-align: right;
        }


    </style>

  </head>

        <div class="row" id="section_group_edit" style="display:block;">
          <div class="col-md-12">
            <!-- Event Settings -->
            <div class="box" id="section_group_edit_box">
              <div class="box-header with-border">
                <h3 class="box-title"><?php echo "資料清除";?></h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                  <div class="row c_box">
                      <div class="col-md-12">
                          <div class="row">
                              <div class="col-md-4">
                                  <label>清除未使用的Mapfile(非範本)</label>
                                  <input type="button" id="btn_mapfile_clear" value="清除" onclick="clear_mapfile();" />
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <!-- /.box-body -->

            </div>
            <!-- /.box-->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

    <script src="/js/global.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
    <script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
    <script src="/js/dataclear_src/00-dataclear.js?date=<?php echo $UPDATE_DATE;?>"></script>

</html>

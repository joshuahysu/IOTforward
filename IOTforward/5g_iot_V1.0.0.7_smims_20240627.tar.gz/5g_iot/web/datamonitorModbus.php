<?php
include('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
  <link href="/css/vils.min.css" rel="stylesheet">
  <link href="/css/main.css?data=<?php echo $UPDATE_DATE; ?>" rel="stylesheet">
  <title></title>

  <style>
    #log_box_body .row>div {
      padding: 0px;
    }
    .dt-right {
    text-align: right;
    }
    .log_monitor {
      background-color: #000;
      color: #0F0;
      font-size: 16px;
      font-weight: 600;
      width: 100%;
      height: 630px;
      resize: none;
      padding: 0px 20px;
    }

    #log_items {
      padding: 10px;
      background-color: #575656;
      color: #FFF;
      height: 630px;
      overflow-y: auto;
    }

    #log_items a {
      color: #FFF !important;
    }

    #log_items .treeview {
      font-size: 16px;
      border: 1px solid;
      cursor: pointer;
    }

    #log_items .treeview span {
      margin: 10px;
      line-height: 3;
    }

    #log_items .treeview-menu {
      padding-left: 0px;
    }

    #log_items .treeview-menu>li {
      background-color: #393737;
      border: 1px solid;
    }

    #log_items .treeview-menu>li>a {
      margin-left: 15px;
    }

    #log_items .treeview-menu>li>ul>li>a {
      margin-left: 30px;
    }

    #div_date {
      margin-left: 20px;
    }
  </style>
</head>

<div class="row" id="section_group_edit" style="display:block;">
    <div class="col-md-12">
        <!-- Event Settings -->
        <div class="box" id="section_group_edit_box">
            <div class="box-header with-border" id="svid_title">
                <h3 class="box-title"><?php echo "Read modbus"; ?></h3>
            </div>
            <!-- /.box-header --> 
                <div class="row c_box" id="svid_datas">  
                    <div class="col-md-10" style="overflow-x:auto;">
                    <select id="ui_dev" onchange="ChangeDev();return false;"></select> 
                  <table id="monitorTable" class="cell-border" style="width:100%">
                    <thead>
                    <tr>
                        <th>Modbus Slave value</th>
                        <th>SVID_ParaID</th>
                        <th>Parameter</th>
                        <th>原廠參數名稱/fins點位</th>
                        <th>Modbus Slave Address</th>
                        <th>Modbus Master Address</th>
                        <th>start bit</th>
                        <th>end bit</th>
                    </tr>
                    <tr>
                        <th><input type="text" placeholder="Search Modbus Slave value" /></th>
                        <th><input type="text" placeholder="Search SVID_ParaID" /></th>
                        <th><input type="text" placeholder="Search Parameter" /></th>
                        <th><input type="text" placeholder="Search 原廠參數名稱/fins點位" /></th>
                        <th><input type="text" placeholder="Search Modbus Slave Address" /></th>
                        <th><input type="text" placeholder="Search Modbus Master Address" /></th>
                        <th><input type="text" placeholder="Search start bit" /></th>
                        <th><input type="text" placeholder="Search end bit" /></th>
                    </tr>

                    </thead>
                    <tbody></tbody>
                  </table>
                  </div>
                  <div class="col-md-2" style="max-height: 550px; overflow: auto;">
                  </div>
                  </div>
                </div>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box-->
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->


<script src="/js/global.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/common.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/datamonitor_src/01-daterangepicker.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<link href="/js/datatables/datatables.min.css" rel="stylesheet">
<script src="/js/datatables/datatables.min.js"></script>
<script src="/js/datamonitorModbus_src/00-datamonitorModbus.js?date=<?php echo $UPDATE_DATE; ?>"></script>

<script>
  var test_mode = '<?php echo $TEST_MODE; ?>';
</script>

</html>
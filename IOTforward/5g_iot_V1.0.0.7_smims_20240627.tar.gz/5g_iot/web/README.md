
## 設定Apache2 目錄
---
### 設定目錄

``
sudo vi /etc/apache2/apache2.conf
``
```
<Directory />
	Options FollowSymLinks
	AllowOverride None
	Require all granted
</Directory>

<Directory /opt/5g_iot/web/>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
</Directory>
```
### 設定Port

``
sudo vi /etc/apache2/ports.conf
``
```
Listen 8000
```
### 設定虛擬目錄

``
sudo vi /etc/apache2/sites-available/000-default.conf
``
```
<VirtualHost *:8000>
        ServerAdmin webmaster@localhost
        DocumentRoot /opt/5g_iot/web
</VirtualHost>
```
``
sudo vi /etc/apache2/sites-enabled/000-default.conf
``
```
<VirtualHost *:8000>
        ServerAdmin webmaster@localhost
        DocumentRoot /opt/5g_iot/web
</VirtualHost>
```

### 設定使用者帳號

``
sudo vi /etc/apache2/envvars
``
```
export APACHE_RUN_USER="要設定有sudo 權限的linux的使用者 且不用打密碼"
```

### 設定tmp資料夾
``
sudo nano /usr/lib/systemd/system/apache2.service

PrivateTmp=false
```

### 重新啟動Apache2

``
$sudo apachectl restart
``


## 開啟PHP Sqlite [取消註解'#']
---
sudo vi /etc/php/7.4/apache2/php.ini
```
extension=sqlite3
```

## 建立資料夾
sudo mkdir /opt/tmp

## 設定資料夾權限
---
```
sudo chmod 777 /opt/tmp
sudo chmod 777 /opt/5g_iot/web/sqlite
sudo chmod 777 /opt/5g_iot/web/uploads
sudo chmod 777 /opt/5g_iot/config
sudo chmod 777 /tmp  
```

## 設定資料庫權限
---
```
sudo chmod 777 /opt/5g_iot/web/sqlite/5giot.db
```
### 將更新檔的shell指令
將 install.sh 放在 /opt下

###/etc/php/7.4/apache2 的php.ini改
upload_max_filesize = 300M
post_max_size = 300M

<?php
include('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
  <link href="/css/vils.min.css" rel="stylesheet">
  <link href="/css/main.css" rel="stylesheet">
  <link href="/css/jquery_ui_v1.13.2.css" rel="stylesheet">
  <title></title>

  <style>
    .dataTable {
      width: 1000px !important;
    }

    #account_table_body tr:nth-child(even) {
      background-color: #EEE;
    }

    #account_table_body tr td {
      text-align: center;
      padding: 10px 5px;
    }

    #account_table_body tr td i {
      margin: 0px 3px;
      cursor: pointer;
    }

    #dialog {
      overflow: hidden;
    }

    #dialog .row {
      padding: 5px 0px;
    }

    .ui-dialog-titlebar-close {
      display: none;
    }

    .cls_title {
      text-align: right;
    }

    input {
      border-radius: 5px;
      border: 1px solid #000;
      width: 65%;
    }

    i {
      padding: 0px 2px;
      cursor: pointer;
    }

  </style>

</head>

<div class="row" id="section_group_edit" style="display:block;">
  <div class="col-md-12">
    <!-- Event Settings -->
    <div class="box" id="section_group_edit_box">
      <div class="box-header with-border">
        <h3 class="box-title"><?php echo "帳號管理"; ?></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body" id="account_box_body">
        <button type="button" id="ui_add">新增</button>
        <table class="dataTable">
          <thead>
            <tr>
              <th style="width:80px;"></th>
              <th>帳號</th>
              <th>密碼</th>
              <th style="width:150px;">建立時間</th>
              <th style="width:150px;">修改時間</th>
            </tr>
          </thead>
          <tbody id="account_table_body">
          </tbody>
        </table>
      </div>
      <!-- /.box-body -->

    </div>
    <!-- /.box-->
  </div>
  <!-- /.col -->
</div>
<!-- /.row -->

<div id="dialog" class="container-fluid" title="新增帳號">
  <div class="row">
    <div class="col-md-4 cls_title">帳號:</div>
    <div class="col-md-8"><input type="text" id="dialog_id" /></div>
  </div>
  <div class="row justify-content-end">
    <div class="col-md-4 cls_title">密碼:</div>
    <div class="col-md-8">
      <input type="password" id="dialog_pwd" />
      <i class="fa fa-eye-slash" id="dialog_show_pwd"></i>
      <i class="fa fa-edit" id="dialog_edit_pwd"></i>
    </div>
  </div>
  <div class="row justify-content-end" id="dialog_check_row">
    <div class="col-md-4 cls_title">確認密碼:</div>
    <div class="col-md-8"><input type="password" id="dialog_check_pwd" /><i class="fa fa-eye-slash" id="dialog_show_check_pwd"></i></div>
  </div>
</div>

<script src="/js/global.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/account_src/00-account.js?date=<?php echo $UPDATE_DATE; ?>"></script>

</html>
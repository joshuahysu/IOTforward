<?php
include('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
    <link href="/css/vils.min.css" rel="stylesheet">
    <link href="/css/main.css?data=<?php echo $UPDATE_DATE; ?>" rel="stylesheet">
    <title></title>

    <style>
        .c_box_dpmitem {
            margin: 10px 0px;
        }

        .device_setting input[type=text] {
            margin-left: 5px;
            width: 250px !important;
        }

        #dpm_list tbody td {
            padding: 10px 5px;
        }

        #dpm_list tbody td i {
            margin: 0px 3px;
            cursor: pointer;
        }
    </style>

</head>

<div class="row" id="section_group_edit" style="display:block;">
    <div class="col-md-12">

        <div class="box" id="section_group_edit_box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo "設備型號通訊參數"; ?></h3>
            </div>

            <div class="box-body" id="account_box_body">
                <input type="button" value="存檔" id="btn_save" onclick="SaveDev();return false;" style="display:none;margin-left:13px;" />
                <div class="row c_box" id="dpm_list">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#ls_tab_com" data-toggle="tab"><span class="badge">DPM</span></a></li>
                                <li class=""><a href="#lg_tab_fins" data-toggle="tab"><span class="badge">FINS</span></a></li>
                                <li class=""><a href="#lg_tab_modbus" data-toggle="tab"><span class="badge">Modbus</span></a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active table-responsive" id="ls_tab_com">
                                    <div>
                                        <table class="dataTable">
                                            <thead id="head_com">
                                            </thead>
                                            <tbody id="body_com">
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td class="tfootAction">
                                                        <input type="button" value="新增" onclick="Show_devtypes_new('com');return false;" />
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane table-responsive" id="lg_tab_fins">
                                    <div>
                                        <table class="dataTable">
                                            <thead id="head_fins">
                                            </thead>
                                            <tbody id="body_fins">
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td class="tfootAction">
                                                        <input type="button" value="新增" onclick="Show_devtypes_new('fins');return false;" />
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane table-responsive" id="lg_tab_modbus">
                                    <div>
                                        <table class="dataTable">
                                            <thead id="head_modbus">
                                            </thead>
                                            <tbody id="body_modbus">
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td class="tfootAction">
                                                        <input type="button" value="新增" onclick="Show_devtypes_new('modbus');return false;" />
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12" style="display:none;">
                        <table>
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>機器型號</th>
                                    <th>DeviceType</th>
                                    <th>ConnectionType</th>
                                    <th>BaudRate</th>
                                    <th>DataBits</th>
                                    <th>Stop</th>
                                    <th>Parity</th>
                                    <th>ServerPort</th>
                                    <th>MapFile</th>
                                    <th>ReaderCode</th>
                                    <th>AnalogCode</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td class="tfootAction">
                                        <input type="button" value="新增" onclick="Show_devtypes_new();return false;" />
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

            <!-- /.box-body -->

        </div>
        <!-- /.box-->
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->

<script src="/js/global.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/devtypes_src/00-devtypes.js?date=<?php echo $UPDATE_DATE; ?>"></script>

</html>
<?php
session_start();

include ('checksession.php');

$path = ltrim($_SERVER['REQUEST_URI'], '/');    // Trim leading slash(es)
$elements = explode('/', $path);                // Split path on slashes

require_once('config.php');
require_once("php/common.php");

if(empty($elements[0]))
{                       
    // No path elements means home
    //ShowHomepage();
    echo 'normal';
} else if (array_shift($elements)) {
    //echo $elements[0];
    if ( isset($elements[0]) )
        $target = $elements[0];
    else
        $target = $elements;
    //如果有包含view_txt 導到view_txt?xxx的頁面
    if (gettype($target) === 'string' && strstr($target,'view_txt')) {
        $target='view_txt';
    }
    switch($target)             
    {
        case 'account':
            include('account.php');
            break;
        case 'setconfig':
            include('setconfig.php');
            break;
        case 'defsvid':
            include('defsvid.php');
            break;
        case 'devtypes':
            include('devtypes.php');
            break;
        case 'devinfo':
            include('devinfo.php');
            break;
        case 'devsvid':
            include('devsvid.php');
            break;
        case 'datamonitoring':
            include('datamonitoring.php');
            break;
        case 'datamonitorModbus':
            include('datamonitorModbus.php');
            break; 
        case 'eventlog':
            include('eventlog.php');
            break;
        case 'dataclear':
            include('dataclear.php');
            break;
        case 'login':
            include ('login.php');
            break;
        case 'systemImport':
            include ('systemImport.php');
            break;
        case 'servicemonitor':
            include ('servicemonitor.php');
            break;    
        case 'filesystem':
            include ('filesystem.php');
            break;
        case 'view_txt':
            include ('view_txt.php');
            break;                   
        default:
            include ('vils.php');
    }
}

?>
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">

    <!-- Sidebar Menu -->
    <ul class="sidebar-menu">

      <!-- Devices -->
      <li class="header"> 
          <span>
          <?php echo "<img src='/images/". $main_logo_small_file ."' class='img_logo' alt='5G IOT Logo' id='logo'>" ?>
          </span>
      </li>
                  <li class='treeview' id='treeview_system'>
                    <a href='#'>
                      <i class='fa fa-gear'></i> <span>系統設定</span>
                      <span class='pull-right-container'>
                        <i class='fa fa-angle-left pull-right'></i>
                      </span>
                    </a>
                    <ul class='treeview-menu'>
                      <li ><a href='javascript:void(0)' onclick='show_account();return false;'><i class='fa fa-user'></i> <span>帳號管理</span></a></li>
                      <li ><a href='javascript:void(0)' onclick='show_config();return false;'><i class='fa fa-gear'></i> <span>環境設定</span></a></li>
                    </ul>
                  </li>
                  <li class='treeview' id='treeview_device'>
                    <a href='#'>
                      <i class='fa fa-wrench'></i> <span>設備管理</span>
                      <span class='pull-right-container'>
                        <i class='fa fa-angle-left pull-right'></i>
                      </span>
                    </a>
                    <ul class='treeview-menu'>
                      <li ><a href='javascript:void(0)' onclick='show_defsvid();return false;'><i class='fa fa-wrench'></i> <span>1.Parameter總表</span></a></li>
                      <li ><a href='javascript:void(0)' onclick='show_devsvid();return false;'><i class='fa fa-wrench'></i> <span>2.設備Parameter Model Map</span></a></li>
                      <li ><a href='javascript:void(0)' onclick='show_devtypes();return false;'><i class='fa fa-wrench'></i> <span>3.設備型號通訊參數</span></a></li>
                      <li ><a href='javascript:void(0)' onclick='show_devinfo();return false;'><i class='fa fa-wrench'></i> <span>4.本機連結設備管理</span></a></li>
                      <li ><a href='javascript:void(0)' onclick='show_systemImport();return false;'><i class='fa fa-wrench'></i> <span>5.匯入匯出設備設定檔</span></a></li>
                    </ul>
                  </li>
                  <li class='treeview-log' id='treeview_log'>
                    <a href='#'>
                      <i class='fa fa-bar-chart'></i> <span>設備監控</span>
                      <span class='pull-right-container'>
                        <i class='fa fa-angle-left pull-right'></i>
                      </span>
                    </a>
                    <ul class='treeview-menu'>
                      <li ><a href='javascript:void(0)' onclick='show_datamonitor();return false;'><i class='fa fa-bar-chart'></i> <span>DataMonitoring</span></a></li>                      
                      <li ><a href='javascript:void(0)' onclick='show_datamonitorModbus();return false;'><i class='fa fa-bar-chart'></i> <span>DataMonitorModbus</span></a></li>                      
                      <li ><a href='javascript:void(0)' onclick='show_eventlog();return false;'><i class='fa fa-bar-chart'></i> <span>Event Log</span></a></li>
                      <li ><a href='javascript:void(0)' onclick='show_service_monitor();return false;'><i class='fa fa-bar-chart'></i> <span>ServiceMonitor</span></a></li>                    
                      <li ><a href='javascript:void(0)' onclick='show_filesystem();return false;'><i class='fa fa-bar-chart'></i> <span>FileSystem</span></a></li>                      
                    </ul>
                  </li>
                  </li>
                  <li class='treeview-clear' id='treeview_dataclaer'>
                    <!-- <a href='http://192.168.1.3/cgi-bin/index.cgi' target='_blank'>
                      <i class='fa fa-bar-chart'></i> <span>Serial port設備</span>
                    </a> -->
                    <a href='http://192.168.1.11' target='_blank'>
                      <i class='fa fa-bar-chart'></i> <span>Serial port設備</span>
                    </a>
                </li> 
          <li>
          <a href='https://192.168.1.254' target='_blank'>
                      <i class='fa fa-bar-chart'></i> <span>5G設備</span>
          </a>
          </li> 
    </ul>
    <!-- /.sidebar-menu -->
  </section>
  <!-- /.sidebar -->
</aside>
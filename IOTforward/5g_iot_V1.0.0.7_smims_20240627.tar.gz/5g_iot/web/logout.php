<?php
    session_start();
    unset($_SESSION["userid"]);
    // 重導到相關頁面
    header("Location: /index.php");
?>

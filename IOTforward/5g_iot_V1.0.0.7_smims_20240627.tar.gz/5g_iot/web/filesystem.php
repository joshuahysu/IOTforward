<table id="fileTable" class="cell-border" style="width:100%">
        <thead>
        <tr>
            <th>File name</th>            
        </tr>
        <tr>
            <th><input type="text" placeholder="Search file name" /></th>
        </tr>
        </thead>
        <tbody>             
        </tbody>
</table>
<script src="/js/global.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/common.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<link href="/js/datatables/datatables.min.css" rel="stylesheet">
<script src="/js/datatables/datatables.min.js"></script>
<script src="/js/filesystem_src/00-filesystem_src.js"></script>
<?php 
// openfold('/tmp/log');


// function openfold($folderPath){
//     //folderPath= '.'; // 替換為實際的資料夾路徑

//     // 使用 glob 函式取得符合條件的檔案列表
//     //GLOB_BRACE 参数告诉 glob 函数使用大括号扩展模式
//     $txtFiles = glob($folderPath . '/*.{txt,log,csv,pcap}', GLOB_BRACE);
//     if ($txtFiles !== false) {
//         $arr=[];
//         // print_r($txtFiles);
//         // 迴圈列出每個 txt 檔案的路徑
//         foreach ($txtFiles as $txtFile) {
//             // 取得檔案名稱
//             $fileName = basename($txtFile);
//             // 輸出file
//             array_push($ary, urlencode($folderPath.'/'.$fileName));
//             // 輸出連結
//             echo "<a href='view_txt.php?file=" . urlencode($folderPath.'/'.$fileName) . "'>" . $fileName . "</a><br>";
//         }
//         return json_encode($ary);
//     } else {
//         echo "找不到符合條件的檔案。";
//     }
// }
?>
<?php
include('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
  <link href="/css/vils.min.css?data=<?php echo $UPDATE_DATE; ?>" rel="stylesheet">
  <link href="/css/main.css?data=<?php echo $UPDATE_DATE; ?>" rel="stylesheet">
  <title></title>

  <style>
    #log_box_body .row>div {
      padding: 0px;
    }

    .log_monitor {
      background-color: #000;
      color: #0F0;
      font-size: 16px;
      font-weight: 600;
      width: 100%;
      height: 630px;
      resize: none;
      padding: 0px 20px;
    }

    #log_items {
      padding: 10px;
      background-color: #575656;
      color: #FFF;
      height: 630px;
      overflow-y: auto;
    }

    #log_items a {
      color: #FFF !important;
    }

    #log_items .treeview {
      font-size: 16px;
      border: 1px solid;
      cursor: pointer;
    }

    #log_items .treeview span {
      margin: 10px;
      line-height: 3;
    }

    #log_items .treeview-menu {
      padding-left: 0px;
    }

    #log_items .treeview-menu>li {
      background-color: #393737;
      border: 1px solid;
    }

    #log_items .treeview-menu>li>a {
      padding-left: 30px;
    }

    #log_items .treeview-menu>li>a {
      padding-left: 30px;
    }

    .logitem>a  {
      padding-left: 45px !important;
    }

    #div_date {
      margin-left: 20px;
    }
  </style>

</head>

<div class="row" id="section_group_edit" style="display:block;">
  <div class="col-md-12">
    <!-- Event Settings -->
    <div class="box" id="section_group_edit_box">
      <div class="box-header with-border">
        <h3 class="box-title"><?php echo "Event Log"; ?></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body" id="log_box_body">
        <!-- <div id="div_date">
          <span>查詢日期</span>
          <input type="text" id="ui_date" />
        </div> -->
        <div class="row c_box">
          <div class="col-sm-4 col-md-4 col-lg-4">
            <section class="sidebar">
              <ul class="sidebar-menu" id="log_items">
                <li class='treeview' id='treeview_system'>
                  <a href='#' onclick="showLogFiles(this, 'adlink_uptime');">
                    <i class='fa fa-file'></i><span>Uptime</span><i class="fa fa-angle-right"></i>
                  </a>
                </li>
                <li class='treeview' id='treeview_system'>
                  <a href='#' onclick="showLogFiles(this, 'adlink_activate');">
                    <i class='fa fa-file'></i><span>Activate</span><i class="fa fa-angle-right"></i>
                  </a>
                </li>
                <li class='treeview' id='treeview_system'>
                  <a href='#' onclick='showLogFiles(this, "secsgemservice");return false;'>
                    <i class='fa fa-file'></i><span>SECSGEM Service</span><i class="fa fa-angle-right"></i>
                  </a>
                </li>
                <!-- <li class='treeview' id='treeview_system'>
                  <a href='#' onclick='showLogFiles(this, "secsgemservice_pkt");return false;'>
                    <i class='fa fa-file'></i><span>SECSGEM pkt</span><i class="fa fa-angle-right"></i>
                  </a>
                </li> -->
                <!-- <li class='treeview' id='treeview_system'>
                  <a href='#' onclick='showLogFiles(this, "5grouter");return false;'>
                    <i class='fa fa-file'></i><span>5G Router</span><i class="fa fa-angle-right"></i>
                  </a>
                </li> -->
                <li class='treeview' id='treeview_system'>
                  <a href='#' onclick='showLogFiles(this, "modbusservice");return false;'>
                    <i class='fa fa-file'></i><span>Modbus Service</span><i class="fa fa-angle-right"></i>
                  </a>
                </li>

                <!-- <li class='treeview' id='treeview_system'>
                  <a href='#' onclick='showLogFiles(this, "alarmfunction");return false;'>
                    <i class='fa fa-file'></i><span>alarm function</span><i class="fa fa-angle-right"></i>
                  </a>
                </li> -->
           
                 <li class='treeview' id='treeview_system'>
                  <a href='#'>
                    <i class='fa fa-folder-o'></i><span>Device Disconnected</span>
                  </a>

                 <ul class='treeview-menu' id="device_items">
                   <li class='treeview' id='treeview_system'>
                      <a href='#'>
                        <i class='fa fa-folder-o'></i><span>DPM</span><i class="fa fa-angle-right"></i>
                      </a>
                      <ul class='treeview-menu' id="dpm_device">
                      </ul>
                    </li>
                          <!-- 
                    <li class='treeview' id='treeview_system'>
                      <a href='#'>
                        <i class='fa fa-folder-o'></i><span>FINS</span><i class="fa fa-angle-right"></i>
                      </a>
                      <ul class='treeview-menu' id="fins_device">
                      </ul>
                    </li>
                    <li class='treeview' id='treeview_system'>
                      <a href='#'>
                        <i class='fa fa-folder-o'></i><span>Modbus</span><i class="fa fa-angle-right"></i>
                      </a>
                      <ul class='treeview-menu' id="modbus_device">
                      </ul>
                    </li>  
                  </ul>
                </li> -->
              </ul>
            </section>
          </div>
          <div class="col-sm-8 col-md-8 col-lg-8">
            <textarea class='log_monitor' readonly="readonly" id="ui_monitor"></textarea>
          </div>
        </div>
      </div>


      <!-- /.box-body -->

    </div>
    <!-- /.box-->
  </div>
  <!-- /.col -->
</div>
<!-- /.row -->

<script src="/js/global.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/common.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/eventlog_src/00-eventlog.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/eventlog_src/01-daterangepicker.js?date=<?php echo $UPDATE_DATE; ?>"></script>

</html>
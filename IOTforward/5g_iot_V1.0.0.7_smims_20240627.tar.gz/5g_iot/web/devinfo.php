<?php
include ('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">
 <head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
   <link href="/css/vils.min.css" rel="stylesheet">
   <link href="/css/main.css?data=<?php echo $UPDATE_DATE; ?>" rel="stylesheet">
   <link href="/css/jquery_ui_v1.13.2.css" rel="stylesheet">
   <title></title>

   <style>

       .c_box_dpmitem {
           margin: 10px 0px;
       }

       .device_setting input[type=text] {
           margin-left: 5px;
           width: 250px !important;
       }

       #dpm_list tbody td {
           padding: 10px 5px;
       }

       #dpm_list tbody td {
           padding: 10px 5px;
       }

       #dpm_list tbody td:first-child {
        text-align: center;
       }

       #dpm_list tbody td i {
           margin: 0px 3px;
           cursor: pointer;
       }

       .device_setting {
           margin: 0px;
       }

       .info_block_0
       {
           background-color: rgba(190,190,190,0.4);
       }

       .info_block_1
       {
           background-color: rgba(190,190,190,0.7);
       }

       .info_block_2
       {
           background-color: rgba(190,190,190,0.8);
       }


   </style>

 </head>

       <div class="row" id="section_group_edit" style="display:block;">
         <div class="col-md-12">
           <!-- Event Settings -->
           <div class="box" id="section_group_edit_box">
             <div class="box-header with-border">
               <h3 class="box-title"><?php echo "本機連結設備管理";?></h3>
             </div>
             <!-- /.box-header -->
             <div class="box-body" id="account_box_body">
                 <input type="button" value="存檔" id="btn_save" onclick="SaveDevInfo();return false;" style="margin-left:13px;"/>
                 <div class="row c_box" id="dpm_list">
                     <div class="col-md-12">
                         <label style="padding-right:10px;">ToolID</label>
                         <input id="ui_toolid" type="text" style="width:auto;" />
                     </div>
                     <div class="col-sm-12 col-md-12 col-lg-12" style="margin-top:20px;padding:0px;">
                         <div class="nav-tabs-custom">
                           <ul class="nav nav-tabs">
                               <li class="active com"><a href="#ls_tab_com" data-toggle="tab"><span class="badge">DPM</span></a></li>
                               <li class="fin"><a href="#lg_tab_fins" data-toggle="tab"><span class="badge">FINS</span></a></li>
                               <li class="modbus"><a href="#lg_tab_modbus" data-toggle="tab"><span class="badge">Modbus</span></a></li>
                           </ul>
                           <div class="tab-content">
                               <div class="tab-pane active table-responsive" id="ls_tab_com">
                                   <div>
                                       <table class="dataTable">
                                           <thead id="head_com">
                                           </thead>
                                           <tbody id="body_com">
                                           </tbody>
                                           <tfoot>
                                               <tr>
                                                   <td class="tfootAction">
                                                       <input type="button" value="新增" onclick="Show_devtypes_new('com');return false;" />
                                                   </td>
                                               </tr>
                                           </tfoot>
                                       </table>
                                  </div>
                               </div>
                               <div class="tab-pane table-responsive" id="lg_tab_fins">
                                   <div>
                                       <table class="dataTable">
                                           <thead id="head_fins">
                                           </thead>
                                           <tbody id="body_fins">
                                           </tbody>
                                           <tfoot>
                                               <tr>
                                                   <td class="tfootAction">
                                                       <input type="button" value="新增" onclick="Show_devtypes_new('fins');return false;" />
                                                   </td>
                                               </tr>
                                           </tfoot>
                                       </table>
                                  </div>
                               </div>
                               <div class="tab-pane table-responsive" id="lg_tab_modbus">
                                   <div>
                                       <table class="dataTable">
                                           <thead id="head_modbus">
                                           </thead>
                                           <tbody id="body_modbus">
                                           </tbody>
                                           <tfoot>
                                               <tr>
                                                   <td class="tfootAction">
                                                       <input type="button" value="新增" onclick="Show_devtypes_new('modbus');return false;" />
                                                   </td>
                                               </tr>
                                           </tfoot>
                                       </table>
                                  </div>
                               </div>
                           </div>
                         </div>
                     </div>

                 </div>
             </div>
             <!-- /.box-body -->
           </div>
           <!-- /.box-->
         </div>
         <!-- /.col -->
       </div>
       <!-- /.row -->

       <div id="dialog">
           <iframe id="dialog_svid" style="width:100%;height:100%;"></iframe>
       </div>

   <script src="/js/global.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/common.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/map.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/devinfo_src/00-devinfo.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script>
        var test_mode = '<?php echo $TEST_MODE; ?>';
   </script>

</html>

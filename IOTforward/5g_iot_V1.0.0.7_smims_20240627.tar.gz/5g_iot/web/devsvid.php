<?php
include('checksession.php');
require_once('config.php');
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
    <link href="/css/vils.min.css" rel="stylesheet">
    <link href="/css/main.css?date=<?php echo $UPDATE_DATE; ?>" rel="stylesheet">
    <title></title>

    <style>
        .c_box_dpmitem {
            margin: 10px 0px;
        }

        .device_setting input[type=text] {
            margin-left: 5px;
            width: 250px !important;
        }

        #ui_svid_param tbody td {
            padding: 10px 5px;
        }

        #ui_svid_param tbody td {
            padding: 10px 5px;
        }

        #ui_svid_param tbody td i,
        #ui_def_svid_param tbody td i {
            margin: 0px 3px;
            cursor: pointer;
        }

        #ui_svid_param input[type=text] {
            width: 100%;
        }

        #ui_def_svid_body td {
            padding: 12px 5px;
            text-align: center;
        }

        .only_dev_svid {
            background-color: #e8e982 !important;
        }

        .diff_dev_svid {
            background-color: #f67777 !important;
        }

        .device_setting {
            margin: 0px;
        }

        .color_frame {
            display: table-row;
            margin-top: 10px;
        }

        .color_block {
            width: 20px;
            height: 15px;
            display: inline-block;
            margin: 0px 5px;
            border: 1px solid #888;
        }

        #ui_new_mapfile_name {
            margin-bottom: 10px;
        }

        #ui_def_svid_param {
            margin-top: 20px;
        }

        .color_block_content {
            display: table-cell;
            vertical-align: top;
        }

    </style>

</head>

<div class="row" id="section_group_edit" style="display:block;">
    <div class="col-md-12">
        <!-- Event Settings -->
        <div class="box" id="section_group_edit_box">
            <div class="box-header with-border" id="svid_title">
                <h3 class="box-title"><?php echo "設備Parameter Model Map"; ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div class="row c_box" id="svid_header">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-2">
                                <label>SVID範本</label>
                            </div>
                            <div class="col-md-10">
                                <select id="ui_dev" onchange="ChangeSvidSample();return false;"></select>
                            </div>
                        </div>
                        <!-- <div class="row">
                            <div class="col-md-2">
                                <label>客製化版mapfile</label>
                            </div>
                            <div class="col-md-10">
                                <select id="ui_dev_pri" onchange="ChangePriSvidSample();return false;"></select>
                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="row c_box" id="svid_datas">
                    <div class="col-md-12" id="ui_new_mapfile_name">
                    </div>
                    <div class="col-md-10" style="overflow-x:auto; max-height: 550px;">
                        <div class="color_frame">
                            <span class="color_block only_dev_svid"></span>
                            <span class="color_block_content">不存在Parameter總表</span>
                            <span class="color_block diff_dev_svid"></span>
                            <span class="color_block_content">與Parameter總表內容相異</span>
                        </div>
                        <table id='ui_svid_param' class="dataTable" style="margin-top:0px;overflow:auto;">
                            <thead id="ui_svid_head">
                            </thead>
                            <tbody id="ui_svid_body">
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td class="tfootAction" colspan="13">
            
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="col-md-2" style="max-height: 550px; overflow: auto;">
                        <table id='ui_def_svid_param' class="dataTable">
                            <thead id="ui_def_svid_head">
                                <tr>
                                    <th></th>
                                    <th>SVID_ParaID</th>
                                    <th>點位名稱</th>
                                </tr>
                            </thead>
                            <tbody id="ui_def_svid_body">
                            </tbody>
                        </table>
                    </div>
                    </div>

                    <input id="btn_save" type="button" value="存檔" onclick="saveSvid();" style="display:none;" />
                                        <input id="btn_del" type="button" value="刪除" onclick="delSvidModel();" style="display:none;color:#FFF;background-color:#d84848;" />
                                        <br />
                                        另存範本：<input type="text" id="ui_saveas" style="width:200px;" />
                                        <input id="btn_saveas" type="button" value="另存範本" onclick="saveasSvid();" />

                                        <div class="text-center">
                                        <button id="download" type="button">匯出csv</button>
                                        </div>
                    <form id="changeTableColumnValueForm" action="/php/devsvid.php" method="POST">   
                            <select name="changeTableColumnValue" id="changeTableColumnValue" style="width:200px; font-size: 14px; height:25.7px">
                            </select>

                            <!-- 文字框 -->
                            <input type="text" name="textbox" id="textbox" placeholder="請輸入想變更的數值" style="width:200px; font-size: 14px;">

                            <!-- 提交按鈕 -->
                            <button type="submit">更新</button>
                    </form>




                </div>
            </div>

            <!-- /.box-body -->

        </div>
        <!-- /.box-->
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->

<script>
    var glMapFile = '<?php echo $_GET['mapfile']; ?>';
    var glKey = '<?php echo $_GET['key']; ?>';
</script>

<!-- csv import to front end -->
<!-- <body>
  <input type="file" name="file" id="uploadFile" onchange="readCsv(this);" />
</body> -->

<script src="/js/global.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/common.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map.js?date=1<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE; ?>"></script>
<script src="/js/exportCsv.js"></script>
<script src="/js/devsvid_src/00-devsvid.js?date=<?php echo $UPDATE_DATE; ?>"></script>

</html>
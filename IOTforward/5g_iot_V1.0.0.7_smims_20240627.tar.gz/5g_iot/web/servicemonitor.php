<?php
// include ('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">
 <head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
   <!-- <link href="/css/vils.min.css" rel="stylesheet">
   <link href="/css/main.css?data=<?php echo $UPDATE_DATE; ?>" rel="stylesheet">
   <link href="/css/jquery_ui_v1.13.2.css" rel="stylesheet"> -->
   <title></title>
 </head>

 <p style="font-size: 120%;">  對上</p>
<div class="container">
  <div class="item">5giot_modbusserverservice</br><button id="reboot_service" onclick="reboot_service('5giot_modbusserverservice')">reboot_service</button><div id="5giot_modbusserverservice" class="light"></div></div>
  <div class="item">5giot_secsgem</br><button id="reboot_service" onclick="reboot_service('5giot_secsgem')">reboot_service</button><div id="5giot_secsgem" class="light"></div></div>
</div>

<p style="font-size: 120%;">  系統</p>

<div class="container">
  <div class="item">5giot_manager</br>
  <button id="reboot_service" onclick="reboot_service('5giot_manager')">reboot_service</button>  
  <div id="5giot_manager" class="light"></div></div>
  <div class="item">mosquitto</br>
  <button id="reboot_service" onclick="reboot_service('mosquitto')">reboot_service</button>
  <div id="mosquitto" class="light"></div></div>
</div>

<p style="font-size: 120%;">  對下設備</p>

<div class="container">
  <div class="item">5giot_fins2mqtt</br><button id="reboot_service" onclick="reboot_service('5giot_fins2mqtt')">reboot_service</button><div id="5giot_fins2mqtt" class="light"></div></div>

  <div class="item">5giot_dpm_ebara</br><button id="reboot_service" onclick="reboot_service('5giot_dpm_ebara')">reboot_service</button><div id="5giot_dpm_ebara" class="light"></div></div>

  <div class="item">5giot_dpm_edwards</br><button id="reboot_service" onclick="reboot_service('5giot_dpm_edwards')">reboot_service</button><div id="5giot_dpm_edwards" class="light"></div></div>

  <div class="item">5giot_dpm_ksy_sde_sdt_sdx_sdh</br><button id="reboot_service" onclick="reboot_service('5giot_dpm_ksy_sde_sdt_sdx_sdh')">reboot_service</button><div id="5giot_dpm_ksy_sde_sdt_sdx_sdh" class="light"></div></div>

  <div class="item">5giot_dpm_ksy_mu_ts</br><button id="reboot_service" onclick="reboot_service('5giot_dpm_ksy_mu_ts')">reboot_service</button><div id="5giot_dpm_ksy_mu_ts" class="light "></div></div>

<!-- <div class="item">
5giot_remove_log
<div id="5giot_remove_log" class="light"></div>
</div> -->

<!-- <div class="item">
5giot_simulator_ebara_esr_est_ev-s_ev-m
<div id="5giot_simulator_ebara_esr_est_ev-s_ev-m" class="light"></div>
</div> -->

<!-- <div class="item">
5giot_simulator_edwards
<div id="5giot_simulator_edwards" class="light"></div>
</div> -->

<!-- <div class="item">
5giot_simulator_fins<br>
<div id="5giot_simulator_fins" class="light"></div>
</div> -->

<!-- <div class="item">
5giot_simulator_ksy_sde_sdt_sdx_sdh<br>
<div id="5giot_simulator_ksy_sde_sdt_sdx_sdh" class="light"></div>
</div> -->

<!-- <div class="item">
5giot_simulator_ksy_mu_ts<br>
<div id="5giot_simulator_ksy_mu_ts" class="light "></div>
</div> -->

<!-- <div class="item">
5giot_simulator_modbus_server<br>
<div id="5giot_simulator_modbus_server" class="light"></div>
</div> -->

</div>

   <script src="/js/exportCsv.js"></script>
   <script src="/js/global.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/common.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/map.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/systemImport/00-systemImport.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script>
        var test_mode = '<?php echo $TEST_MODE; ?>';
   </script>

</html>
<script>

function reboot_service(service)
{
    let targetURL = gl_target_server + '/php/servicemonitor.php';
    let p = $.getJSON(targetURL, `rebootservice=1&service=${service}`)
        .done(data => {

        })
        .fail((jqXHR, textStatus, errorThrown) => {
            console.error('getJSON request failed: ' + textStatus, errorThrown);
        });
    
}



function toggleLights(id,active) {
    var tempDiv = document.getElementById(id);
      if(active==1){
        tempDiv.classList.remove("red");
        tempDiv.classList.add("green");
      }
      else{
        tempDiv.classList.remove("green");
        tempDiv.classList.add("red");
      }
}

// 定義一個函數，用於更新畫面
function updateScreen() {

// 設置要訪問的後端端點 URL
var url = "/php/servicemonitor.php?checkAllService=1";

// 使用 Fetch API 發送 GET 請求
fetch(url).then(function(response) {
        // 檢查響應是否成功
        if (!response.ok) {
            throw new Error("Network response was not ok");
        }
        // 解析 JSON 數據
        return response.json();
    })
    .then(function(data) {
        // 在這裡處理後端返回的數據，更新畫面等操作
        console.log(data);
        data.forEach(function(element, index) {
        console.log("Element: " + element + ", Index: " + index);

        switch (element.name) {
          case "5giot_manager.service":
            toggleLights("5giot_manager",element.active)
            break;
          case "5giot_modbusserverservice.service":
            toggleLights("5giot_modbusserverservice",element.active)
            break;
          case "5giot_secsgem.service":
            toggleLights("5giot_secsgem",element.active)
            break;
          case "5giot_fins2mqtt.service":
            toggleLights("5giot_fins2mqtt",element.active)
            break;
          case "mosquitto.service":
            toggleLights("mosquitto",element.active)          
            break;
          case "5giot_simulator_edwards.service":
          //toggleLights("5giot_simulator_edwards",element.active)          
          break;
          case "5giot_dpm_ksy_sde_sdt_sdx_sdh.service":
          toggleLights("5giot_dpm_ksy_sde_sdt_sdx_sdh",element.active)          
          break;
          case "5giot_dpm_ebara.service":
          toggleLights("5giot_dpm_ebara",element.active)          
          break;
          case "5giot_remove_log.service":
          // toggleLights("5giot_remove_log",element.active)          
          break;
          case "5giot_simulator_ebara_esr_est_ev-s_ev-m.service":
          //toggleLights("5giot_simulator_ebara_esr_est_ev-s_ev-m",element.active)          
          break;
          case "5giot_dpm_edwards.service":
          toggleLights("5giot_dpm_edwards",element.active)          
          break;
          case "5giot_simulator_fins.service":
          //toggleLights("5giot_simulator_fins",element.active)          
          break;
          case "5giot_simulator_modbus_server.service":
          //toggleLights("5giot_simulator_modbus_server",element.active)          
          break;
          case "5giot_simulator_ksy_sde_sdt_sdx_sdh.service":
          //toggleLights("5giot_simulator_ksy_sde_sdt_sdx_sdh",element.active)          
          break;
          case "5giot_dpm_ksy_mu_ts.service":
          toggleLights("5giot_dpm_ksy_mu_ts",element.active)          
          break;
          case "5giot_simulator_ksy_mu_ts.service":
          toggleLights("5giot_simulator_ksy_mu_ts",element.active)          
          break;

          
        }
        });
    })
    .catch(function(error) {
        // 請求失敗
        console.error("Fetch failed:", error.message);
    });

}
updateScreen();
// 設置定時器，每隔一段時間執行一次 updateScreen 函數
var intervalId = setInterval(updateScreen, 20000); // 每隔 1 秒執行一次
</script>

<style type="text/css">
.light {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  margin: 10px;
}

.red {
  background-color: red;
}

.yellow {
  background-color: yellow;
}

.green {
  background-color: green;
}
.hidden {
  display: none;
}

  .container {
    display: grid;
    grid-template-columns:1fr 1fr 1fr 1fr 1fr;
    grid-template-rows:120px;
    grid-gap:10px;
    padding:10px;
  }
  .item{
  border:1px solid black;
  }

</style>

<?php

// Report simple running errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);

if (session_status() != PHP_SESSION_ACTIVE) {
    session_start();
}

if (!isset($_SESSION['userid'])) {
    header('Location: /login.php');
    
}

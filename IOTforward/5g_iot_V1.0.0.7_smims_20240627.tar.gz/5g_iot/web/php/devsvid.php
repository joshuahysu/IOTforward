<?php

require_once("common.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];
// console_log((string)$method);
// console_log((string)isset($_POST['submit']));

switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();        
        break;
    case 'submit':
        break;
}

function Do_GET()
{
    if (isset($_GET["loaddevinfo"])) {
        echo loaddevinfo();
    } else if (isset($_GET["loadsvidsemple"])) {
        echo loadsvidsemple();
    } else if (isset($_GET["loaddevsviddata"])) {
        $key = $_GET["key"];
        echo loaddevsviddata($key);
    } else if (isset($_GET["loadsvidparam"])) {
        echo loadsvidparam();
    }
}

function Do_POST()
{
    // $ary = [];
    $func = $_POST["func"];
    // array_push($ary, $func);
    switch ($_POST["func"]) {
        case 'savesvid':
            $filename = $_POST["filename"];
            $data = json_decode($_POST["data"]);
            savesvid($filename, $data);
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
        case 'delSvidModel':
            $modelName = $_POST["modelname"];
            delSvidModel($modelName);
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
    }
    if(isset($_POST['changeTableColumnValue'])) {
        changeTableColumnValue($_POST['changeTableColumnValue'],$_POST['textbox']);
        echo '{"code":"200","msg":"ok","detail":""}';
    }
}


function changeTableColumnValue($tableColumn, $value)
{
    $sql="";
    if($_POST["filename"]!='None'){
        $sql = "update svidinfo set ".$tableColumn." = '".$value."' where class = '".$_POST["filename"]."'";
    }
    else{
        $sql = "update svidinfo set ".$tableColumn." = '".$value."'";
    }
    echo $sql;
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}


function loaddevinfo() {
    $sql = 'SELECT * FROM deviceinfo; ';
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}

function loadsvidsemple() {
    $sql = "SELECT DISTINCT class, private FROM svidinfo WHERE class != 'def'; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}

function loaddevsviddata($key) {
    $sql = "SELECT * FROM svidinfo WHERE class = 'def'; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    $ary["def"] = [];
    $ary[$key] = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary["def"], $row);
    }

    $sql = "SELECT * FROM svidinfo WHERE class = '".$key."'; ";
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($ary[$key], $row);
    }

    $db->closeSqlite();
    return json_encode($ary);
}

function savesvid($filename, $data)
{
    $sql = "DELETE FROM svidinfo WHERE class = '".$filename."'; ";
    foreach ($data as $key => $value) {
        foreach ($value as $v) {
            $sql .= "INSERT INTO svidinfo ('class', 'uid', 'parameterid', 'remark', 'serveraddress', 'serverfunctioncode', 'num', 'address', 'functioncode', 'readfreq', 'tagname', 'scaletype', 'scalemultiple', 'scaleoffset', 'unit', 'max', 'min', 'signed', 'fixed', 'mergemode', 'startbit', 'endbit', 'endian', 'valuetype', 'intnum') ";
            $sql .= "VALUES ('".$filename."', '".$v->uid."', '".$v->parameterid."', '".$v->remark."', '".$v->serveraddress."','".$v->serverfunctioncode."','".$v->num."','".$v->address."','".$v->functioncode."','".$v->readfreq."','".$v->tagname."','".$v->scaletype."','".$v->scalemultiple."','".$v->scaleoffset."','".$v->unit."','".$v->max."','".$v->min."','".$v->signed."','".$v->fixed."','".$v->mergemode."','".$v->startbit."','".$v->endbit."','".$v->endian."','".$v->valuetype."','".$v->intnum."'); ";
        }
    }
    // writeLogFile([$filename], "text.txt");
    //echo $sql."<br>";
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}
function delSvidModel($modelName)
{
    $sql = "DELETE FROM svidinfo WHERE class = '".$modelName."'; ";
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

function loadsvidparam()
{
    $sql = "SELECT remark, parameterid FROM svidinfo WHERE class = 'def'; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}

function console_log($output, $with_script_tags = true) {
    $js_code = 'console.log(' . json_encode($output, JSON_HEX_TAG) .
    ');';
    if ($with_script_tags) {
    $js_code = '<script>' . $js_code . '</script>';
    }
    echo $js_code;
    }

?>

<?php

class SQLiteDB extends SQLite3
{
   function __construct($path = '')
   {
        if ($path == '')
            $this->open('../sqlite/5giot.db');
        else
            $this->open($path);
        // return SQLiteDB::ConnectSqlite();
   }

   // Connect Sqlite
   function ConnectSqlite() {
       $db = new SQLiteDB();
       if(!$db){
          // echo $db->lastErrorMsg();
       } else {
          // echo "Yes, Opened database successfully\r\n";
       }
   }

   // Query datas
   function QueryDatas($sql) {
       $ret = $this->query($sql);
       if (!$ret) {
           // echo $this->lastErrorMsg();
       } else {
           // echo "888";
       }
       return $ret;
   }

   // Execute Sql Command
   function ExecuteSql($sql) {
       $this->busyTimeout(5000);
       $ret = $this->exec($sql);
       if (!$ret) {
           // echo $this->lastErrorMsg();
       } else {
           // echo "Yes, Command Execute successfully<br/>\n";
       }
   }

   // Close
   function closeSqlite() {
       $this->close();
       unset($db);
   }
}
?>
<?php 

require_once("common.php");
require_once("../config.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];
//DelAccount('5');
switch ($method) {
    case 'GET':
        Do_GET();
        break;
    case 'POST':
        Do_POST();
        break;
    case 'PUT':
        break;
}

function Do_GET() {
    $fun = $_GET['fun'];
    switch ($fun) {
        case 'loadaccount':
            echo LoadAccount();
            break;
            
    }
}

function Do_POST() {
    $fun = $_POST['fun'];
    switch ($fun) {
        case 'saveaccount':
            $key = $_POST['id'];
            $id = $_POST['userid'];
            $pwd = $_POST['pwd'];
            SaveAccount($key, $id, $pwd);
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
        case 'delaccount':
            $key = $_POST['id'];
            DelAccount($key);
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
    }
}

function LoadAccount() {
    $sql = 'select * from userdata; ';
    $db = new SqliteDB();
    $ret = $db->QueryDatas($sql);
    $data = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($data, $row);
    }
    $db->closeSqlite();
    return json_encode($data);
}

function SaveAccount($key, $id, $pwd) {
    $sql = '';
    if ($key == '-1') {
        $sql = "insert into userdata('userid', 'pwd', 'createtime', 'modifytime') values('".$id."', '".$pwd."', strftime('%Y/%m/%d %H:%M:%S','now', 'localtime'), strftime('%Y/%m/%d %H:%M:%S','now', 'localtime')); ";
    } else {
        $sql = "update userdata set userid = '".$id."', pwd = '".$pwd."', modifytime = strftime('%Y/%m/%d %H:%M:%S','now', 'localtime') where id = '".$key."'; ";
    }
    $db = new SqliteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

function DelAccount($key) {
    $sql = "delete from userdata where id = '".$key."'; ";
    //echo $sql."<br>";
    $db = new SqliteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

?>
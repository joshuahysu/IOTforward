<?php

require_once("common.php");
require_once("../config.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}

function Do_GET()
{
    if (isset($_GET["loaddevinfo"])) {
        echo loaddevinfo();
    } else if (isset($_GET["loadsvidsemple"])) {
        echo loadsvidsemple();
    } else if (isset($_GET["loaddevsviddata"])) {
        $key = $_GET["key"];
        echo loaddevsviddata($key,$_GET["modbusn"]);
    } else if (isset($_GET["loadsvidparam"])) {
        echo loadsvidparam();
    }
}

function Do_POST()
{
    $func = $_POST["func"];
    switch ($_POST["func"]) {
        case 'loaddeviceitems':
            echo LoadDeviceItems();
            break;            
    }
}

function loaddevinfo() {
    $sql = "SELECT * FROM deviceinfo where devicetype<>'DPM';";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}
function loadsvidsemple() {
    $sql = "SELECT DISTINCT class, private FROM svidinfo WHERE class != 'def'; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}

function loaddevsviddata($key,$modbusn) {
    // $sql = "SELECT * FROM svidinfo WHERE class = 'def'; ";
    $db = new SQLiteDB();
    // $ret = $db->QueryDatas($sql);
    $ary = [];
    $ary["def"] = [];
    $ary[$key] = [];
    // while ($row = $ret->fetchArray(1)) {
    //     array_push($ary["def"], $row);
    // }


    $sql = <<<EOF
    SELECT 
    t1.parameterid,t1.remark,
    printf('%0*d', length(t1.serveraddress), CAST(REPLACE(t1.serveraddress, 'N', CAST(t2.modbusn AS CHAR(255))) AS INT)) AS serveraddress,
    t1.serverfunctioncode,printf('%0*d', length(t1.address), CAST(t1.address AS INTEGER) - d.base01) AS address,
    t1.num,t1.functioncode,t1.readfreq,t1.tagname,t1.scaletype,t1.scalemultiple,t1.scaleoffset,t1.unit,t1.max,
    t1.min,t1.signed,t1.fixed,t1.startbit,t1.endbit 
    FROM svidinfo t1
    JOIN deviceinfo t2 ON t2.mapfile = '$key' AND t1.class = t2.mapfile AND t2.modbusn = '$modbusn'
    JOIN devicedef d ON d.mapfile = t1.class AND t1.class = '$key';
    EOF;
    //echo $sql;

    // $sql = "SELECT * FROM svidinfo WHERE class = '".$key."'; ";
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($ary[$key], $row);
    }

    $db->closeSqlite();
    return json_encode($ary);
}
?>

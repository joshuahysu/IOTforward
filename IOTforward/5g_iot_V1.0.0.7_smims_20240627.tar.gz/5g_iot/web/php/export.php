<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once("common.php");
require_once("../config.php");
require_once("sqlite3.php");

$csvFds = [];
$csvDatas = [];
$csvFileName = "";

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        break;
}
function Do_GET()
{
    if (isset($_GET["getservercsv"])) {
        GetCsvInfo("secsserver");
        GetCsvInfo("modbusserver");
        echo '{"code":"200","msg":"ok","detail":""}';
    } else if (isset($_GET["getdevicecsv"])) {
        GetCsvInfo("device");
        GetCsvInfo("mapfile");
        echo '{"code":"200","msg":"ok","detail":""}';
    } else if (isset($_GET["editmapfile"])) {

    } else if (isset($_GET["full"])) {
        DeleteAllCsv();
        GetCsvInfo("secsserver");
        //echo '{"code":"200","msg":"ok","detail":"secsserver4"}';
        GetCsvInfo("modbusserver");
        //echo '{"code":"200","msg":"ok","detail":"modbusserver"}';
        GetCsvInfo("device");
        //echo '{"code":"200","msg":"ok","detail":"device"}';
        GetCsvInfo("mapfile");
        //echo '{"code":"200","msg":"ok","detail":"mapfile2"}';
        //GetCsvInfo("modbus_client");           
        echo '{"code":"200","msg":"ok","detail":""}';
    } else if (isset($_GET["getorigincsv"])) {
        GetCsvInfo("originmapfile");
        echo '{"code":"200","msg":"ok","detail":""}';
    }

}



function DeleteAllCsv()
{
    // 执行 shell 命令
    $command = 'sudo find /opt/5g_iot/config -type f -name "*.csv" -delete';
    $output = [];
    $returnCode = 0;    
    // 使用 shell_exec 执行命令
    $output = shell_exec($command);    

    // 执行 shell 命令
    $command = 'sudo find /opt/5g_iot/config/mapfile -type f -name "*.csv" -delete';
    $output = [];
    $returnCode = 0;    
    // 使用 shell_exec 执行命令
    $output = shell_exec($command);  

}
    
    
function console_log($output, $with_script_tags = true) {
    $js_code = 'console.log(' . json_encode($output, JSON_HEX_TAG) .
    ');';
    if ($with_script_tags) {
    $js_code = '<script>' . $js_code . '</script>';
    }
    echo $js_code;
}


function GetCsvInfo($type)
{
    global $dev_config_path, $dev_config_mapfile_path, $dev_secsgem_config_path, $dev_modbus_config_path, $csvFileName, $csvFds, $csvDatas,$gconnectiontype;

    checkFolderExists($dev_config_path);
    checkFolderExists($dev_config_mapfile_path);
    checkFolderExists($dev_secsgem_config_path);
    checkFolderExists($dev_modbus_config_path);

    switch ($type) {
        case 'secsserver':
            $csvFileName = $dev_secsgem_config_path . "secsequipconfig.csv";
            GetCsvFields("secs");
            //GetCsvDatas("secs");
            $csvDatas = [["0.0.0.0,5000,5001,224.0.0.1,19999","","","GIOT-GW/FIVEGIOT/UL,MDLN-A","000001","10","/opt/5g_iot/config/deviceinfo.csv"]];
            exportCsv();
            break;
        case 'modbusserver':
            $csvFileName = $dev_config_path . "modbusserverconfig.csv";
            GetCsvFields("modbusserverconfig");
            GetCsvDatas("modbusserverconfig");
            exportCsv();

            $csvFileName = $dev_modbus_config_path . "config.csv";
            GetCsvFields("config");
            $csvDatas = [["224.0.0.1,19999","","","GIOT-GW/FIVEGIOT/UL","000001","/opt/5g_iot/config/modbusserverconfig.csv","/opt/5g_iot/config/deviceinfo.csv"]];
            exportCsv();
            break;
        case 'device':
            GetCsvFields("deviceinfo");
            GetCsvDatas("deviceinfo");
            $csvFileName = $dev_config_path . "deviceinfo.csv";
            exportCsv();
            break;       
        case 'mapfile':
            global $gmodbusn;
            $mapfileList = [];
            $configList = [];
            GetCsvFields("mapfile");
            $sql = "select * from deviceinfo; ";
            $db = new SQLiteDB();
            $ret = $db->QueryDatas($sql);

            while ($row = $ret->fetchArray(1)) {

                //print_r($row);
	            //GetCsvFields("mapfile");

                //Server CSV
                if ($row["mapfile"] != null && $row["mapfile"] != '' && $row["mapfile"] != 'None') {
                    $csvFileName = $row["mapfile"];
                    $gconnectiontype=$row["connectiontype"];
                    if (!in_array($csvFileName, $mapfileList)&&empty($row["modbusn"])) {
                        array_push($mapfileList, $csvFileName);
                        $gmodbusn=$row['modbusn'];
                        if($row["connectiontype"]=="Modbus TCP"){                            
                            GetCsvFields("new_mapfile");
                            GetCsvDatas("new_mapfile", $csvFileName);
                        }
                        elseif($row["connectiontype"]=="Modbus RTU"){
                            GetCsvFields("mapfile");
                            GetCsvDatas("mapfile", $csvFileName);
                        }
                        elseif($row["connectiontype"]=="COM"){
                            GetCsvFields("new_dpm_mapfile");
                            GetCsvDatas("new_dpm_mapfile", $csvFileName);
                        }
                        elseif($row["connectiontype"]=="FINS"){
                            GetCsvFields("new_mapfile");
                            GetCsvDatas("new_mapfile", $csvFileName);
                        }

                        for ($i = 0; $i < count($csvDatas); $i++) {
                            unset($csvDatas[$i]["mergemode"]);
                        }

                        $csvFileName = $dev_config_mapfile_path . $csvFileName . ".csv";
                        //產生mapfile檔案，當有modbusn時會多產生一個無意義檔案
                        exportCsv(); 
                    }




                    //這裡要把modbusn注入
                    //取deviceinfo把modbus的N值取出來
                    //對 deviceinfo和svidinfo做join
                    //將svidinfo 的 N取代為deviceinfo的N
                    //輸出csv
            
                    if($row['modbusn']!= ''&&$row["modbusn"] != null){
                        $csvFileName = $row["mapfile"];
                        //echo $csvFileName;   
                        $gmodbusn=$row['modbusn'];
                        if($row["connectiontype"]=="Modbus TCP"){
                            GetCsvFields("new_mapfile");
                            GetCsvDatas("new_mapfile", $csvFileName);
                        }
                        elseif($row["connectiontype"]=="Modbus RTU"){
                            GetCsvFields("mapfile");
                            GetCsvDatas("modbusNmapfile",$csvFileName);
                        }
                        elseif($row["connectiontype"]=="FINS"){
                            GetCsvFields("new_mapfile");
                            GetCsvDatas("new_mapfile", $csvFileName);
                        }
                        elseif($row["connectiontype"]=="COM"){
                            GetCsvFields("new_dpm_mapfile");
                            GetCsvDatas("new_dpm_mapfile", $csvFileName);
                        }
                        $csvFileName = $dev_config_mapfile_path . $csvFileName .$gmodbusn. ".csv";
                        exportCsv();  
                        }
                }
            

                //Deivce CSV [DPM]
                if ($row["readercode"] != null && $row["readercode"] != '') {
                    if (!in_array($row["readercode"], $configList)) {
                        array_push($configList, $row["readercode"]);
                        $csvFileName = $row["readercode"];
                        switch ($row["readercode"]) {
                            case 'EBARA_ESR_EST_EV-S_EV-M':
                                exportCsvByEBARA();
                                break;
                            case 'EDWARDS':
                                exportCsvByEDWARDS();
                                break;
                            case 'KSY_MU_TS':
                                exportCsvByKSY_MU_TS();
                                break;
                            case 'KSY_SDE_SDT_SDX_SDH':
                                exportCsvByKSY_SDE_SDT_SDX_SDH();
                                break;
                        }
                    }
                }
            }

            $csvFileName = "modbus_client";
            exportCsvBymodbus_servicecsv();

            //Device CSV [FINS]
            $sql = "select count(1) from deviceinfo where connectiontype = 'FINS'; ";
            $ret3 = $db->QueryDatas($sql);
            $total = 0;

            if ($ret3) {
            while ($row = $ret3->fetchArray(1)) {
                $total = intval(implode(",", $row));
                if ($total > 0) {
                    $csvFileName = "fins2mqtt";
                    exportCsvByfins_servicecsv();
                    //echo "exportCsvByfins_servicecsv";
                }
            }
            }   

            $db->closeSqlite();
            break;
        
        case 'originmapfile':
            GetCsvFields("mapfile");
            $sql = "select distinct class from svidinfo where class <> 'def'; ";
            $db = new SQLiteDB();
            $ret = $db->QueryDatas($sql);
            while ($row = $ret->fetchArray(1)) {
                //Server CSV
                $csvFileName = $dev_config_mapfile_path . $row["class"] . ".csv";
                GetCsvDatas("origin", $row["class"]);
                exportCsv();
            }
            $db->closeSqlite();
            break;
        default:
            // code...
            break;
    }
}

function GetCsvFields($type)
{
    global $csvFileName, $csvFds, $csvDatas;
    switch ($type) {
        case 'secs':
            $csvFds = ["ip", "FDCport", "ITport", "MQMCAddress", "MQMCPort", "MQMCUser", "MQMCPassword", "MQMCPrefix", "MDLN", "SOFTREV", "SessionId", "DeviceInfoFile"];
            break;
        case 'deviceinfo':
            $csvFds = ["#Name", "ToolID", "DPM_ID", "Chamber_ID", "Parameter_ID", "DeviceType", "ConnectionType", "StationId", "SlavePort", "SlaveBaud", "DataBits", "Stop", "Parity", "ServerIp", "ServerPort", "MapFile"];
            break;
        case 'config':
            $csvFds = ["MQMCAddress", "MQMCPort", "MQMCUser", "MQMCPassword", "MQMCPrefix", "SOFTREV", "ModbusServerConfigFile", "DeviceInfoFile"];
            break;
        case 'modbusserverconfig':
            $csvFds = ["Ip", "Port", "StationId", "ToolID", "DPM_ID", "Chamber_ID", "Parameter_ID", "DeviceType", "MapFile"];
            break;
        case 'mapfile':
            $csvFds = ["Parameter_ID", "ServerAddress", "ServerFunctionCode", "Address", "Num", "FunctionCode", "ReadFreq", "Name", "ScaleType", "ScaleMultiple", "ScaleOffset", "Unit", "Max", "Min", "Signed", "Fixed","StartBit","EndBit"];
            break;
        case 'fins-mapfile':
            $csvFds = ["Parameter_ID", "ServerAddress", "ServerFunctionCode", "Address", "Num", "FunctionCode", "ReadFreq", "Name", "ScaleType", "ScaleMultiple", "ScaleOffset", "Unit", "Max", "Min", "Signed", "Fixed","StartBit","EndBit"];
            break;
        case 'new_mapfile':
            $csvFds = ["Parameter_ID", "ServerAddress", "ServerFunctionCode", "Num", "Endian", "ValueType", "IntNum", "Fixed"];
            break;
        case 'new_dpm_mapfile':
            $csvFds = ["Parameter_ID", "ServerAddress", "ServerFunctionCode", "Num", "Endian", "ValueType"];
            break;
        }
}

function GetCsvDatas($type, $filename = "")
{
    global $dev_config_mapfile_path, $csvFileName, $csvFds, $csvDatas,$gmodbusn,$gconnectiontype;
    $csvDatas = [];

    $db = new SQLiteDB();

    switch ($type) {
        case 'secs':
            $sql = <<<EOF
                select 
                    ip, fdcport, itport, mqttaddress, mqttport, mqttuser, mqttpassword, mqttprefix, mdln, softrev, sessionid, deviceinfofile 
                from config;
            EOF;
            break;
        case 'deviceinfo':
            $sql = <<<EOF
                select 
                    name, toolid, dpmid, chamberid, parameterid, devicetype, 
                    case connectiontype when 'Modbus TCP' then 'MODBUSTCP' when 'Modbus RTU' then 'MODBUSRTU' else connectiontype end as connectiontype, 
                    devicestationid, slaveport, baudrate, databits, stop, parity, 
                    deviceip, deviceport,
                    CASE 
                    WHEN connectiontype = 'Modbus TCP' or connectiontype ='Modbus RTU' or connectiontype ='FINS' THEN '/opt/5g_iot/config/mapfile/' || mapfile || modbusn || '.csv' 
                    ELSE '$dev_config_mapfile_path' || mapfile ||'.csv' 
                END AS mapfile 
                from deviceinfo;
            EOF;
            //echo $sql."<br>";
            break;
        case 'config':
            $sql = <<<EOF
                select 
                    mqttaddress, mqttport, mqttuser, mqttpassword, mqttprefix, softrev, modbusserverconfigfile, deviceinfofile 
                from config;
            EOF;
            break;
        case 'modbusserverconfig':
            $sql = <<<EOF
                select 
                    --case devicetype when 'DPM' then '127.0.0.1' else serverip end as serverip, 
                    --case devicetype when 'DPM' then '502' else serverport end as serverport, 
                    --case devicetype when 'DPM' then ROW_NUMBER() OVER(ORDER BY id) else serverstationid end as stationid, 
                    serverip, serverport, serverstationid, toolid, dpmid, chamberid, parameterid, devicetype, '$dev_config_mapfile_path' || mapfile|| modbusn || '.csv' 
                from deviceinfo;
            EOF;
            break;
        case 'mapfile':
            if ($filename == '')
                $sql = <<<EOF
                SELECT s.parameterid, 
                printf('%0*d', length(s.serveraddress), CAST(s.serveraddress AS INTEGER)) AS serveraddress, 
                s.serverfunctioncode, 
                printf('%0*d', length(s.address), CAST(s.address AS INTEGER) - d.base01) AS address, 
                s.num,s.functioncode,s.readfreq,s.tagname,s.scaletype,s.scalemultiple,s.scaleoffset,s.unit,s.max,s.min,s.signed, 
                s.fixed,s.startbit,s.endbit 
                FROM svidinfo s JOIN devicedef d ON d.mapfile = s.class AND s.class <> 'def';
                EOF;
            else {
                $sql = <<<EOF
                SELECT s.parameterid, 
                printf('%0*d', length(s.serveraddress), CAST(s.serveraddress AS INTEGER)) AS serveraddress, 
                s.serverfunctioncode, 
                printf('%0*d', length(s.address), CAST(s.address AS INTEGER) - d.base01) AS address, 
                s.num,s.functioncode,s.readfreq,s.tagname,s.scaletype,s.scalemultiple,s.scaleoffset,s.unit,s.max,s.min,s.signed, 
                s.fixed,s.startbit,s.endbit 
                FROM svidinfo s JOIN devicedef d ON d.mapfile = s.class AND s.class = '$filename';
                EOF;
            }
            break;
        case 'new_mapfile':  
            $sql = <<<EOF
            SELECT
            t1.parameterid,
            printf('%0*d', length(t1.serveraddress), CAST(REPLACE(t1.serveraddress, 'N', CAST(t2.modbusn AS CHAR(255))) AS INT)) AS serveraddress,
            t1.serverfunctioncode,t1.num,t1.endian,t1.valuetype,t1.intnum,t1.fixed
            FROM svidinfo t1
            JOIN deviceinfo t2 ON t2.mapfile = '$filename' AND t1.class = t2.mapfile AND t2.modbusn = '$gmodbusn'
            JOIN devicedef d ON d.mapfile = t1.class AND t1.class = '$filename';
            EOF;                
            break;

        case 'new_dpm_mapfile':  
            $sql = <<<EOF
            SELECT
            t1.parameterid,
            printf('%0*d', length(t1.serveraddress), CAST(REPLACE(t1.serveraddress, 'N', CAST(t2.modbusn AS CHAR(255))) AS INT)) AS serveraddress,
            t1.serverfunctioncode,t1.num,t1.endian,t1.valuetype
            FROM svidinfo t1
            JOIN deviceinfo t2 ON t2.mapfile = '$filename' AND t1.class = t2.mapfile AND t2.modbusn = '$gmodbusn'
            JOIN devicedef d ON d.mapfile = t1.class AND t1.class = '$filename' AND d.connectiontype='$gconnectiontype'
            GROUP BY t2.modbusn, t1.parameterid ;
            EOF;                
            break;
        case 'fins-for-modbus-mapfile':
            if ($filename == '')
                $sql = <<<EOF
                SELECT s.parameterid, 
                printf('%0*d', length(s.serveraddress), CAST(s.serveraddress AS INTEGER)) AS serveraddress, 
                s.serverfunctioncode, 
                printf('%0*d', length(s.address), CAST(s.address AS INTEGER) - d.base01) AS address, 
                s.num,s.functioncode,s.readfreq,s.tagname,s.scaletype,s.scalemultiple,s.scaleoffset,s.unit,s.max,s.min,s.signed, 
                s.fixed,'' as startbit,'' as endbit
                FROM svidinfo s JOIN devicedef d ON d.mapfile = s.class AND s.class <> 'def';
                EOF;
            else {
                $sql = <<<EOF
                SELECT s.parameterid, 
                printf('%0*d', length(s.serveraddress), CAST(s.serveraddress AS INTEGER)) AS serveraddress, 
                s.serverfunctioncode, 
                printf('%0*d', length(s.address), CAST(s.address AS INTEGER) - d.base01) AS address, 
                s.num,s.functioncode,s.readfreq,s.tagname,s.scaletype,s.scalemultiple,s.scaleoffset,s.unit,s.max,s.min,s.signed, 
                s.fixed ,'' as startbit,'' as endbit
                FROM svidinfo s JOIN devicedef d ON d.mapfile = s.class AND s.class = '$filename';
                EOF;
            }
            break;
        //modbusN特殊輸出的sql需要代替掉點為N的欄位
        case 'modbusNmapfile':
                $sql = <<<EOF
                SELECT 
                t1.parameterid,
                printf('%0*d', length(t1.serveraddress), CAST(REPLACE(t1.serveraddress, 'N', CAST(t2.modbusn AS CHAR(255))) AS INT)) AS serveraddress,
                t1.serverfunctioncode,printf('%0*d', length(t1.address), CAST(t1.address AS INTEGER) - d.base01+1) AS address,
                t1.num,t1.functioncode,t1.readfreq,t1.tagname,t1.scaletype,t1.scalemultiple,t1.scaleoffset,t1.unit,t1.max,
                t1.min,t1.signed,t1.fixed,t1.startbit,t1.endbit 
                FROM svidinfo t1
                JOIN deviceinfo t2 ON t2.mapfile = '$filename' AND t1.class = t2.mapfile AND t2.modbusn = '$gmodbusn'
                JOIN devicedef d ON d.mapfile = t1.class AND t1.class = '$filename';
                EOF;
                //echo $sql;
            break;
        case 'fins-modbusNmapfile':
            $sql = <<<EOF
            SELECT 
            t1.parameterid,
            printf('%0*d', length(t1.serveraddress), CAST(REPLACE(t1.serveraddress, 'N', CAST(t2.modbusn AS CHAR(255))) AS INT)) AS serveraddress,
            t1.serverfunctioncode,printf('%0*d', length(t1.address), CAST(t1.address AS INTEGER) - d.base01) AS address,
            t1.num,t1.functioncode,t1.readfreq,t1.tagname,t1.scaletype,t1.scalemultiple,t1.scaleoffset,t1.unit,t1.max,
            t1.min,t1.signed,t1.fixed,'' as startbit,'' as endbit
            FROM svidinfo t1
            JOIN deviceinfo t2 ON t2.mapfile = '$filename' AND t1.class = t2.mapfile AND t2.modbusn = '$gmodbusn'
            JOIN devicedef d ON d.mapfile = t1.class AND t1.class = '$filename';
            EOF;
            break;
            //produce fins2mqtt.csv
        case 'fins-mapfile':
            if ($filename == '')
                $sql = <<<EOF
                    select 
                        parameterid, serveraddress, serverfunctioncode, address, num, functioncode, readfreq, tagname, scaletype, scalemultiple, 
                        scaleoffset, unit, max, min, signed, fixed ,startbit,endbit
                    from svidinfo 
                    where class <> 'def'; 
                EOF;
            else {
                $sql = <<<EOF
                    select 
                        parameterid, serveraddress, serverfunctioncode, address, num, functioncode, readfreq, tagname, scaletype, 
                        scalemultiple, scaleoffset, unit, max, min, signed, fixed, mergemode,startbit,endbit
                    from svidinfo 
                    where class = '$filename' ;
                EOF;
            }
            break;
        case 'origin':       
            $sql = <<<EOF
                select 
                    parameterid, serveraddress, serverfunctioncode, address, num, functioncode, readfreq, scaletype, scalemultiple, scaleoffset, unit, max, min, signed, fixed 
                from svidinfo where class = '$filename';
            EOF;
            break;
    }

    //echo $sql;
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {   
        array_push($csvDatas, $row);
    }
    $db->closeSqlite();
}
//
// description匯出CSV檔案
function exportCsv()
{
    global $csvFileName, $csvFds, $csvDatas;
    $path = $csvFileName;
    @ob_clean(); //清理緩衝區 避免開頭出現空行
    $fp = fopen($path, 'w+'); //開啟output流
    // 轉義為預定字符集, 根據需求轉字符集(不需要轉化可以忽略該行程式碼),
    // 將內部字符集轉為SJIS-win,一般專案為UTF-8字符集
    // mb_internal_encoding() 設定或獲取內部字符集,有興趣的同學可以去看看
    // mb_convert_variables('SJIS-win', mb_internal_encoding(), $csvFds);
    fputcsv($fp, $csvFds, ",");
    //初始化必要引數
    $intOffset = 0; // mysql中offset引數
    $intPageSize = 20; // 查詢條數 根據實際情況更換
    $blnFinishedFlg = false;
    do {
        // 輸出到csv檔案
        foreach ($csvDatas as $row) {
            fwrite($fp, implode(',', $row) . PHP_EOL);
            @ob_flush();
            flush();
        }
        if ($intPageSize === count($csvDatas)) {
            // 獲取到的結果數量等於查詢條數，認為未取完資料繼續查詢, 修改offset值
            $intOffset = $intOffset + $intPageSize;
            $blnFinishedFlg = false;
        } else {
            //小於查詢條數，資料已取完
            $blnFinishedFlg = true;
        }
    } while (false === $blnFinishedFlg);

    // 第三步關閉檔案流
    @ob_end_flush();
    fclose($fp);
}
function exportCsvByEBARA()
{
    global $dev_config_path, $csvFileName, $csvFds, $csvDatas;
    // CSV
    $csvFds = ["#serial_port", "bps", "DataBits", "Stop", "Parity", "DPM_ID+ChamberID"];
    $info = [];
    $sql = "select slaveport,baudrate, databits, stop, lower(parity) as parity, dpmid || chamberid, mapfile from deviceinfo where readercode like '%$csvFileName%';";
    $db = new SqliteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();
    for ($i = 0; $i < count($info); $i++) {
        $svidClass = $info[$i]["mapfile"];

        GetCsvDatas("mapfile", $svidClass);
        for ($j = 0; $j < count($csvDatas); $j++) {
            $key = str_pad($j + 1, 2, "0", STR_PAD_LEFT);
            $key = "ParameterName" . $key . "=svid_parameter" . $key;
            for ($k = 0; $k < count($info); $k++) {
                $info[$i][$key] = $csvDatas[$j]["tagname"] . "=" . $csvDatas[$j]["parameterid"]."_";
            }
        }
    }
    $csvFileName = $dev_config_path . $csvFileName . ".csv";
    for ($i = 0; $i < count($info); $i++) {
        unset($info[$i]["mapfile"]);
    }

    $csvDatas = $info;
    exportCsv();

    // CFG
    $info = [];
    $sql = "select mqttprefix || '/', mqttaddress, mqttport, mqttuser, mqttpassword, ebara_time from config; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();

    $csvFileName = str_replace(".csv", ".cfg", $csvFileName);
    $csvFds = ["#mqtt_topic", "mqtt_ip", "mqtt_port", "mqtt_user", "mqtt_password", "cmd_period_ms"];
    $csvDatas = $info;
    exportcsv();
}
function exportCsvByEDWARDS()
{
    global $dev_config_path, $csvFileName, $csvFds, $csvDatas;

    // CSV
    $csvFds = ["#serial_port", "bps", "DataBits", "Stop", "Parity", "DPM_ID+ChamberID"];

    $info = [];
    $sql = "select slaveport, baudrate, databits, stop, lower(parity) as parity, dpmid || chamberid, mapfile from deviceinfo where readercode like '%$csvFileName%';";
    $db = new SqliteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();
    for ($i = 0; $i < count($info); $i++) {
        $svidClass = $info[$i]["mapfile"];

        GetCsvDatas("mapfile", $svidClass);

        for ($j = 0; $j < count($csvDatas); $j++) {
            $key = str_pad($j + 1, 2, "0", STR_PAD_LEFT);
            $key = "ParameterName" . $key . "=svid_parameter" . $key;
            // array_push($csvFds, $key);

            for ($k = 0; $k < count($info); $k++) {
                $info[$k][$key] = $csvDatas[$j]["tagname"] . "=" . $csvDatas[$j]["parameterid"]."_";
            }
        }
    }
    $csvFileName = $dev_config_path . $csvFileName . ".csv";
    for ($i = 0; $i < count($info); $i++) {
        unset($info[$i]["mapfile"]);
    }
    // echo "info->".json_encode($info)."<br>";
    $csvDatas = $info;
    exportCsv();

    // CFG
    $info = [];
    $sql = "select mqttprefix || '/', mqttaddress, mqttport, mqttuser, mqttpassword, edwards_time from config; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();

    $csvFileName = str_replace(".csv", ".cfg", $csvFileName);
    $csvFds = ["#mqtt_topic", "mqtt_ip", "mqtt_port", "mqtt_user", "mqtt_password", "cmd_period_ms"];
    $csvDatas = $info;
    exportcsv();
}
function exportCsvByKSY_MU_TS()
{
    global $dev_config_path, $csvFileName, $csvFds, $csvDatas;

    // CSV
    $csvFds = ["#serial_port", "bps", "DataBits", "Stop", "Parity", "DPM_ID+ChamberID"];

    $info = [];
    $sql = "select slaveport, baudrate, databits, stop, lower(parity) as parity, dpmid || chamberid, mapfile from deviceinfo where readercode like '%$csvFileName%';";

    $db = new SqliteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();
    for ($i = 0; $i < count($info); $i++) {
        $svidClass = $info[$i]["mapfile"];

        GetCsvDatas("mapfile", $svidClass);

        for ($j = 0; $j < count($csvDatas); $j++) {
            $key = str_pad($j + 1, 2, "0", STR_PAD_LEFT);
            $key = "ParameterName" . $key . "=svid_parameter" . $key;
            // array_push($csvFds, $key);

            for ($k = 0; $k < count($info); $k++) {
                $info[$i][$key] = $csvDatas[$j]["tagname"] . "=" . $csvDatas[$j]["parameterid"]."_";
            }
        }
    }
    $csvFileName = $dev_config_path . $csvFileName . ".csv";
    for ($i = 0; $i < count($info); $i++) {
        unset($info[$i]["mapfile"]);
    }
    $csvDatas = $info;
    exportCsv();

    // CFG
    $info = [];
    $sql = "select mqttprefix || '/', mqttaddress, mqttport, mqttuser, mqttpassword, ksy_mu_time from config; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();

    $csvFileName = str_replace(".csv", ".cfg", $csvFileName);
    $csvFds = ["#mqtt_topic", "mqtt_ip", "mqtt_port", "mqtt_user", "mqtt_password", "cmd_period_ms"];
    $csvDatas = $info;
    exportcsv();
}
function exportCsvByKSY_SDE_SDT_SDX_SDH()
{
    global $dev_config_path, $csvFileName, $csvFds, $csvDatas;

    // CSV
    $csvFds = ["#serial_port", "bps", "DataBits", "Stop", "Parity", "AnalogDataCode+RunHourCode", "DPM_ID+ChamberID"];

    $info = [];
    // $sql = "select A.slaveport, A.baudrate, A.databits, A.stop, A.parity, B.analogcode, A.dpmid || A.chamberid from deviceinfo as A left join devicedef as B on B.machinetype = A.maker where B.readercode like '%".$csvFileName."%';";
    $sql = "select slaveport, baudrate, databits, stop, lower(parity) as parity, analogcode, dpmid || chamberid, mapfile from deviceinfo where readercode like '%$csvFileName%';";
    $db = new SqliteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();

    for ($i = 0; $i < count($info); $i++) {
        $svidClass = $info[$i]["mapfile"];

        GetCsvDatas("mapfile", $svidClass);

        for ($j = 0; $j < count($csvDatas); $j++) {
            $key = str_pad($j + 1, 2, "0", STR_PAD_LEFT);
            $key = "ParameterName" . $key . "=svid_parameter" . $key;
            // array_push($csvFds, $key);

            for ($k = 0; $k < count($info); $k++) {
                $info[$i][$key] = $csvDatas[$j]["tagname"] . "=" . $csvDatas[$j]["parameterid"]."_";
            }
        }
    }

    // echo "info->".json_encode($info)."<br>";
    $csvFileName = $dev_config_path . $csvFileName . ".csv";
    for ($i = 0; $i < count($info); $i++) {
        unset($info[$i]["mapfile"]);
    }
    $csvDatas = $info;
    exportCsv();

    // CFG
    $info = [];
    $sql = "select mqttprefix || '/', mqttaddress, mqttport, mqttuser, mqttpassword, ksy_time from config; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();

    $csvFileName = str_replace(".csv", ".cfg", $csvFileName);
    $csvFds = ["#mqtt_topic", "mqtt_ip", "mqtt_port", "mqtt_user", "mqtt_password", "cmd_period_ms"];
    $csvDatas = $info;
    exportcsv();
}
/**
 * modbus的functioncode轉換
 *
 * @param [type] $functioncode
 * @return void
 */
function ParseFunctioncode($functioncode) {
    switch ($functioncode) {
        case '3':
            return '4';
        case '1':
            return '0';
        case '2':
            return '1';
        case '4':
            return '1';
    }
}

//modbus對上裡面需要放對下收fins及com的csv
function export_modbus_servicecsv_cal(){
    global $dev_config_path, $csvFileName, $csvFds, $csvDatas;

    $info = [];

    //取得目標設備(s)
    $sql ="select di.deviceip, di.deviceport,di.devicestationid, di.dpmid,di.chamberid, di.mapfile, di.modbusn FROM deviceinfo di JOIN devicedef dd ON di.mapfile = dd.mapfile AND (dd.connectiontype = 'FINS' or dd.connectiontype = 'COM')";
    $infostrCALC=[];
    $db = new SqliteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        // 插入新数据到每行的开头
        array_unshift($row, 'MODBUS_CLIENT_TCP');
        array_push($info, $row);

        //每個一設備要再生成計算的規則
        $strCALC="CALC,{$row["dpmid"]},{$row["chamberid"]},";
        array_push($infostrCALC, $strCALC);

    }
    $db->closeSqlite();

    for ($i = 0; $i < count($info); $i++) {
        $svidClass = $info[$i]["mapfile"];
        global $gmodbusn;
        $gmodbusn=$info[$i]['modbusn'];
        GetCsvDatas("modbusNmapfile",$info[$i]['mapfile']);

        for ($j = 0; $j < count($csvDatas); $j++) {
            $key = 'SVID_param' . str_pad($j + 1, 2, "0", STR_PAD_LEFT);
            // array_push($csvFds, $key);
            // 227是通訊點，由這邊去跳過他
            if($csvDatas[$j]["parameterid"]=="227")
            {
                continue;
            }
            for ($k = 0; $k < count($info); $k++) {

                $val= ParseFunctioncode($csvDatas[$j]["functioncode"]).$csvDatas[$j]["address"] ;

                if($csvDatas[$j]["startbit"]!='' && $csvDatas[$j]["endbit"]!=''){
                    $val=$val."[".$csvDatas[$j]["endbit"].":".$csvDatas[$j]["startbit"]."]";
                }

                if ($csvDatas[$j]['mergemode'] != null) {
                    switch ($csvDatas[$j]['mergemode']) {
                        case '1':   // int16
                            $val = 's(' . $val.")";
                            break;
                        case '2':   // uint32
                            $val = '(' . $val . ')';
                            break;
                        case '3':   // int32
                            $val = 's(' . $val . ')';
                            break;
                        case '4':   // float4
                            $val = 'f(' . $val . ')';
                            break;
                        case '5':   // float8
                            $val = 'f(' . $val . ')';
                            break;
                        case '6':   // uint64
                            $val = '(' . $val . ')';
                            break;
                        case '7':   //int64
                            $val = 's(' . $val . ')';
                            break;
                    }
                }
                $val=$val. "=" . $csvDatas[$j]["parameterid"]."_";
            }
            $info[$i][$key] =$val;

            // #CALC,1200,001,max(-32768;min(32767;({011_}*2)+1))=011,max(0;min(65535;{017_}/2)-10)=017    # (value(1200001011_)*2)+1, (value(1200001017_)/2)-10
            $infostrCALC[$i]=$infostrCALC[$i]."max({$csvDatas[$j]["min"]};min({$csvDatas[$j]["max"]};(".'{'.$csvDatas[$j]["parameterid"].'_}*'."{$csvDatas[$j]["scalemultiple"]})+"."({$csvDatas[$j]["scaleoffset"]})))=". $csvDatas[$j]["parameterid"].',';

            $info[$i][$key] =$val;

        }
    }

    for ($i = 0; $i < count($info); $i++) {
        unset($info[$i]["mapfile"]);
        unset($info[$i]["modbusn"]);        
    }
    //前一個for處理完後才可以處理這個
    for ($i = 0; $i < count($infostrCALC); $i++) {
        $infostrCALC[$i]=substr($infostrCALC[$i], 0, -1);
    }

    return $infostrCALC;
}

function exportCsvBymodbus_servicecsv()
{
    global $dev_config_path, $csvFileName, $csvFds, $csvDatas;
    $csvFds = ["#plc_ip", "plc_port", "fins_dest_node","big_endian", "mqtt_topic", "address01=SVID_param01","address02=SVID_param02","..."];
    $devs = [];
    $info = [];

    // # function_name, plc_ip, plc_port, slave_id, dpm_id, chamber_id, address01=svid_parameter01, address02=svid_parameter02,....
    // #MODBUS_CLIENT_TCP,192.168.2.2,60000,1,1200,006,41001=011,41003=017

    //取得目標設備(s)
    $sql ="select di.deviceip, di.deviceport,di.devicestationid, di.dpmid,di.chamberid, di.mapfile, di.modbusn FROM deviceinfo di JOIN devicedef dd ON di.mapfile = dd.mapfile AND dd.connectiontype = 'Modbus TCP'";
    $infostrCALC=[];
    $db = new SqliteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        // 插入新数据到每行的开头
        array_unshift($row, 'MODBUS_CLIENT_TCP');
        array_push($info, $row);

        //每個一設備要再生成計算的規則
        $strCALC="CALC,{$row["dpmid"]},{$row["chamberid"]},";
        array_push($infostrCALC, $strCALC);

    }
    $db->closeSqlite();

    for ($i = 0; $i < count($info); $i++) {
        $svidClass = $info[$i]["mapfile"];
        global $gmodbusn;
        $gmodbusn=$info[$i]['modbusn'];
        GetCsvDatas("modbusNmapfile",$info[$i]['mapfile']);

        for ($j = 0; $j < count($csvDatas); $j++) {
            $key = 'SVID_param' . str_pad($j + 1, 2, "0", STR_PAD_LEFT);
            // array_push($csvFds, $key);
            // 227是通訊點，由這邊去跳過他
            if($csvDatas[$j]["parameterid"]=="227")
            {
                continue;
            }
            for ($k = 0; $k < count($info); $k++) {

                $val= ParseFunctioncode($csvDatas[$j]["functioncode"]).$csvDatas[$j]["address"] ;

                if($csvDatas[$j]["startbit"]!='' && $csvDatas[$j]["endbit"]!=''){
                    $val=$val."[".$csvDatas[$j]["endbit"].":".$csvDatas[$j]["startbit"]."]";
                }

                if ($csvDatas[$j]['mergemode'] != null) {
                    switch ($csvDatas[$j]['mergemode']) {
                        case '1':   // int16
                            $val = 's(' . $val.")";
                            break;
                        case '2':   // uint32
                            $val = '(' . $val . ')';
                            break;
                        case '3':   // int32
                            $val = 's(' . $val . ')';
                            break;
                        case '4':   // float4
                            $val = 'f(' . $val . ')';
                            break;
                        case '5':   // float8
                            $val = 'f(' . $val . ')';
                            break;
                        case '6':   // uint64
                            $val = '(' . $val . ')';
                            break;
                        case '7':   //int64
                            $val = 's(' . $val . ')';
                            break;
                    }
                }
                $val=$val. "=" . $csvDatas[$j]["parameterid"]."_";
                //$val=$val. "=" . $csvDatas[$j]["parameterid"];
            }
            $info[$i][$key] =$val;

            // #CALC,1200,001,max(-32768;min(32767;({011_}*2)+1))=011,max(0;min(65535;{017_}/2)-10)=017    # (value(1200001011_)*2)+1, (value(1200001017_)/2)-10
            $infostrCALC[$i]=$infostrCALC[$i]."max({$csvDatas[$j]["min"]};min({$csvDatas[$j]["max"]};(".'{'.$csvDatas[$j]["parameterid"].'_}*'."{$csvDatas[$j]["scalemultiple"]})+"."({$csvDatas[$j]["scaleoffset"]})))=". $csvDatas[$j]["parameterid"].',';

            $info[$i][$key] =$val;

        }
    }

    for ($i = 0; $i < count($info); $i++) {
        unset($info[$i]["mapfile"]);
        unset($info[$i]["modbusn"]);        
    }
    //前一個for處理完後才可以處理這個
    for ($i = 0; $i < count($infostrCALC); $i++) {
        $infostrCALC[$i]=substr($infostrCALC[$i], 0, -1);
        //echo $infostrCALC[$i];

        array_push($info,[$infostrCALC[$i]]);
    }

    //不保證順序可以調換
    array_unshift($info,["CFG_CALC,GIOT-GW/FIVEGIOT/UL/,224.0.0.1,19999,127.0.0.1"]);
    array_unshift($info,["CFG_MODBUS_CLIENT_RTU,GIOT-GW/FIVEGIOT/UL/,224.0.0.1,19999,127.0.0.1,3000"]);
    array_unshift($info,["CFG_MODBUS_CLIENT_TCP,GIOT-GW/FIVEGIOT/UL/,224.0.0.1,19999,127.0.0.1,3000"]);

    

    $info_Fins_CALC=export_modbus_servicecsv_cal();

    for ($i = 0; $i < count($info_Fins_CALC); $i++) {
        array_push($info,[$info_Fins_CALC[$i]]);
    }




    $csvDatas = $info;
    $csvFileName = $dev_config_path . $csvFileName . ".csv";
    exportCsv();

    // // CFG
    // $info = [];
    // $sql = "select mqttprefix || '/', mqttaddress, mqttport, mqttuser, mqttpassword, fins_time from config; ";
    // $db = new SQLiteDB();
    // $ret = $db->QueryDatas($sql);
    // while ($row = $ret->fetchArray(1)) {
    //     array_push($info, $row);
    // }
    // $db->closeSqlite();

    // $csvFileName = str_replace(".csv", ".cfg", $csvFileName);
    // // echo $csvFileName."<br>";
    // $csvFds = ["#mqtt_topic", "mqtt_ip", "mqtt_port", "mqtt_user", "mqtt_password", "cmd_period_ms"];
    // $csvDatas = $info;
    // exportcsv();
}




function exportCsvByfins_servicecsv()
{
    global $dev_config_path, $csvFileName, $csvFds, $csvDatas;

    $csvFds = ["#plc_ip", "plc_port", "fins_dest_node","big_endian", "mqtt_topic", "address01=SVID_param01","address02=SVID_param02","..."];
    $devs = [];
    $info = [];

    // #plc_ip, plc_port, fins_dest_node, mqtt_topic, address01=SVID_param01, address02=SVID_param02,...
    // 127.0.0.1,19600,0,1200605,D22=008,D23=009

    //取得目標設備(s)
    $sql ="select deviceip, deviceport, finsdestination,fins_endian, dpmid || chamberid AS topic, di.mapfile FROM deviceinfo di JOIN devicedef dd ON di.mapfile = dd.mapfile AND dd.connectiontype = 'FINS'";
    
    $db = new SqliteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();

    $svid_param_csv=[];
    for ($i = 0; $i < count($info); $i++) {
        $svidClass = $info[$i]["mapfile"];

        GetCsvDatas("fins-mapfile", $info[$i]['mapfile']);
        $part_device_param=$info[$i];


        for ($j = 0; $j < count($csvDatas); $j++) {
            $key = 'SVID_param' . str_pad($j + 1, 2, "0", STR_PAD_LEFT);
            // array_push($csvFds, $key);

            if($csvDatas[$j]["parameterid"]=="227")
            {
                continue;
            }

            for ($k = 0; $k < count($info); $k++) {

                $val= $csvDatas[$j]["tagname"] ;


                if($csvDatas[$j]["startbit"]!='' && $csvDatas[$j]["endbit"]!=''){
                    $val=$val."[".$csvDatas[$j]["endbit"].":".$csvDatas[$j]["startbit"]."]";
                }


                if ($csvDatas[$j]['mergemode'] != null) {
                    switch ($csvDatas[$j]['mergemode']) {
                        case '1':   // int16
                            $val = 's(' . $val.")";
                            break;
                        case '2':   // uint32
                            $val = '(' . $val . ')';
                            break;
                        case '3':   // int32
                            $val = 's(' . $val . ')';
                            break;
                        case '4':   // float4
                            $val = 'f(' . $val . ')';
                            break;
                        case '5':   // float8
                            $val = 'f(' . $val . ')';
                            break;
                        case '6':   // uint64
                            $val = '(' . $val . ')';
                            break;
                        case '7':   //int64
                            $val = 's(' . $val . ')';
                            break;
                    }
                }
                $val=$val. "=" . $csvDatas[$j]["parameterid"]."_";
            }


            $part_device_param[$key] =$val;


            //每128筆切割一次
            if($j%128==127){
                array_push($svid_param_csv,$part_device_param);
                $part_device_param=$info[$i];
            }elseif($j==count($csvDatas)-1){
                array_push($svid_param_csv,$part_device_param);
            }

        }
    }

    for ($i = 0; $i < count($svid_param_csv); $i++) {
        unset($svid_param_csv[$i]["mapfile"]);
    }

    $csvDatas = $svid_param_csv;
    $csvFileName = $dev_config_path . $csvFileName . ".csv";
    exportCsv();

    // CFG
    $info = [];
    $sql = "select mqttprefix || '/', mqttaddress, mqttport, mqttuser, mqttpassword, fins_time from config; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($info, $row);
    }
    $db->closeSqlite();

    $csvFileName = str_replace(".csv", ".cfg", $csvFileName);
    // echo $csvFileName."<br>";
    $csvFds = ["#mqtt_topic", "mqtt_ip", "mqtt_port", "mqtt_user", "mqtt_password", "cmd_period_ms"];
    $csvDatas = $info;
    exportcsv();
}
/**
 * @description 對應不同瀏覽器、輸出漢字名出問題的Bug
 * 由於IE Edge 包含Chrome等資訊、所以只能第一個判斷
 * @param string $strFileName 檔名
 * @return string Head資訊
 */
function changeFileNameWithAgent($strFileName)
{
    $filename = preg_replace('/[\?\*\|\\/\:"><]/', '', $strFileName);
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $strHeader = '';
    if (strpos($agent, "Edge")) {
        $filename = urlencode($filename);
        $filename = str_replace("+", "%20", $filename);
        $strHeader = "Content-Disposition: attachment; filename=" . $filename;
    } else if (strpos($agent, "Firefox")) {
        $filename = urlencode($filename);
        $filename = str_replace("+", "%20", $filename);
        $strHeader = 'Content-Disposition: attachment; filename*="utf8\'\'' . $filename . '"';
    } else if (strpos($agent, "Chrome")) {
        $strHeader = "Content-Disposition: attachment; filename=" . $filename;
    } else if (strpos($agent, "Safari")) {
        $strHeader = 'Content-Disposition: attachment;filename*=UTF-8\'\'' . rawurlencode($filename);
    } else {
        $filename = urlencode($filename);
        $filename = str_replace("+", "%20", $filename);
        $strHeader = "Content-Disposition: attachment; filename=" . $filename;
    }
    return $strHeader;
}
function checkFolderExists($path)
{
    // echo $path."<br>";
    if (!file_exists($path))
        mkdir($path, 0777, true);
}
?>
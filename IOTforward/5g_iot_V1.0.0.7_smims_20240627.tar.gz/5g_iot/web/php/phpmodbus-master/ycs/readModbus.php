<?php

require_once dirname(__FILE__) . '/../phpmodbus-master/Phpmodbus/ModbusMaster.php';


$method = $_SERVER['REQUEST_METHOD'];

switch ($method)
{
    case 'GET':
        REST_do_GET();
    break;
    case 'PUT':
        //REST_do_PUT();
    break;
    case 'POST':
        //REST_do_POST();
    break;
    case 'DELETE':
        //REST_do_DELETE();
    break;
}

function REST_do_GET()
{
    if (isset($_GET['readmodbus'])&&isset($_GET['serverstationid'])){
        echo Read_Modbus($_GET['address'],$_GET['serverstationid']);
    } 
}

function Read_Modbus($address,$stationid){
    // Create Modbus object
    $modbus = new ModbusMaster("127.0.0.1", "TCP");
    try {
        // FC 3
        // read 1 words (20 bytes) from device ID=0, address=12288
        $recData = $modbus->readMultipleRegisters($stationid, $address,1);
        $values = array_chunk($recData, 2);
        $revArr=[];
        foreach($values as $bytes){
            $t=PhpType::bytes2unsignedInt($bytes);
            array_push($revArr,$t);
        }

        echo json_encode($revArr);    
        //echo json_encode($recData);
    }
    catch (Exception $e) {
        // Print error information if any
        echo $modbus;
        echo $e;
        //exit;
    }
}


// // Received data
// echo "<h1>Received Data</h1>\n";
// print_r($recData);

// // Conversion
// echo "<h2>32 bits types</h2>\n";
// // Chunk the data array to set of 4 bytes
// $values = array_chunk($recData, 4);

// // Get float from REAL interpretation
// echo "<h3>REAL to Float</h3>\n";
// foreach($values as $bytes)
//     echo PhpType::bytes2float($bytes) . "</br>";

// // Get integer from DINT interpretation
// echo "<h3>DINT to integer </h3>\n";
// foreach($values as $bytes)
//     echo PhpType::bytes2signedInt($bytes) . "</br>";

// // Get integer of float from DINT interpretation
// echo "<h3>DWORD to integer (or float) </h3>\n";
// foreach($values as $bytes)
//     echo PhpType::bytes2unsignedInt($bytes) . "</br>";

// echo "<h2>16 bit types</h2>\n";
// // Chunk the data array to set of 4 bytes
// $values = array_chunk($recData, 2);

// // Get signed integer from INT interpretation
// echo "<h3>INT to integer </h3>\n";
// foreach($values as $bytes)
//     echo PhpType::bytes2signedInt($bytes) . "</br>";

// // Get unsigned integer from WORD interpretation
// echo "<h3>WORD to integer </h3>\n";
// foreach($values as $bytes)
//     echo PhpType::bytes2unsignedInt($bytes) . "</br>";

// // Get string from STRING interpretation
// echo "<h3>STRING to string </h3>\n";
// echo PhpType::bytes2string($recData) . "</br>";
?>
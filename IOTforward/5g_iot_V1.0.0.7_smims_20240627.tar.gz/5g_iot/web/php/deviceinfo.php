<?php

require_once("common.php");
require_once("../config.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}

function Do_GET()
{
    if (isset($_GET["savedevinfo"]))
    {
        $data = json_decode($_GET["data"]);
        savedevinfo($data);
        echo '{"code":"200","msg":"ok","detail":""}';
    }
    else if (isset($_GET["querydevinfo"]))
    {
        echo querydevinfo();
    }
    else if (isset($_GET["deldevinfo"]))
    {
        $key = $_GET["key"];
        deldevinfo($key);
        echo '{"code":"200","msg":"ok","detail":""}';
    }
    else if (isset($_GET["getComports"]))
    {
        echo getComports();
    }
    else if (isset($_GET["savedevsvid"]))
    {
        $data = json_decode($_GET["data"]);
        savesvid($data);
        echo '{"code":"200","msg":"ok","detail":""}';
    }
    else if (isset($_GET["loadchamber"]))
    {
        echo loadchamber();
    }
}
function Do_POST()
{
    switch ($_POST["func"]) {
        case 'savedevsvid':
            $data = json_decode($_POST["data"]);
            savesvid($data);
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
        case 'savedevinfo':
            $data = json_decode($_POST["data"]);
            savedevinfo($data);
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
    }
}

function savedevinfo($data)
{
    $toolid = $data->{"toolid"};
    $sql = '';
    $fds = '';
    $vals = '';
    $err = [];
    $dpmid = GetDpmId();
    $ary = $data->{"add"};
    foreach ($ary as $k => $v) {
        $fds = '';
        $vals = '';

        foreach ($v as $key => $value) {
            $fds .= ($fds != '' ? "," : "") . "'".$key."'";
            $vals .= ($vals != '' ? "," : "") . "'".$value."'";
        }
        $fds .= ",'dpmid'";
        $vals .= ",'".GetDpmId()."'";
        $sql .= "INSERT INTO deviceinfo ($fds) VALUES ($vals); ";
    }

    $ary = $data->{"edit"};
    foreach ($ary as $k => $v) {
        $vals = '';

        if ($v == null)
            continue;

        foreach ($v as $key => $value) {
            $vals .= ($vals != '' ? "," : "") . "'".$key."' = '".$value."'";
        }
        $sql .= "UPDATE deviceinfo SET ".$vals." WHERE id = '".$k."'; ";

        
    }

    $sql .= "UPDATE deviceinfo SET 'toolid' = '".$toolid."'; ";

    // echo $sql."<br>";
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);

    $sql = '';
    $dev_news = $data->{"writedev"};
    // echo json_encode($dev_news);
    foreach ($dev_news as $k => $v) {

        if ($v == null)
            continue;

        $sql = "INSERT INTO devicedef(machinetype,devicetype,connectiontype,baudrate,databits,stop,parity,serverport,mapfile,readercode,analogcode) ";
        $sql .= "SELECT '".$v->{'devname'}."', devicetype, connectiontype, baudrate, databits, stop, parity, serverport, mapfile, readercode, analogcode FROM deviceinfo WHERE id = '".$v->{'key'}."'; ";
        // echo $sql."<br>";
        $db->ExecuteSql($sql);
    }
    // echo $sql."<br>";
    //為了讓chamberid不要重復
    //-- 创建一个带有自增序号的临时表
    //-- 将临时表的自增序号作为新的chamberid，并更新回原始表
    //-- 删除临时表
    $sql = <<<EOF

    CREATE TEMP TABLE temp_deviceinfo AS
    SELECT *, ROW_NUMBER() OVER (ORDER BY chamberid) AS rn
    FROM deviceinfo;    

    UPDATE deviceinfo
    SET chamberid = 300 + rn ,name= 300 + rn
    FROM temp_deviceinfo
    WHERE deviceinfo.id = temp_deviceinfo.id AND deviceinfo.devicetype='LSC';    

    DROP TABLE temp_deviceinfo;
    SELECT * FROM deviceinfo;
    EOF;

    $db->ExecuteSql($sql);

    $db->closeSqlite();

}
function querydevinfo()
{
    $result = [];

    // info datas
    $sql = "SELECT * FROM deviceinfo ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $result["devinfos"] = $ary;

    // def datas
    $sql = "SELECT * FROM devicedef; ";
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $result["devdefs"] = $ary;

    // map file
    $sql = "SELECT DISTINCT class FROM svidinfo WHERE class != 'def'; ";
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $result["mapfiles"] = $ary;

    $db->closeSqlite();
    return json_encode($result);
}
function deldevinfo($key)
{
    $sql = "DELETE FROM deviceinfo WHERE id = ".$key;
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

function savesvid($data)
{
    $tagName = '';
    $sql = '';
    foreach ($data as $key => $value) {
        $tagName = $key;
        $sql .= "DELETE FROM svidinfo WHERE class = '".$tagName."'; ";
        foreach ($value as $k => $v) {
            $sql .= "INSERT INTO svidinfo ('class', 'uid', 'parameterid', 'remark', 'serveraddress','serverfunctioncode', 'num','address','functioncode','readfreq','tagname','scaletype','scalemultiple','scaleoffset','unit','max','min', 'signed', 'fixed', 'private') ";
            $sql .= "VALUES ('".$tagName."', '".$v->uid."', '".$v->parameterid."', '".$v->remark."', '".$v->serveraddress."','".$v->serverfunctioncode."','".$v->num."','".$v->address."','".$v->functioncode."','".$v->readfreq."','".$v->tagname."','".$v->scaletype."','".$v->scalemultiple."','".$v->scaleoffset."','".$v->unit."','".$v->max."','".$v->min."','".$v->signed."','".$v->fixed."', 1); ";
        }

    }
    // echo $sql."<br>";
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();

}
function loadchamber()
{
    $sql = "SELECT * FROM chamber_comparison; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}
function getComports()
{
    global $com_ports_setting_path;

    $file = $com_ports_setting_path."comports.csv";
    $openfile = fopen($file, "r");
    $ary = [];
    foreach (fgetcsv($openfile, 1000, ',') as $key => $value) {
        array_push($ary, $value);
    }
    fclose($openfile);
    return json_encode($ary);
}
function GetDpmId()
{
    $dpmid = '';
    $sql = 'SELECT factory, dpmids FROM config; ';
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        $dpm = json_decode($row['dpmids']);
        $dpmid = $dpm->{$row['factory']};
    }
    $db->closeSqlite();
    // echo json_encode($ary);
    return $dpmid;
}

?>

<?php

require_once("common.php");
require_once("../config.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}
function Do_GET()
{
    if (isset($_GET["saveconfig"]))
    {
        $data = json_decode($_GET["data"]);
        Editconfig($data);
        saveconfig($data);

        echo '{"code":"200","msg":"ok","detail":""}';
    } else if (isset($_GET["queryconfig"])) {
        echo queryconfig();
    } 
}

function Do_POST()
{
    switch ($_POST["func"]) {
        case 'startdevsystem':
            StartDevSystem();
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
        case 'stopdevsystem':
            StopDevSystem();
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
        case 'SIMCheckOn':
            $returnData =SIMCheckOn();
            echo '{"code":"200","msg":"ok","detail":"'.$returnData.'"}';
            break;
        case 'SIMCheckOff':
            $returnData =SIMCheckOff();
            echo '{"code":"200","msg":"ok","detail":"'.$returnData.'"}';
            break;    
        case 'SimulatorOn':
            $returnData =SimulatorOn();
            echo '{"code":"200","msg":"ok","detail":"'.$returnData.'"}';
            break;
        case 'SimulatorOff':
            $returnData =SimulatorOff();
            echo '{"code":"200","msg":"ok","detail":"'.$returnData.'"}';
            break;
        case 'StartTcpdump':
            $returnData =StartTcpdump();
            echo '{"code":"200","msg":"ok","detail":"'.$returnData.'"}';
            break;
        case 'SudoReboot':
            $returnData =SudoReboot();
            echo '{"code":"200","msg":"ok","detail":"'.$returnData.'"}';
            break;                       
    }

}

function SudoReboot()
{
    // 使用 shell_exec 执行命令
    $output = shell_exec('sudo reboot');
    return $output;
}


function StartTcpdump()
{
    $data=date("YmdHis");
//開子執行續來啟動 Tcpdump  
// 执行的外部命令一定要指向null不知道為什麼
$command = 'sudo tcpdump -i eth0 -w /tmp/log/'.$data.'.pcap -c 1000 2>/dev/null &';

// 定义进程间通信（IPC）管道配置
$descriptorspec = [
    0 => ['pipe', 'r'], // 标准输入管道，用于从子进程读取数据
    1 => ['pipe', 'w'], // 标准输出管道，用于向子进程写入数据
    2 => ['pipe', 'w']  // 标准错误管道，用于向子进程写入错误信息
];

// 执行外部命令并创建子进程
$process = proc_open($command, $descriptorspec, $pipes);

if (is_resource($process)) {
    // 获取子进程的状态信息
    $status = proc_get_status($process);
    $pid = $status['pid'];

    //echo "TCPDump process started with PID: $pid" . PHP_EOL;

    // 在此处您可以执行其他操作，等待一段时间，然后关闭子进程
    // 例如，等待10秒后关闭子进程
    // sleep(10);

    // // 关闭子进程
    // proc_terminate($process);

   // echo "TCPDump process terminated." . PHP_EOL;
} else {
    // 处理 proc_open 函数调用失败的情况
    //echo "Failed to execute command." . PHP_EOL;
}
return $output;
}


function SimulatorOn()
{
//执行 shell 命令
$command = 'sudo mv /opt/5g_iot/config/no_simulator /opt/5g_iot/config/no_simulator.bak ';

$output = [];
$returnCode = 0;

// 使用 shell_exec 执行命令
$output = shell_exec($command);

// 输出命令执行的结果
//echo "<pre>$output</pre>";
return $output;
}

function SimulatorOff()
{
// 执行 shell 命令
$command = 'sudo mv /opt/5g_iot/config/no_simulator.bak /opt/5g_iot/config/no_simulator';
$output = [];
$returnCode = 0;

// 使用 shell_exec 执行命令
$output = shell_exec($command);

// 输出命令执行的结果
//echo "<pre>$output</pre>";
return $output;
}

function SIMCheckOn()
{
    // 执行 shell 命令
    $command = 'sudo mv /opt/5g_iot/config/no_dialup /opt/5g_iot/config/no_dialup.bak';
    $output = [];
    $returnCode = 0;

    // 使用 shell_exec 执行命令
    $output = shell_exec($command);

    // 输出命令执行的结果

    return $output;
}

function SIMCheckOff()
{
    // 执行 shell 命令
    $command = 'sudo mv /opt/5g_iot/config/no_dialup.bak /opt/5g_iot/config/no_dialup';
    $output = [];
    $returnCode = 0;

    // 使用 shell_exec 执行命令
    $output = shell_exec($command);

    // 输出命令执行的结果
    //echo "<pre>$output</pre>";
    return $output;
}

function Editconfig($data)
{
    $localgateway = $data->{'localgateway'};

    //修改linux底層interfaces檔案裡的mask內容
    //使用 awk 來搜尋和修改 /etc/network/interfaces 檔案中的內容
    if(validateIP($localgateway)){
    exec("sudo awk '/^auto br0/{p=1} p && /gateway/{sub(/gateway .*/, \"gateway $localgateway\"); p=0} 1' /etc/network/interfaces > tmp && sudo mv tmp /etc/network/interfaces");
    }
}
    //使用正则表达式验证 IP 地址格式
function validateIP($ip) {
    if (preg_match('/^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/', $ip)) {
        return true;
    } else {
        return false;
    }
}
function saveconfig($data)
{
    global $dev_config_path;

    $localip = '';
    $localmask = '';
    $fds = '';
    $val = '';
    $parame = '';
    $dpmid = '';
    $aryfield = ["ip","fdcport","itport","mdln","sessionid","deviceinfofile","mqttaddress","mqttport","mqttuser","mqttpassword","mqttprefix","factory","dpmids","lang","softrev", "deviceinfofile", "modbusserverconfigfile","ebara_time","edwards_time","ksy_mu_time","ksy_time","fins_time","localip","localmask"];
    foreach ($aryfield as $fd)
    {
        // echo $data->{$fd};
        $fds .= ($fds == '' ? '' : ',') . $fd;
        switch ($fd) {
            case 'deviceinfofile':
                $val .= ($val == '' ? '' : ',') . "'".$dev_config_path."deviceinfo.csv'";
                break;
            case 'modbusserverconfigfile':
                $val .= ($val == '' ? '' : ',') . "'".$dev_config_path."modbusserverconfig.csv'";
                break;
            case 'softrev':
                $val .= ($val == '' ? '' : ',') . "'000001'";
                break; 
            default:
                $val .= ($val == '' ? '' : ',') . "'" . $data->{$fd} . "'";
                if ($fd == 'dpmids')
                    $dpmid = json_decode($data->{$fd})->{$data->{"factory"}};
                else if ($fd == 'localip'){
                    $localip = $data->{$fd};
                    //修改linux底層interfaces檔案裡的address內容
                    //exec("sudo sed -i 's/address .*/address $localip/g' /etc/network/interfaces");
                    //使用 awk 來搜尋和修改 /etc/network/interfaces 檔案中的內容
                    if(validateIP($localip)){
                    exec("sudo awk '/^auto br0/{p=1} p && /address/{sub(/address .*/, \"address $localip\"); p=0} 1' /etc/network/interfaces > tmp && sudo mv tmp /etc/network/interfaces");
                    }
                }
                else if ($fd == 'localmask'){                
                    $localmask = $data->{$fd};
                    //修改linux底層interfaces檔案裡的mask內容
                    //使用 awk 來搜尋和修改 /etc/network/interfaces 檔案中的內容
                    if(validateIP($localmask)){
                    exec("sudo awk '/^auto br0/{p=1} p && /netmask/{sub(/netmask .*/, \"netmask $localmask\"); p=0} 1' /etc/network/interfaces > tmp && sudo mv tmp /etc/network/interfaces");
                    }//exec("sudo sed -i 's/mask .*/mask $localmask/g' /etc/network/interfaces");
                }
                break;
        }
    }

    $sql = "DELETE from config; ";
    $sql .= "INSERT INTO config ($fds) VALUES ($val); ";
    if ($dpmid != '')
        $sql .= "UPDATE deviceinfo SET dpmid = '". $dpmid . "'; ";

    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();

    CreateIpFile($localip, $localmask);
    EditAPNData($data->{"factory"});

    exec("sudo systemctl restart networking.service");
    exec("sudo systemctl restart apache2");

    // echo "<br />". $sql;
}

function queryconfig()
{

    $db = new SQLiteDB();
    $sql = "SELECT * FROM config ";
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {

        //需要增加資料庫沒有的部分
        //讀取/etc/network/interfaces
        $row['localgateway'] =exec("sudo awk '/^iface br0/{p=1} p && /^ *gateway/{print $2; exit}' /etc/network/interfaces");
 
        array_push($ary, $row);

    }

    $db->closeSqlite();
    return json_encode($ary);
}

function StartDevSystem()
{
    $ary = [];
    exec('python3 /opt/5g_iot/util/service_load.py', $out, $return);
    array_push($ary, json_encode($out));
    array_push($ary, $return);
    //writeLogFile($ary, "logfile.txt");
}

function StopDevSystem()
{
    $ary = [];
    exec('python3 /opt/5g_iot/util/service_remove.py', $out);
    array_push($ary, json_encode($out));
    //writeLogFile($ary, "logfile.txt");
}

function EditAPNData($factory)
{
    $file = fopen("/opt/5g_iot/config/apn.cfg", "w");
    fputs($file, $factory."\n");
    fclose($file);
}

function CreateIpFile($ip, $mask) {
    global $dev_ip_setting_path;

    $fileName = $dev_ip_setting_path."local_IP.txt";
    $file = fopen($fileName, "w");
    $fileSize = fputs( $file, $ip . "," . $mask);
    fclose($file);
    //echo "寫入檔案成功, 共有 " . $fileSize . " bytes";
}

?>

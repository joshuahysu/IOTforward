<?php
// Report simple running errors
ini_set('error_reporting', 0);
ini_set('display_errors', 0);
// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);
// error_reporting(E_ERROR | E_WARNING | E_PARSE);

require_once __DIR__.'/../config.php';
// require_once("DB_Class.php");

#
# get device status from UDP port
#
function packageJSON($status_str)
{
    $status_array = explode("\n", $status_str);
    $emptyRemoved = array_filter($status_array);

    $status = [];
    foreach ($emptyRemoved as $item_num => $item)
    {
        $pair = explode("=", $item);
        $status[$pair[0]] = $pair[1];
    }

    return $status;
}

#
# read log file to table
#
function readLogFile($file_name)
{
    $file = file_get_contents($file_name, true);

    $status_array = explode("\n", $file);
    $emptyRemoved = array_filter($status_array);

    $status = [];
    foreach ($emptyRemoved as $item_num => $item)
    {
        $pair = explode("=", $item);
        $status[$pair[0]] = $pair[1];
    }

    return $status;
}

#
# write log file
#
function writeLogFile($pair_array, $file_name)
{
    #file_put_contents($file_name, print_r($pair_array, true));

    $text = "";
    foreach($pair_array as $key => $value)
    {
        $text .= $key."=".$value."\n";
    }
    $fh = fopen($file_name, "w");// or die("Could not open log file.");
    fwrite($fh, $text) or die("Could not write file!");
    fclose($fh);
}

function get_issuetime_list()
{
    $issues = array();
    $issues['0'] = 'Immediately';
    $issues['1'] = '1 minute';
    $issues['5'] = '5 minutes';
    $issues['10'] = '10 minutes';

    return $issues;
}

function get_issuetime_name($issuetime)
{
    $issuename = $issuetime;
    if($issuetime == '0')
        $issuename = 'Immediately';
    if($issuetime == '1')
        $issuename = '1 minute';
    if($issuetime == '5')
        $issuename = '5 minutes';
    if($issuetime == '10')
        $issuename = '10 minutes';

    return $issuename;
}

function get_user_name($projectid, $userid)
{
    $db = new DB($projectid, 'base');

    $db->query("SELECT name FROM User WHERE userid=$userid ");

    $username = $userid;
    if($result = $db->fetch_array())
    {
        $username = $result['name'];
    }

    return $username;
}

function get_User_data($useraccount)
{
    // global $_DB;
    // $db = new DB();
    // $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    $db = new DB(1, 'base');

    $db->query("SELECT * FROM User WHERE account='".$useraccount."' ");

    $user_data = [];
    $user_data['account'] = $useraccount;
    while($result = $db->fetch_array())
    {
        $user_data['name'] = $result['name'];
        $user_data['groupid'] = $result['groupid'];
    }
    //$db->close();

    return $user_data;
}

function get_Web_port()
{
    global $_DB;

    $web_udp_port = 18613;
    $has_memcached = true;

    $cached_name = $_DB['username'].'web_udp_port';

    try {
        $memcached = new Memcached();
        $memcached->addServer('127.0.0.1',11211);
        $web_udp_port = $memcached->get($cached_name);

        if($web_udp_port)
        {
            return $web_udp_port;
        }
    }
    catch (Throwable $t)
    {
        //echo $t->getMessage();
        $has_memcached = false;
    }
    catch (Exception $e)
    {
        //echo $e->getMessage();
        $has_memcached = false;
    }

    $db = new DB(1, 'base');
    $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);

    $db->query("SELECT web_udp_port FROM systemconfig where CONFIG_ID = 1 ");

    while($result = $db->fetch_array())
    {
        $web_udp_port = (int)$result['web_udp_port'];
    }

    if($has_memcached)
    {
        $memcached->add($cached_name, $web_udp_port, 1800);
    }

    return $web_udp_port;
}

?>

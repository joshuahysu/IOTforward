<?php

require_once("common.php");
require_once("../config.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];
switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}

function Do_GET()
{
    if (!is_null($_GET['loadlogfiledata'])) {
        $fileName = $_GET['cmd'];
        echo LoadLogFileDatas($fileName, 0);
    }
}

function Do_POST()
{
    $func = $_POST["func"];
    //writeLogFile([$func], "../logfile.txt");
    switch ($_POST["func"]) {
        // case 'restartdevsystem':
        //     RestartDevSystem();
        //     echo '{"code":"200","msg":"ok","detail":""}';
        //     break;
        case 'loaddeviceitems':
            echo LoadDeviceItems();
            break;
        case 'loadlogfiledata':
            $fileName = $_POST['filename'];
            $lastline = $_POST['lastline'];
            echo LoadLogFileDatas($fileName, $lastline);
            break;

        case 'getPHPGlStartDate':
            // 获取当前日期并按照指定的格式格式化
            $glStartDate = date('Ymd');
            // 输出格式化后的日期
            echo $glStartDate;
    }

}

function LoadDeviceItems()
{
    $items = [];
    //$sql = "SELECT DISTINCT machinetype FROM devicedef; ";
    $sql = <<<EOF
        select 
            devicetype,
            connectiontype,
            case when connectiontype == 'COM' then slaveport
                    when connectiontype == 'FINS' then deviceip || ':' || deviceport 
                    else deviceip || ':' || deviceport || '-' || devicestationid end as 'key'
        from deviceinfo;
    EOF;
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        array_push($items, $row);
    }
    $db->closeSqlite();
    return json_encode($items);
}

function LoadLogFileDatas($fileName, $lastLine)
{
    // $result = '';
    // $output = '';
    // $return = '';
    // switch ($fileName)
    // {
    //     case "adlink_uptime":
    //         exec("uptime", $output, $return);
    //         $result = json_encode($output);
    //         break;
    //     case "adlink_activate":
    //         $result = exec("systemctl status 5giot_manager.service | grep Active:", $output, $return);
    //         $result = json_encode($output);
    //         break;
    //     default:
    //         global $log_file_path;

    //         if(strpos($fileName, "log_pkts_")!== false){
    //             $filePath = '/tmp/log/'. $fileName;
    //         }else if(strpos($fileName, "log_5g_router_info")!== false){
    //             $filePath = '/tmp/log/'. $fileName;
    //         }            
    //         else{
    //         $filePath = $log_file_path . $fileName;
    //         }
    //         //$filePath =FindFirstInclude($fileName,$log_file_path);
    //         //echo "filePath".$fileName.$filePath;
    //         $result = FileLastLines($filePath, 30);
    // }
    // return $result;


    $result = '';
    $output = '';
    $return = '';

    if ($fileName == "adlink_uptime") {
        exec("uptime", $output, $return);
        $result = json_encode($output);
    } elseif ($fileName == "adlink_activate") {
        $result = exec("systemctl status 5giot_manager.service | grep Active:", $output, $return);
        $result = json_encode($output);
    }
    elseif(strpos($fileName, "log_pkts_") !== false || strpos($fileName, "log_5g_router_info") !== false){
        $filePath = '/tmp/log/' . $fileName;
        $result = FileLastLines($filePath, 30);
    }
    elseif($fileName =="alarmfunction"){
        // 获取当前系统时间并按照指定格式显示
        $currentDate = date('Ymd');

        $filePath = '/tmp/log/';
        $result = FileLastLines($filePath.'log_5g_router_info.txt', 30);
        $result =$result .FileLastLines($filePath.'log_cpurammonitor.txt', 30);
        $result =$result .FileLastLines($filePath.'log_HsmsSs_equip_err_'.$currentDate.'.txt', 30);
        $result =$result .FileLastLines($filePath.'logfile_secsgem_'.$currentDate.'.csv', 30);

        // logfile_192.168.1.11:5501_20240312.csv


    }
    else {
        global $log_file_path;
        $filePath = $log_file_path . $fileName;
        $result = FileLastLines($filePath, 30);   
    }

    return $result;
}

//尋找第一個包含搜尋文字的文件名
function FindFirstInclude($substring,$directory) {

    $files = scandir($directory);
    foreach ($files as $file) {
        // 忽略 "." 和 ".."
        if ($file == "." || $file == "..") {
            continue;
        }            
        // 確定文件名包含指定字串正常只會有一個
        if (strpos($file, $substring) !== false) {
            return $directory.$file;
        }
    }
}

function FileCount($file) {
    $fp=fopen($file, "r");
    $i=0;
    while(!feof($fp)) {
        //每次讀取2M
        if($data=fread($fp,1024*1024*2)){
            //計算讀取到的行數
            $num=substr_count($data,"\n");
            $i+=$num;
        }
    }
    fclose($fp);
    return $i;
}

function FileLastLines($filename, $n) {
    $result = [];
    if(!file_exists($filename)){
        echo "No exist LogFile".$filename;
    }
    if(!$fp = fopen($filename, 'r')){
        echo "No Find LogFile".$filename;
        return false;
    }

    $pos = -2;
    $eof = "";
    $str = "";

    $count = FileCount($filename);
    if ($n > $count)
        $n = $count;

    while($n > 0){
        while($eof != "\n"){
            if(!fseek($fp, $pos, SEEK_END)){
                $eof = fgetc($fp);
                $pos--;
            }else{
                break;
            }
        }
        if (ftell($fp) == 1) {
            fseek($fp, 0);
        }
        $str = fgets($fp);
        array_push($result, $str);
        $eof = "";
        $n--;
    }
    return json_encode($result);
    
}

?>

<?php

session_start();

require_once("common.php");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        break;
    case 'DELETE':
        break;
}

function Do_GET()
{
    $fun = $_GET['fun'];
    switch ($fun) {
        case 'fetchsystemtime':
            echo getSysTime();
            break;
        case 'pcinfo':
            echo getPCInfo();
            break;
    }
    // if (isset($_GET['fetchsystemtime'])) {
    // } else {
    //     $app_version = ''; //getServerInfo('appversion');

    //     global $APP_BIN_FILE;
    //     $vilscenterapp = $APP_BIN_FILE;
    //     exec("ps aux | grep \"${vilscenterapp}\" | grep -v grep | awk '{ print $2 }' | head -1", $out);

    //     $json_orig = [];
    //     $json_orig['version'] = $app_version;
    //     $json_orig['pid'] = $out[0];

    //     echo json_encode($json_orig);
    // }
}

function getSysTime()
{
    $result = [];
    //date_default_timezone_set('Asia/Taipei');

    $result["systime"] = date('Y/m/d H:i:s', time());

    return json_encode($result);
}

function getPCInfo()
{
    $data = [];
    $data['cpu'] = getCPUUsage();
    $data['ram'] = getRAMUsage();
    return json_encode($data);
}

function getCPUUsage()
{
    $result = '';
    $cpu = getServerLoad();
    if (is_null($cpu)) {
        $result = "CPU load not estimateable (maybe too old Windows or missing rights at Linux or Windows)";
    } else {
        $result = $cpu . "%";
    }
    return $result;
}

function getRAMUsage()
{
    $result = '';

    $os = PHP_OS;
    switch (strtoupper($os)) {
        case 'LINUX':
            $free = shell_exec('free');
            $free = (string)trim($free);

            $free_arr = explode("\n", $free);
            $mem = explode(" ", $free_arr[1]);
            $mem = array_filter($mem);
            $mem = array_merge($mem);
            $memory_usage = $mem[2] / $mem[1] * 100;
            $memory_usage1 = sprintf("%01.2f", $memory_usage)  . "%";
            $result = $memory_usage1;

            break;
        case 'DARWIN':
            $free = shell_exec('top -l 1 | head | grep Phy ');
            $free = (string)trim($free);

            $free_arr = explode(":", $free);

            $mem = explode(" ", trim($free_arr[1]));
            $mem = array_filter($mem);
            $mem = array_merge($mem);

            $use = intval(str_replace("M", "", $mem[0]));
            $use = $use * 1024 * 1024;

            $total = intval(str_replace("M", "", $mem[0])) + intval(str_replace("M", "", $mem[4]));
            $total = $total * 1024 * 1024;

            $memory_usage = $use / $total * 100;
            $memory_usage1 = sprintf("%01.2f", $memory_usage)  . "%";
            $result = $memory_usage1;
            break;
    }
    return $result;
}

function _getServerLoadLinuxData()
{
    if (is_readable("/proc/stat")) {
        $stats = @file_get_contents("/proc/stat");

        if ($stats !== false) {
            // Remove double spaces to make it easier to extract values with explode()
            $stats = preg_replace("/[[:blank:]]+/", " ", $stats);

            // Separate lines
            $stats = str_replace(array("\r\n", "\n\r", "\r"), "\n", $stats);
            $stats = explode("\n", $stats);

            // Separate values and find line for main CPU load
            foreach ($stats as $statLine) {
                $statLineData = explode(" ", trim($statLine));

                // Found!
                if (count($statLineData) >= 5 && $statLineData[0] == "cpu") {
                    return array(
                        $statLineData[1],
                        $statLineData[2],
                        $statLineData[3],
                        $statLineData[4],
                    );
                }
            }
        }
    }

    return null;
}

// Returns server load in percent (just number, without percent sign)
function getServerLoad()
{
    $load = null;
    if (stristr(PHP_OS, "win")) {
        $cmd = "wmic cpu get loadpercentage /all";
        @exec($cmd, $output);

        if ($output) {
            foreach ($output as $line) {
                if ($line && preg_match("/^[0-9]+\$/", $line)) {
                    $load = $line;
                    break;
                }
            }
        }
    } else {
        if (is_readable("/proc/stat")) {
            // Collect 2 samples - each with 1 second period
            // See: https://de.wikipedia.org/wiki/Load#Der_Load_Average_auf_Unix-Systemen
            $statData1 = _getServerLoadLinuxData();
            sleep(1);
            $statData2 = _getServerLoadLinuxData();

            if (!is_null($statData1) && !is_null($statData2)) {
                // Get difference
                $statData2[0] -= $statData1[0];
                $statData2[1] -= $statData1[1];
                $statData2[2] -= $statData1[2];
                $statData2[3] -= $statData1[3];

                // Sum up the 4 values for User, Nice, System and Idle and calculate
                // the percentage of idle time (which is part of the 4 values!)
                $cpuTime = $statData2[0] + $statData2[1] + $statData2[2] + $statData2[3];

                // Invert percentage to get CPU time, not idle time
                $load = 100 - ($statData2[3] * 100 / $cpuTime);
            }
        }
    }
    $load = number_format(floatval($load), 2); 
    return $load;
}

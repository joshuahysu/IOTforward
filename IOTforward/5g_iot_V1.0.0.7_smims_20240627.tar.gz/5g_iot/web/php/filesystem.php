<?php

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}

function Do_GET()
{
    if (isset($_GET["getLogfiles"])) {        
        $logArr=[];
        $logArr=openfold('/tmp/log',$logArr);
        $logArr=openfold('/opt/5g_iot/log',$logArr);
        echo json_encode($logArr);
    } 
}

function Do_POST()
{
    // if (isset($_POST['file'])) {
    //     $file = $_POST['file'];
    //     downloadFile($file);
    // } 
}

function openfold($folderPath,$result){
    //folderPath= '.'; // 替換為實際的資料夾路徑
    // global $logArr;
    // $tmpAry=[];
    // array_push($tmpAry, "1123");
    // array_push($logArr,$tmpAry);
    // 使用 glob 函式取得符合條件的檔案列表
    //GLOB_BRACE 参数告诉 glob 函数使用大括号扩展模式
    $txtFiles = glob($folderPath . '/*.{txt,log,csv,pcap}', GLOB_BRACE);
    if ($txtFiles !== false) {
        // print_r($txtFiles);
        // 迴圈列出每個 txt 檔案的路徑
        foreach ($txtFiles as $txtFile) {
            // 取得檔案名稱
            $fileName = basename($txtFile);
            // 輸出file
            //array_push($ary, urlencode($folderPath.'/'.$fileName));
            // 輸出連結
            //echo "<a href='view_txt.php?file=" . urlencode($folderPath.'/'.$fileName) . "'>" . $fileName . "</a><br>";
            $tmpAry=[];
            array_push($tmpAry, "<a href='view_txt.php?file=" . urlencode($folderPath.'/'.$fileName) . "'>" . $fileName . "</a><br>");
 
            array_push($tmpAry, "<a href='view_txt.php?download=1&file=" . urlencode($folderPath.'/'.$fileName) . "'>"."Download". "</a><br>");
            array_push($result,$tmpAry);            
        }
    } else {
        //echo "找不到符合條件的檔案。";
    }
    return $result;
}
?>
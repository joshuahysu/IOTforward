<?php

require_once("common.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}

function Do_GET()
{
    if (isset($_GET["rebootservice"])) {
        rebootservice($_GET["service"]);
    }
    elseif(isset($_GET["checkAllService"])){
    checkAllService();
    }
}

function Do_POST()
{
    // 检查提交类型
    if (isset($_POST["submitType"])) {
        $submitType = $_POST["submitType"];
        echo "Upload\n";
        // 根据提交类型调用不同的处理函数
        switch ($submitType) {
            case "uploadCsv":     
                break;
            case "importLinuxGar":
                break;
        }
    }
    $result = [];
    array_push($result, $str); 
    echo json_encode($result);
}


function rebootservice($service_name){
    exec("sudo systemctl restart ".$service_name, $output, $return_var);
    echo json_encode(["sudo systemctl restart ".$service_name]);
}

function checkService($service_name){

// 執行 systemctl 命令
exec("systemctl is-active ".$service_name, $output, $return_var);
// echo $return_var;
// echo print_r($output);
// 檢查命令的返回值
if ($return_var === 0) {
    // 服務 active
    return array('name'=>$service_name,'active' => 1);
    //echo "Service $service_name is active.";
} else {
    // 服務不 active
    return array('name'=>$service_name,'active' => 0);
}
}

function checkAllService(){
    // 創建一個空的關聯陣列
    $result = array();

    // 將新數據添加到陣列中
    $result[] = checkService("5giot_manager.service");
    $result[] = checkService("5giot_modbusserverservice.service");
    $result[] = checkService("5giot_secsgem.service");
    $result[] = checkService("5giot_fins2mqtt.service");
    $result[] = checkService("5giot_remove_log.service");
    $result[] = checkService("mosquitto.service");
    $result[] = checkService("5giot_simulator_edwards.service");
    $result[] = checkService("5giot_dpm_ksy_sde_sdt_sdx_sdh.service");
    $result[] = checkService("5giot_dpm_ebara.service");
    $result[] = checkService("5giot_remove_log.service");
    $result[] = checkService("5giot_simulator_ebara_esr_est_ev-s_ev-m.service");
    $result[] = checkService("5giot_dpm_edwards.service");
    $result[] = checkService("5giot_simulator_fins.service");
    $result[] = checkService("5giot_simulator_modbus_server.service");
    $result[] = checkService("5giot_simulator_ksy_sde_sdt_sdx_sdh.service");
    $result[] = checkService("5giot_dpm_ksy_mu_ts.service");
    $result[] = checkService("5giot_simulator_ksy_mu_ts.service");
    
    echo json_encode($result);
}
?>
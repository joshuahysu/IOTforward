<?php

require_once("common.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}

function Do_GET()
{
    if (isset($_GET["loaddevsviddata"])) {
        echo loaddevsviddata();
    } 
    elseif (isset($_GET["loaddevsviddata_new"])) {
        echo loaddevsviddata_new();
    } 
    
}

function Do_POST()
{
        // 检查提交类型
    if (isset($_POST["submitType"])) {
        $submitType = $_POST["submitType"];
        //echo "Upload\n";  
        // 根据提交类型调用不同的处理函数
        switch ($submitType) {
            case "uploadCsv":
                $uploadDir = "../uploads/"; // 上传目录
                $uploadFile = $uploadDir . basename($_FILES['uploadFile']['name']);
                //echo basename($_FILES['uploadFile']['name']);
                if (move_uploaded_file($_FILES['uploadFile']['tmp_name'], $uploadFile)) {
                    //调用处理 CSV 的函数
                    //processCSV($uploadFile);
                    echo basename($_FILES['uploadFile']['name']);
                    deleteTable(basename($_FILES['uploadFile']['name']),"All");

                    // 读取 CSV 文件内容
                    $csvData = array_map('str_getcsv', file($uploadFile));
                    CSVToSQLite($csvData);

                    //使用完後刪除
                    deleteFile($uploadFile);
                    echo "File is valid, and was successfully uploaded.\n";
                } else {
                    echo "Upload failed.\n";
                }
                break;
            case "uploadOneDeviceCsv":
                uploadOneDevice("Class");
                break;
            case "uploadAllDeviceCsv":
                uploadOneDevice("All");
                break;
            case "importLinuxGar":
                $uploadDir = "../uploads/"; // 上传目录
                $uploadFile = $uploadDir . basename($_FILES['uploadFile']['name']);
                echo "Upload importLinuxGar";
                if (move_uploaded_file($_FILES['uploadFile']['tmp_name'], $uploadFile)) {
                    echo "Upload Start";
                    //调用处理 CSV 的函数
                    tarFile($uploadFile);
                    //使用完後刪除
                    //deleteFile($uploadFile);
                    echo "File is valid, and was successfully uploaded.\n";
                } else {
                    echo "Upload importLinuxGar failed.\n";
                }
                break;
            case "downloadDB":
                downloadDB();
                break;
            case "uploadDb":
                uploadDb();
                break;                
        }
    }
}


function uploadOneDevice($function){
    $uploadDir = "../uploads/"; // 上传目录
    $uploadFile = $uploadDir . basename($_FILES['uploadFile']['name']);
    $newCsvData=[];

    //echo basename($_FILES['uploadFile']['name']);
    if (move_uploaded_file($_FILES['uploadFile']['tmp_name'], $uploadFile)) {
        //调用处理 CSV 的函数
        echo basename($_FILES['uploadFile']['name']);

        //===========读取 CSV 文件内容 且修改csv內的uid=====================

        $csvData = array_map('str_getcsv', file($uploadFile));
        // 初始化一个递增的 ID 变量
        $id = 1+(int)selectLastId();
        $firstIteration = true;
        console_log("id=".$id);
        // 遍历每一行数据
        foreach ($csvData as &$row) {
            // 如果不是第一次循环，则用递增的 ID 替换每一行数据的第一个字段
            if (!$firstIteration) {
                $row[0] = $id++;
                $row[1]=$row[0]+1;
                array_push($newCsvData,$row);
                $newRow=[];
                array_push($newRow,$id++);
                array_push($newRow,$row[1]);                            
                array_push($newRow,"def");
                array_push($newRow,$row[3]);
                array_push($newRow,$row[4]);
                for ($i = 1; $i <= 23; $i++) {
                    array_push($newRow,"");
                }
                array_push($newCsvData,$newRow);
            } else {
                // 如果是第一次循环，则将布尔值变量设置为 false，表示已经跳过第一次循环
                $firstIteration = false;
                array_push($newCsvData,$row);
            }
        }
        //=====================================
        $className=$csvData[1][2];//取得className

        deleteTable($className,$function);
      
        CSVToSQLite($newCsvData);
        
        echo "File is valid, ";
        //使用完後刪除
        deleteFile($uploadFile);
        echo "and was successfully uploaded.\n";
    } else {
        echo "Upload failed.\n";
    }

}


function uploadDb(){
    if(basename($_FILES['uploadFile']['name']!="5giot.db")){
        echo "Upload failed.\n";
        echo "File name is invalid .\n";
        return;
    }
    $uploadDir = "../sqlite/"; // 上传目录
    $uploadFile = $uploadDir . basename($_FILES['uploadFile']['name']);
    if (move_uploaded_file($_FILES['uploadFile']['tmp_name'], $uploadFile)) {
        //调用处理 CSV 的函数
        //processCSV($uploadFile);
        echo basename($_FILES['uploadFile']['name']);
        echo "File is valid, and was successfully uploaded.\n";
    } else {
        echo "Upload failed.\n";
    }
}

function downloadDB(){
    $file = '../sqlite/5giot.db';

    // 检查文件是否存在
    if (file_exists($file)) {
        // 设置响应头
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
    
        // 将文件内容输出到浏览器
        readfile($file);
    
        // 确保文件完整性
        exit;
    } else {
        // 如果文件不存在，返回404错误
        http_response_code(404);
        echo 'File not found.';
    }

}



function deleteFile($filepath){
    if (file_exists($filepath)) {
        // 如果檔案存在，進行刪除
        if (unlink($filepath)) {
          //  echo '檔案成功刪除。';
        } else {
            echo '無法刪除檔案。';
        }
    } else {
        echo '檔案不存在。';
    }
}

// 处理 CSV 文件的函数
function processCSV($csvFile) {
    // 读取 CSV 文件内容
    $csvData = array_map('str_getcsv', file($csvFile));

    // 假设第一行是列名，将其移除
    $columns = array_shift($csvData);

    // 建立数据库连接
    $conn = new mysqli("localhost", "username", "password", "database");

    // 检查连接是否成功
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // 构建插入语句
    $sql = "INSERT INTO your_table_name (" . implode(',', $columns) . ") VALUES ";

    // 构建每行的插入值
    foreach ($csvData as $row) {
        $sql .= "('" . implode("','", $row) . "'),";
    }

    // 移除最后的逗号
    $sql = rtrim($sql, ',');

    // 执行插入操作
    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.\n";
    } else {
        echo "Error inserting data: " . $conn->error . "\n";
    }

    // 关闭数据库连接
    $conn->close();
}

    function deleteTable($csvFile,$function) {
        try {
            // 1. 打开 SQLite 数据库连接
            $db = new SQLite3('../sqlite/5giot.db');
        
            //2.刪除資料
            $result ="";
    
        
            if($function=="All")
            {
                $result = $db->exec("DELETE FROM svidinfo");
            }
            else if($function=="Def")
            {
            $result = $db->exec("DELETE FROM svidinfo WHERE class = 'def'");}
            else if($function=="Class"){
            //更新單一設備時移除單一設備
            $result = $db->exec("DELETE FROM svidinfo WHERE class = '".$csvFile."'");
            }
    
            if ($result) {
                echo 'Data DELETE successfully.';
            } else {
                echo 'Error DELETE data: ' . $db->lastErrorMsg();
            }
        } catch (Exception $e) {
            echo 'Exception caught: ' . $e->getMessage();
        } finally {
            //关闭数据库连接
            if ($db) {
                $db->close();
            }
        }
        }



function CSVToSQLite($csvData) {
try {

    // 读取 CSV 文件内容
    //$csvData = array_map('str_getcsv', file($csvFile));

    // 假设第一行是列名，将其移除
    $columns = array_shift($csvData);

    // 1. 打开 SQLite 数据库连接
    $db = new SQLite3('../sqlite/5giot.db');
    console_log($columns);

    $sql = "INSERT OR REPLACE INTO svidinfo(". implode(',', $columns) . ") VALUES ";
    // 2. 绑定参数
    // 构建每行的插入值
    foreach ($csvData as $row) {
        if (strlen($row[3]) <3) {
            $row[3] = str_pad($row[3], 3, '0', STR_PAD_LEFT);
        }
        $sql .= "('" . implode("','", $row) . "'),";
    }

    // 移除最后的逗号
    $sql = rtrim($sql, ',');

    console_log($sql);
    // 4. 执行插入语句
    //$result = $insertStatement->execute();
    $result = $db->exec($sql);

    if ($result) {
        echo 'Data inserted successfully.';
    } else {
        echo 'Error inserting data: ' . $db->lastErrorMsg();
    }
} catch (Exception $e) {
    echo 'Exception caught: ' . $e->getMessage();
} finally {
    //关闭数据库连接
    if ($db) {
        $db->close();
    }
}
}

function copypaste($sourceFile,$destinationFile){
//$sourceFile = '/path/to/source/file.txt'; // 源文件路径
//$destinationFile = '/path/to/destination/file.txt'; // 目标文件路径

// 将源文件复制到目标文件，并覆盖目标文件
if (copy($sourceFile, $destinationFile)) {
    echo "文件複製成功並覆蓋了目標文件。";
} else {
    echo "文件複製失败。";
}
}

function tarFile($uploadFile){

// 解压文件
$zipFile = $uploadFile;
$extractTo = '/opt/tmp';

// 执行 shell 命令
//tar -xvzf example.tar.gz
$command = 'sudo tar -xvzf '.$zipFile.' -C '.$extractTo;
$output = [];
$returnCode = 0;

// 使用 shell_exec 执行命令
$output = shell_exec($command);

// 输出命令执行的结果
echo "<pre>$zipFile."."/n".".$output</pre>";

//將檔案都轉成LF
//shell_exec("sudo find $extractTo/5g_iot -type f -exec dos2unix {} \;");

copypaste($extractTo.'/5g_iot/install.sh','/opt/install.sh');


// 设置要执行的 shell 脚本文件路径
$shellScriptPath = 'sudo sh /opt/install.sh >>/opt/install_log.txt 2>>/opt/install_error_log.txt';

// 执行 shell 脚本
$output = shell_exec($shellScriptPath);

// 输出执行结果
echo "<pre1>$output</pre1>";
}


function console_log($output, $with_script_tags = true) {
$js_code = 'console.log(' . json_encode($output, JSON_HEX_TAG) .
');';
if ($with_script_tags) {
$js_code = '<script>' . $js_code . '</script>';
}
echo $js_code;
}

function loaddevsviddata() {
    $sql = "SELECT * FROM svidinfo; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}

function loaddevsviddata_new() {
    $sql = "SELECT * FROM svidinfo where class<>'def'; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}


function selectLastId() {

$lastId=0;
// 执行 SQL 查询以选择表中的最后一条记录
$sql= "SELECT id FROM svidinfo ORDER BY id DESC LIMIT 1";

$db = new SQLiteDB();
$ret = $db->QueryDatas($sql);

while ($row = $ret->fetchArray(1)) {
    $lastId=$row['id'];
}
$db->closeSqlite();

return $lastId;
}
?>
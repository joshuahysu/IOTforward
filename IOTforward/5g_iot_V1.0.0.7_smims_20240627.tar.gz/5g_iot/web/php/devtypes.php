<?php

require_once("common.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        break;
}
function Do_GET()
{
    if (isset($_GET["savedevdef"]))
    {
        $data = json_decode($_GET["data"]);
        // echo $_GET["data"];
        savedevdef($data);
        echo '{"code":"200","msg":"ok","detail":""}';
    }
    else if (isset($_GET["editdevdef"]))
    {
        $key = $_GET["key"];
        $data = json_decode($_GET["data"]);
        editdevdef($key, $data);
        echo '{"code":"200","msg":"ok","detail":""}';
    }
    else if (isset($_GET["queryconfig"]))
    {
        echo querydevdef();
    }
    else if (isset($_GET["deletedevdef"]))
    {
        $key = $_GET["key"];
        deletedevdef($key);
        echo '{"code":"200","msg":"ok","detail":""}';
    }
}

function savedevdef($data) {
    $sql = '';
    $fds = '';
    $vals = '';
    $oldName = '';
    $valsinfo = '';
    $ary = $data->{"add"};
    foreach ($ary as $k => $v) {
        $fds = '';
        $vals = '';

        foreach ($v as $key => $value) {
            $fds .= ($fds != '' ? "," : "") . "'".$key."'";
            $vals .= ($vals != '' ? "," : "") . "'".$value."'";
        }
        $sql .= "INSERT INTO devicedef ($fds) VALUES ($vals); ";
    }

    $ary = $data->{"edit"};
    foreach ($ary as $k => $v) {
        $vals = '';
        $valsinfo = '';
        if ($v == null)
            continue;

        $oldName = GetOldDevName($k);

        foreach ($v as $key => $value) {
            $vals .= ($vals != '' ? "," : "") . "'".$key."' = '".$value."'";
            switch ($key) {
                case 'machinetype':
                    $valsinfo .= ($valsinfo != '' ? "," : "") . "'maker' = '".$value."'";
                    break;
                case 'base01':
                    //deviceinfo table沒有這個欄位
                    break;
                case 'fins_endian':
                    //deviceinfo table沒有這個欄位
                    break;         
                default:
                    $valsinfo .= ($valsinfo != '' ? "," : "") . "'".$key."' = '".$value."'";
            }
        }

        $sql .= "UPDATE devicedef SET ".$vals." WHERE id = '".$k."'; ";
        $sql .= "UPDATE deviceinfo SET ".$valsinfo." WHERE maker = '".$oldName."'; ";
    }
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

function editdevdef($id, $data) {
    $vals = '';

    foreach ($data as $key => $value) {
        $vals .= ($vals != '' ? "," : "") . " '".$key."' = '".$value."'";
    }

    $sql = "UPDATE devicedef SET ".$vals." WHERE id = ".$id."; ";
    echo $sql;
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

function querydevdef() {
    $result = [];
    $sql = "SELECT * FROM devicedef; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $result["defdev"] = $ary;

    $sql = "SELECT DISTINCT class FROM svidinfo WHERE class != 'def'; ";
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $result["mapfiles"] = $ary;

    $db->closeSqlite();
    return json_encode($result);
}

function deletedevdef($key) {
    $sql = "DELETE FROM devicedef WHERE id = ".$key;
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

function GetOldDevName($key)
{
    $name = '';
    $sql = "select machinetype from devicedef where id = '".$key."'; ";
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    while ($row = $ret->fetchArray(1)) {
        $name = $row['machinetype'];
    }
    $db->closeSqlite();
    return $name;
}

?>

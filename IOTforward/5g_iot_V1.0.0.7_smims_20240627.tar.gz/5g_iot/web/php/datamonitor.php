<?php

require_once("common.php");
require_once("../config.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];
// writeLogFile(["a"], "../logfile.txt");
// LoadLogFileDatas('aa', 2878);
switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}

function Do_GET()
{
}

function Do_POST()
{
    $func = $_POST["func"];
    switch ($_POST["func"]) {
        case 'loadlogfiledata':
            $fileName = $_POST['filename'];
            $lastline = $_POST['lastline'];
            echo LoadLogFileDatas($fileName, $lastline);
            break;
        case 'loaddeviceitems':
            echo LoadDeviceItems();
            break;
    }

}

function LoadDeviceItems()
{
    $sql = <<<EOF
        select 
            dpmid || chamberid AS "id", 
            case when devicetype == "DPM" then slaveport 
                 when connectiontype == "FINS" then deviceip || ":" || deviceport
                 else deviceip || ":" || deviceport || "-" || devicestationid end AS "name" , 
            devicetype, 
            connectiontype 
        from deviceinfo;
    EOF;
    //$sql = 'select dpmid || chamberid AS "id", case when devicetype == "DPM" then slaveport when connectiontype == "FINS" then serverip || ":" || serverport || "-" || serverstationid else deviceip || ":" || deviceport || "-" || devicestationid end AS "name" , devicetype, connectiontype from deviceinfo; ';
    $db = new SQLiteDB();
    $ret = $db->QueryDatas($sql);
    $items = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($items, $row);
    }
    $db->closeSqlite();
    // echo json_encode($items);
    return json_encode($items);
}

function LoadLogFileDatas($fileName, $lastLine)
{
    global $log_file_path;
    $filePath = $log_file_path . $fileName;
    $result = FileLastLines($filePath, 30);
    return $result;
}

function FileCount($file) 
{
    $fp=fopen($file, "r");
    $i=0;
    while(!feof($fp)) {
        //每次讀取2M
        if($data=fread($fp,1024*1024*2)){
            //計算讀取到的行數
            $num=substr_count($data,"\n");
            $i+=$num;
        }
    }
    fclose($fp);
    echo $i;
}

function FileLastLines($filename, $n) 
{
    $result = [];
    if(!$fp = fopen($filename, 'r')){
        echo "打開文件失敗，請檢查文件路徑是否正確，路徑和文件名不要包含中文";
        return false;
    }
    $pos = -2;
    $eof = "";
    $str = "";
    while($n > 0){
        while($eof != "\n"){
            if(!fseek($fp, $pos, SEEK_END)){
                $eof = fgetc($fp);
                $pos--;
            }else{
                break;
            }
        }
        $str1 = fgets($fp);
        array_push($result, $str1);
        $eof = "";
        $n--;
    }
    return json_encode($result);
}

?>

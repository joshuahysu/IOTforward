<?php

require_once("common.php");
require_once("sqlite3.php");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method)
{
    case 'GET':
        Do_GET();
        break;
    case 'PUT':
        break;
    case 'POST':
        Do_POST();
        break;
}

function Do_GET() {
    if (isset($_GET["savedefsvid"]))
    {
        $data = json_decode($_GET["data"]);
        savedefsvid($data);
        echo '{"code":"200","msg":"ok","detail":""}';
    } else if (isset($_GET["querydefsvid"])) {
        echo querydefsvid();
    } else if (isset($_GET["deletedefsvid"])) {
        $key = $_GET["setkey"];
        deletedefsvid($key);
        echo '{"code":"200","msg":"ok","detail":""}';
    }

}

function Do_POST() {
    $func = $_POST["func"];
    // array_push($ary, $func);
    switch ($_POST["func"]) {
        case 'savedefsvid':
            $data = json_decode($_POST["data"]);
            savedefsvid($data);
            echo '{"code":"200","msg":"ok","detail":""}';
            break;
    }
}

function savedefsvid($data) {
    $sql = '';
    $ary = $data->{'new'};
    foreach ($ary as $value) {
        $sql .= "INSERT INTO svidinfo ('uid', 'parameterid', 'remark','serveraddress','serverfunctioncode', 'num','address','functioncode','readfreq','scaletype','scalemultiple','scaleoffset','unit','max','min','signed','fixed') ";
        $sql .= "VALUES ('".$value->uid."','".$value->parameterid."','".$value->remark."','".$value->serveraddress."','".$value->serverfunctioncode."','".$value->num."','".$value->address."','".$value->functioncode."','".$value->readfreq."','".$value->scaletype."','".$value->scalemultiple."','".$value->scaleoffset."','".$value->unit."','".$value->max."','".$value->min."','".$value->signed."','".$value->fixed."'); ";
    }
    $ary = $data->{'edit'};
    foreach ($ary as $value) {
        $sql .= "UPDATE svidinfo ";
        $sql .= "SET 'uid' = '".$value->uid."', 'parameterid' = '".$value->parameterid."', 'remark' = '".$value->remark."', 'serverfunctioncode' = '".$value->serverfunctioncode."', 'serveraddress' = '".$value->serveraddress."', 'num' = '".$value->num."', 'address' = '".$value->address."', 'functioncode' = '".$value->functioncode."', 'readfreq' = '".$value->readfreq."', 'scaletype' = '".$value->scaletype."', 'scalemultiple' = '".$value->scalemultiple."', 'scaleoffset' = '".$value->scaleoffset."', 'unit' = '".$value->unit."', 'max' = '".$value->max."', 'min' = '".$value->min."', 'signed' = '".$value->signed."', 'fixed' = '".$value->fixed."' ";
        $sql .= "WHERE id = '".$value->id."'; ";
    }
    $ary = $data->{'uid'};
    foreach ($ary as $key => $value) {
        $sql .= "UPDATE svidinfo SET uid = '".$value."' WHERE id = '".$key."'; ";
    }

    //echo $sql."<br>";
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

function querydefsvid() {
    $db = new SQLiteDB();
    $sql = "SELECT * FROM svidinfo where class = 'def'; ";
    $ret = $db->QueryDatas($sql);
    $ary = [];
    while ($row = $ret->fetchArray(1)) {
        array_push($ary, $row);
    }
    $db->closeSqlite();
    return json_encode($ary);
}

function deletedefsvid($key) {
    $sql = "DELETE FROM svidinfo WHERE id = ".$key;
    $db = new SQLiteDB();
    $db->ExecuteSql($sql);
    $db->closeSqlite();
}

?>

<?php
include ('checksession.php');
?>

<!DOCTYPE HTML>
<html lang="en">
 <head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=yes">
   <link href="/css/vils.min.css" rel="stylesheet">
   <link href="/css/main.css?date=<?php echo $UPDATE_DATE;?>" rel="stylesheet">
   <title></title>

   <style>

       .c_box_dpmitem {
           margin: 10px 0px;
       }

       .device_setting input[type=text] {
           margin-left: 5px;
           width: 250px !important;
       }

       #svid_body td {
           padding: 10px 5px;
       }

       #svid_body td:first-child {
        text-align: center;
       }

       #svid_body td i {
           margin: 0px 3px;
           cursor: pointer;
       }

       #svid_body td input {
           width: 100%;
       }

   </style>

 </head>
       <div class="row" id="section_group_edit" style="display:block;">
         <div class="col-md-12">
           <!-- Event Settings -->
           <div class="box" id="section_group_edit_box">
             <div class="box-header with-border">
               <h3 class="box-title"><?php echo "Parameter總表";?></h3>
             </div>
             <!-- /.box-header -->
             <div class="box-body" id="account_box_body">
                 <div class="row c_box" id="dpm_list">
                 <button id="download" type="button">匯出csv</button>
                     <input id="btn_save" type="button" style="display:none;" value="存檔" onclick="SaveSvidData();return false;" />
                     <table class="dataTable">
                         <thead id="svid_head">
                         </thead>
                         <tbody id="svid_body">
                         </tbody>
                         <tfoot>
                             <tr>
                                 <td class="tfootAction">
                                     <input type="button" value="新增" onclick="createNewRow();" />
                                 </td>
                             </tr>
                         </tfoot>
                     </table>
                 </div>
             </div>
             <!-- /.box-body -->
           </div>
           <!-- /.box-->
         </div>
         <!-- /.col -->
       </div>
       <!-- /.row -->
   <script src="/js/global.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/map_base.min.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/map.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/common.js?date=<?php echo $UPDATE_DATE;?>"></script>
   <script src="/js/exportCsv.js"></script>
   <script src="/js/defsvid_src/00-defsvid.js?date=<?php echo $UPDATE_DATE;?>"></script>

</html>
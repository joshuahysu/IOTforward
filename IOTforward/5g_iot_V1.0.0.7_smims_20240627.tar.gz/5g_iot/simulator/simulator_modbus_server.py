#!/usr/bin/python3
import time
from pyModbusTCP.server import ModbusServer,DataBank

class MyDataBank(DataBank):
	def __init__(self):
		super().__init__(virtual_mode=True)

	def get_coils(self, address, number=1, srv_info=None):
		list_tmp = []
		j = address % 100000
		for i in range(j, j+number):
			list_tmp.append(True if i % 2 == 1 else False)
		print('coils: address=%d, number=%d, unit_id=%d' % (address, number, srv_info.recv_frame.mbap.unit_id), list_tmp)
		return list_tmp

	def get_discrete_inputs(self, address, number=1, srv_info=None):
		list_tmp = []
		j = address % 100000
		for i in range(j, j+number):
			list_tmp.append(True if i % 2 == 1 else False)
		print('discrete_inputs: address=%d, number=%d, unit_id=%d' % (address, number, srv_info.recv_frame.mbap.unit_id), list_tmp)
		return list_tmp

	def get_holding_registers(self, address, number=1, srv_info=None):
		list_tmp = []
		j = address % 100000
		for i in range(j, j+number):
			list_tmp.append(i)
		print('holding_registers: address=%d, number=%d, unit_id=%d' % (address, number, srv_info.recv_frame.mbap.unit_id), list_tmp)
		return list_tmp

	def get_input_registers(self, address, number=1, srv_info=None):
		list_tmp = []
		j = address % 100000
		for i in range(j, j+number):
			list_tmp.append(i)
		print('input_registers: address=%d, number=%d, unit_id=%d' % (address, number, srv_info.recv_frame.mbap.unit_id), list_tmp)
		return list_tmp

if __name__ == '__main__':
	server = ModbusServer(host='0.0.0.0', port=502, no_block=False, data_bank=MyDataBank())
	server.start()

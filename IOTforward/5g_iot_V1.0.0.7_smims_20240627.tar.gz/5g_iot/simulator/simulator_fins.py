#!/usr/bin/python3
import binascii,socket

ip_addr = ('', 19600)
socket_inst = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
socket_inst.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
socket_inst.bind(ip_addr)

while True:
	packet, addr = socket_inst.recvfrom(1436)
	if len(packet) != 18:
		continue
	#print('%s -> %s' % (str(addr), binascii.hexlify(packet).decode('ascii').upper()))

	resp_packet = b'\xC0' + packet[1:3] + packet[6:9] + packet[3:6] + packet[9:12] + b'\x00\x00'
	plc_sa = int.from_bytes(packet[13:15],'big')
	plc_sz = int.from_bytes(packet[16:18],'big')
	for i in range(plc_sa, plc_sa + plc_sz):
		resp_packet += i.to_bytes(2,'big')
	socket_inst.sendto(resp_packet, addr)
	#print('%s <- %s' % (str(addr), binascii.hexlify(resp_packet).decode('ascii').upper()))

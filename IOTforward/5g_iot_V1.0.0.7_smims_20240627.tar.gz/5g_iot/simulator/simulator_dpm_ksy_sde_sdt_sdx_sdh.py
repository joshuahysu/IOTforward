#!/usr/bin/python3
import binascii,time
import serial

print('KSY SDE/SDL/SDT/SDX/SDH Simultor')

time.sleep(2)
uart = serial.Serial(port='/dev/vcom_ksy_sde_sdt_sdx_sdh_dev',baudrate=9600,bytesize=serial.SEVENBITS,stopbits=serial.STOPBITS_TWO,parity=serial.PARITY_EVEN)

while True:
	ch = uart.read(1)
	if ch != b'\x02':
		continue
	packet = ch

	ch = uart.read(1)
	if ch == b'A' or ch == b'K' or ch == b'a' or ch == b'k' or ch == b'X':
		packet += ch
		command = ch
	else:
		continue

	try:
		fcs =  binascii.hexlify(int(2 ^ ch[0]).to_bytes(1,'big')).upper()
	except:
		continue

	tmp = b''
	while len(tmp) < 2:
		ch = uart.read(1)
		if ch != None:
			tmp += ch
	if tmp != fcs:
		continue
	packet += tmp

	ch = uart.read(1)
	if ch != b'\x2A':
		continue
	packet += ch

	ch = uart.read(1)
	if ch != b'\x0D':
		continue
	packet += ch

	#print('UART -> ' + binascii.hexlify(packet).decode('ascii').upper())

	resp = b'\x02\x06' + command
	if command == b'A':
		resp += b'001'
		resp += b'002'
		resp += b'003'
		resp += b'004'
		resp += b'005'
		resp += b'006'
		resp += b'007'
		resp += b'008'
		resp += b'009'
		resp += b'010'
		resp += b'011'
		resp += b'012'
		resp += b'013'
	elif command == b'a':
		resp += b'001'
		resp += b'002'
		resp += b'003'
		resp += b'   '
		resp += b'005'
		resp += b'006'
		resp += b'007'
	elif command == b'X':
		resp += b'0001'
		resp += b'0002'
		resp += b'0003'
		resp += b'0004'
		resp += b'0005'
		resp += b'0006'
		resp += b'0007'
		resp += b'0008'
		resp += b'0009'
		resp += b'0010'
		resp += b'0011'
		resp += b'0012'
		resp += b'    '
		resp += b'    '
		resp += b'0015'
		resp += b'0016'
		resp += b'0017'
		resp += b'0018'
		resp += b'0019'
		resp += b'0020'
		resp += b'0021'
		resp += b'0022'
		resp += b'0023'
		resp += b'    '
		resp += b'    '
	elif command == b'K' or command == b'k':
		resp += b'123456'
	fcs = 0
	for ch in resp:
		fcs ^= ch
	fcs = binascii.hexlify(fcs.to_bytes(1,'big')).upper()
	resp += fcs
	resp += b'*\r'

	i = uart.write(resp)
	#print('UART <- ' + binascii.hexlify(resp).decode('ascii').upper())

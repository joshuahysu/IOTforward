#!/usr/bin/python3
import binascii,time
import serial

print('EDWARDS Simultor')

time.sleep(2)
uart = serial.Serial(port='/dev/vcom_edwards_dev',baudrate=9600,bytesize=serial.EIGHTBITS,stopbits=serial.STOPBITS_ONE,parity=serial.PARITY_NONE)

while True:
	ch = uart.read(1)
	if ch != b'?':
		continue
	packet = ch

	ch = uart.read(1)
	if ch != b'V':
		continue
	packet += ch

	param = b''
	while True:
		ch = uart.read(1)
		if ch == None:
			break
		packet += ch
		if ch == b'\r':
			break
		param += ch
	if ch == None:
		continue

	try:
		i = int(param)
	except:
		continue

	#print('UART -> ' + binascii.hexlify(packet).decode('ascii').upper())

	resp = param + b',0,0,0\r\n'
	i = uart.write(resp)
	#print('UART <- ' + binascii.hexlify(resp).decode('ascii').upper())

#!/usr/bin/python3
import binascii,time
import serial

print('KSY MU/TS Simultor')

time.sleep(2)
uart = serial.Serial(port='/dev/vcom_ksy_mu_ts_dev',baudrate=9600,bytesize=serial.SEVENBITS,stopbits=serial.STOPBITS_TWO,parity=serial.PARITY_EVEN)

while True:
	tmp = uart.read(1)
	if tmp != b'@':
		continue
	packet = tmp

	tmp = uart.read(2)
	if tmp != b'00':
		continue
	packet += tmp

	tmp = uart.read(2)
	if tmp != b'RE':
		continue
	packet += tmp

	tmp = uart.read(2)
	if tmp != b'00':
		continue
	packet += tmp

	tmp = uart.read(4)
	if tmp == None or len(tmp) < 4:
		continue
	packet += tmp
	try:
		addr = int(tmp)
	except:
		continue

	tmp = uart.read(4)
	if tmp == None or len(tmp) < 4:
		continue
	packet += tmp
	try:
		cnt = int(tmp)
	except:
		continue

	fcs = 0
	for ch in packet:
		fcs ^= ch
	fcs = binascii.hexlify(fcs.to_bytes(1,'big')).upper()

	tmp = uart.read(2)
	if tmp != fcs:
		continue

	tmp = uart.read(2)
	if tmp != b'*\r':
		continue

	#print('UART -> ' + binascii.hexlify(packet).decode('ascii').upper())

	#---------------------

	resp = b'@00RE00'
	for i in range(addr, addr+cnt):
		try:
			tmp = ('%02d' % (i % 100)).encode('ascii')
			if i == 4545:
				tmp = b'F0' + tmp
			else:
				tmp = b'00' + tmp
			resp += tmp
		except:
			pass

	fcs = 0
	for ch in resp:
		fcs ^= ch
	fcs = binascii.hexlify(fcs.to_bytes(1,'big')).upper()

	resp += fcs
	resp += b'*\r'

	i = uart.write(resp)
	#print('UART <- ' + binascii.hexlify(resp).decode('ascii').upper())

#!/usr/bin/python3
import binascii,socket

ip_addr = ('', 19600)
socket_inst = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
socket_inst.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
socket_inst.bind(ip_addr)

while True:
	packet, addr = socket_inst.recvfrom(8192)
	if len(packet) <= 12:
		continue
	print('%s -> %s' % (str(addr), binascii.hexlify(packet).decode('ascii').upper()))

	i = len(packet) - 12
	resp_packet = b''
	if packet[10:12] == b'\x01\x01' and i == 6:  # command code: MEMORY AREA READ
		resp_packet = b'\xC0' + packet[1:3] + packet[6:9] + packet[3:6] + packet[9:12] + b'\x00\x00'
		plc_sa = int.from_bytes(packet[13:15],'big')
		plc_sz = int.from_bytes(packet[16:18],'big')
		for i in range(plc_sa, plc_sa + plc_sz):
			resp_packet += i.to_bytes(2,'big')
	elif packet[10:12] == b'\x01\x04' and i % 4 == 0:  # command code: MULTIPLE MEMORY AREA READ
		resp_packet = b'\xC0' + packet[1:3] + packet[6:9] + packet[3:6] + packet[9:12] + b'\x00\x00'
		for j in range(12, len(packet), 4):
			plc_area = packet[j:j+1]
			plc_addr = int.from_bytes(packet[j+1:j+3],'big')
			resp_packet += (plc_area + plc_addr.to_bytes(2,'big'))

	if len(resp_packet) > 0:
		socket_inst.sendto(resp_packet, addr)
		print('%s <- %s' % (str(addr), binascii.hexlify(resp_packet).decode('ascii').upper()))

#!/usr/bin/python3
import binascii,time
import serial

print('EBARA ESR/EST/EV-S/EV-M Simultor')

time.sleep(2)
uart = serial.Serial(port='/dev/vcom_ebara_esr_est_ev-s_ev-m_dev',baudrate=9600,bytesize=serial.EIGHTBITS,stopbits=serial.STOPBITS_ONE,parity=serial.PARITY_NONE)

while True:
	ch = uart.read(1)
	if ch != b'\x02':
		continue
	m20_cmd = ch

	while True:
		ch = uart.read(1)
		if ch != None:
			break
	if ch != b'M':
		continue
	m20_cmd += ch

	while True:
		ch = uart.read(1)
		if ch != None:
			break
	if ch != b'2':
		continue
	m20_cmd += ch

	while True:
		ch = uart.read(1)
		if ch != None:
			break
	if ch != b'0':
		continue
	m20_cmd += ch

	tmp = b''
	while len(tmp) < 8:
		ch = uart.read(1)
		if ch != None:
			tmp += ch
	try:
		analog_data = int(tmp.decode('ascii'),16)
	except:
		continue
	m20_cmd += tmp

	while True:
		ch = uart.read(1)
		if ch != None:
			break
	if ch != b'\x03':
		continue
	m20_cmd += ch

	checksum = 0
	for i in range(len(m20_cmd)):
		checksum += m20_cmd[i]
	checksum &= 0xff
	checksum = binascii.hexlify(checksum.to_bytes(1, 'big')).upper()

	tmp = b''
	while len(tmp) < 2:
		ch = uart.read(1)
		if ch != None:
			tmp += ch
	if tmp != checksum:
		continue
	m20_cmd += tmp

	while True:
		ch = uart.read(1)
		if ch != None:
			break
	if ch != b'\x0D':
		continue
	m20_cmd += ch

	#print('UART -> ' + binascii.hexlify(m20_cmd).decode('ascii').upper())

	list_resp = []
	for i in range(0,23):
		if analog_data & 1<<i > 0:
			list_resp.append('%02d' % (i))

	while len(list_resp) > 0:
		analog_code = list_resp.pop(0).encode('ascii')
		return_data = analog_code
		resp_data = b'\x02' + analog_code + b'\x20'*(7-len(return_data)) + return_data
		checksum = 0
		for i in range(len(resp_data)):
			checksum += resp_data[i]
		checksum &= 0xff
		checksum = binascii.hexlify(checksum.to_bytes(1, 'big')).upper()
		resp_data += (b'\x03' + checksum + b'\x0D')
		#print('UART <- ' + binascii.hexlify(resp_data).decode('ascii').upper())
		i = uart.write(resp_data)
	resp_data = b'\x02\x45\x4E\x44\x03\x44\x43\x0D'
	#print('UART <- ' + binascii.hexlify(resp_data).decode('ascii').upper())
	i = uart.write(resp_data)

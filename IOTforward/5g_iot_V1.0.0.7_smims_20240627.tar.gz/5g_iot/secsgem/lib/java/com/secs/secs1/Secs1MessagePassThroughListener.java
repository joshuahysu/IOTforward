package com.secs.secs1;

import java.util.EventListener;

/**
 * 

 *
 */
public interface Secs1MessagePassThroughListener extends EventListener {
	
	public void passThrough(Secs1Message message);
}

/**
 * Provides super-interfacies, SECS-Communicator, Message, Config, Exceptions.
 */
/**

 *
 */
package com.secs;

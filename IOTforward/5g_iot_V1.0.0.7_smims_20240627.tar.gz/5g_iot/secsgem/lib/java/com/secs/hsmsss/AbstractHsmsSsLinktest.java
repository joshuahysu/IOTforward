package com.secs.hsmsss;

import java.util.Optional;

import com.secs.ReadOnlyTimeProperty;
import com.secs.hsms.AbstractHsmsAsyncSocketChannel;
import com.secs.hsms.AbstractHsmsLinktest;
import com.secs.hsms.HsmsException;
import com.secs.hsms.HsmsMessage;
import com.secs.hsms.HsmsSendMessageException;
import com.secs.hsms.HsmsWaitReplyMessageException;

public abstract class AbstractHsmsSsLinktest extends AbstractHsmsLinktest {
	
	private final AbstractHsmsAsyncSocketChannel asyncChannel;
	private final AbstractHsmsSsCommunicator comm;
	
	public AbstractHsmsSsLinktest(
			AbstractHsmsAsyncSocketChannel asyncChannel,
			AbstractHsmsSsCommunicator communicator
			) {
		this.asyncChannel = asyncChannel;
		this.comm = communicator;
	}
	
	@Override
	protected ReadOnlyTimeProperty timer() {
		return this.comm.config().linktest();
	}
	
	@Override
	protected Optional<HsmsMessage> send()
			throws HsmsSendMessageException,
			HsmsWaitReplyMessageException,
			HsmsException,
			InterruptedException {
		return this.asyncChannel.sendLinktestRequest(this.comm.getSession());
	}
	
}

package com.secs.secs1;

import com.secs.SecsLog;

/**
 * This interface implements SECS1-Circuit-Control-Log
 * 

 *
 */
public interface Secs1CircuitControlLog extends SecsLog {
	
	/* Nothing */
}

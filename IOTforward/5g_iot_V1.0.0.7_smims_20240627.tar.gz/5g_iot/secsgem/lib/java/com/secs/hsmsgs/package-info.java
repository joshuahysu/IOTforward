/**
 * Implementation package providing HSMS-GS (SEMI-E37.2) Communicator, Message.
 * 

 *
 */
package com.secs.hsmsgs;
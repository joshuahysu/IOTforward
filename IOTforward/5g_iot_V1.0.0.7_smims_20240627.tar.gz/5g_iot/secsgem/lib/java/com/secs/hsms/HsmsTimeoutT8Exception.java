package com.secs.hsms;

public class HsmsTimeoutT8Exception extends HsmsException {
	
	private static final long serialVersionUID = -3497475923757215910L;
	
	public HsmsTimeoutT8Exception() {
		super();
	}

	public HsmsTimeoutT8Exception(Throwable cause) {
		super(cause);
	}
	
}

package com.secs;

/**
 * This interface implements of Try-Send SECS-Message Log.
 * 

 *
 */
public interface SecsTrySendMessageLog extends SecsLog {
	/* Nothing */
}

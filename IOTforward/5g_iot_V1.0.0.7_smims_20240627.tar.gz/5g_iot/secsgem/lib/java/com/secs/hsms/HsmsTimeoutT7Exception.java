package com.secs.hsms;

public class HsmsTimeoutT7Exception extends HsmsException {
	
	private static final long serialVersionUID = -6913738466997835845L;
	
	public HsmsTimeoutT7Exception() {
		super();
	}
}

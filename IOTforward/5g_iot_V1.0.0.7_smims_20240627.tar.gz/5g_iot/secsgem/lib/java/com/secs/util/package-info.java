/**
 * This package is utilities of SECS-Communicate.
 * 

 *
 */
package com.secs.util;
package com.secs.util;

import java.util.Optional;

import com.secs.SecsCommunicator;
import com.secs.SecsException;
import com.secs.SecsMessage;
import com.secs.SecsMessageSendable;
import com.secs.SecsSendMessageException;
import com.secs.SecsWaitReplyMessageException;

/**
 * 

 *
 */
public interface EntityMessageSender extends SecsMessageSendable {
	
	/**
	 * Send S9F9 if set {@code true} and T3-Timeout.
	 * 
	 * @param doSend
	 */
	public void setSendS9F9(boolean doSend);
	
	/**
	 * S9F9, Transaction Timeout.
	 * 
	 * <p>
	 * blocking-method.<br />
	 * </p>
	 * 
	 * @param SecsWaitReplyMessageException
	 * @return {@code Optional.empty()}
	 * @throws SecsSendMessageException if send failed
	 * @throws SecsWaitReplyMessageException if receive message failed, e.g. Timeout-T3
	 * @throws SecsException
	 * @throws InterruptedException
	 */
	public Optional<SecsMessage> sendS9F9(SecsWaitReplyMessageException e)
			throws SecsSendMessageException,
			SecsWaitReplyMessageException,
			SecsException,
			InterruptedException;
	
	/**
	 * New-instance builder.
	 * 
	 * @param communicator
	 * @return new-instance
	 */
	public static EntityMessageSender newInstance(SecsCommunicator communicator) {
		return new AbstractEntityMessageSender(communicator) {};
	}
	
}

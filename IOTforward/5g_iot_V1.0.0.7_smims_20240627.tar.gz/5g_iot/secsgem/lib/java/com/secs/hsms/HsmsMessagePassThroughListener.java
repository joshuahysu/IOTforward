package com.secs.hsms;

import java.util.EventListener;

/**
 * 

 *
 */
public interface HsmsMessagePassThroughListener extends EventListener {
	
	public void passThrough(HsmsMessage message);
}

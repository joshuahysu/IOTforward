package com.secs.gem;

public enum ClockType {
	A12,
	A16,
	;
}

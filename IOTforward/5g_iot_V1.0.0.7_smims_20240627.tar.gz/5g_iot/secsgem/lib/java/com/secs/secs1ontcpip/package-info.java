/**
 * Implementation package providing SECS-I(SEMI-E4)-on-TCP/IP Communicator, Message.
 * 

 *
 */
package com.secs.secs1ontcpip;

package com.secs.hsms;

import java.util.EventListener;

/**
 * 

 *
 */
public interface HsmsCommunicateStateChangeListener extends EventListener {
	
	public void changed(HsmsCommunicateState state);
}

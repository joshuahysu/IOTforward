package com.secs.secs1;

public class Secs1RetryOverException extends Secs1Exception {
	
	private static final long serialVersionUID = -3521500239565706502L;
	
	public Secs1RetryOverException() {
		super();
	}
	
}

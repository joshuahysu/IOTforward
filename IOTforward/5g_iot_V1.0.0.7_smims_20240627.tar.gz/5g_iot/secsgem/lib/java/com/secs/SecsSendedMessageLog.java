package com.secs;

/**
 * This interface is implements of Sended SECS-Message Log.
 * 

 *
 */
public interface SecsSendedMessageLog extends SecsLog {
	/* Nothing */
}

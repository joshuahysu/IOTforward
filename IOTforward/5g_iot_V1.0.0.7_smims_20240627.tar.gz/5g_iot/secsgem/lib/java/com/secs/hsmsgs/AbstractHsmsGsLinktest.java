package com.secs.hsmsgs;

import java.util.Optional;

import com.secs.ReadOnlyTimeProperty;
import com.secs.hsms.AbstractHsmsAsyncSocketChannel;
import com.secs.hsms.AbstractHsmsLinktest;
import com.secs.hsms.AbstractHsmsSession;
import com.secs.hsms.HsmsException;
import com.secs.hsms.HsmsMessage;
import com.secs.hsms.HsmsSendMessageException;
import com.secs.hsms.HsmsWaitReplyMessageException;

public abstract class AbstractHsmsGsLinktest extends AbstractHsmsLinktest {
	
	private final AbstractHsmsAsyncSocketChannel asyncChannel;
	private final AbstractHsmsGsCommunicator comm;
	
	public AbstractHsmsGsLinktest(
			AbstractHsmsAsyncSocketChannel asyncChannel,
			AbstractHsmsGsCommunicator communicator
			) {
		
		super();
		this.asyncChannel = asyncChannel;
		this.comm = communicator;
	}
	
	@Override
	protected ReadOnlyTimeProperty timer() {
		return this.comm.config().linktest();
	}
	
	@Override
	protected Optional<HsmsMessage> send()
			throws HsmsSendMessageException,
			HsmsWaitReplyMessageException,
			HsmsException,
			InterruptedException {
		
		for (AbstractHsmsSession s : this.comm.getAbstractHsmsSessions()) {
			return this.asyncChannel.sendLinktestRequest(s);
		}
		
		return Optional.empty();
	}
	
}

package com.secs.util;

import java.util.EventListener;

import com.secs.SecsCommunicator;
import com.secs.SecsMessage;
import com.secs.secs2.Secs2Exception;

/**
 * 

 *
 */
public interface EntityMessageReceiveListener extends EventListener {
	
	public void received(SecsMessage msg, SecsCommunicator comm) throws Secs2Exception, InterruptedException;
}

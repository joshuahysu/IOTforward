package com.secs.hsmsss;

@Deprecated
public enum HsmsSsProtocol {
	PASSIVE,
	ACTIVE,
	;
}

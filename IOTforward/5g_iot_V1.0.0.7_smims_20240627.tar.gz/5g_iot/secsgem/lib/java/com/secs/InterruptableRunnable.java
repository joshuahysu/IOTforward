package com.secs;

public interface InterruptableRunnable {
	public void run() throws InterruptedException;
}

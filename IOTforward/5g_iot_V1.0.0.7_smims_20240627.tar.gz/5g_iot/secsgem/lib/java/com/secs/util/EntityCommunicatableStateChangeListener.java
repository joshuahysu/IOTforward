package com.secs.util;

import java.util.EventListener;

import com.secs.SecsCommunicator;

/**
 * 

 *
 */
public interface EntityCommunicatableStateChangeListener extends EventListener {
	
	public void changed(boolean communicatable, SecsCommunicator comm);
}

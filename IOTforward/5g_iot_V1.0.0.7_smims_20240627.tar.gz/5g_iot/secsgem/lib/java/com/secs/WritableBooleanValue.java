package com.secs;

/**
 * Boolean Setter.
 * 

 *
 */
public interface WritableBooleanValue extends WritableValue<Boolean> {
	
	/**
	 * setter.
	 * 
	 * @param v
	 */
	public void set(boolean v);
}

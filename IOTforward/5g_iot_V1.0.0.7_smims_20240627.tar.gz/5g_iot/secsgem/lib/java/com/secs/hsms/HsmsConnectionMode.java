package com.secs.hsms;

public enum HsmsConnectionMode {
	
	PASSIVE,
	ACTIVE,
	;
	
}

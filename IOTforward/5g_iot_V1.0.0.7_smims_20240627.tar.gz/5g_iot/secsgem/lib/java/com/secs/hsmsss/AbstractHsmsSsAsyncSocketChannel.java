package com.secs.hsmsss;

import java.nio.channels.AsynchronousSocketChannel;
import java.util.List;

import com.secs.AbstractSecsLog;
import com.secs.ReadOnlyTimeProperty;
import com.secs.hsms.AbstractHsmsAsyncSocketChannel;
import com.secs.hsms.AbstractHsmsMessage;
import com.secs.hsms.HsmsException;
import com.secs.hsms.HsmsMessage;
import com.secs.hsms.HsmsMessageBuilder;
import com.secs.hsms.HsmsSendMessageException;
import com.secs.hsms.HsmsTransactionManager;
import com.secs.hsms.HsmsWaitReplyMessageException;
import com.secs.secs2.Secs2BytesParseException;

public abstract class AbstractHsmsSsAsyncSocketChannel extends AbstractHsmsAsyncSocketChannel {
	
	private final AbstractHsmsSsCommunicator comm;
	private final AbstractHsmsSsLinktest linktest;
	
	public AbstractHsmsSsAsyncSocketChannel(
			AsynchronousSocketChannel channel,
			AbstractHsmsSsCommunicator communicator
			) {
		
		super(channel);
		this.comm = communicator;
		this.linktest = new AbstractHsmsSsLinktest(this, comm) {};
	}
	
	@Override
	public void linktesting()
			throws HsmsSendMessageException,
			HsmsWaitReplyMessageException,
			HsmsException,
			InterruptedException {
		
		this.linktest.testing();
	}
	
	@Override
	protected HsmsMessageBuilder messageBuilder() {
		return this.comm.msgBuilder();
	}
	
	@Override
	protected AbstractHsmsMessage buildMessageFromBytes(byte[] header, List<byte[]> bodies) throws Secs2BytesParseException {
		return HsmsSsMessageBuilder.fromBytes(header, bodies);
	}
	
	@Override
	protected AbstractHsmsMessage buildMessageFromMessage(HsmsMessage message) {
		return HsmsSsMessageBuilder.fromMessage(message);
	}
	
	private final HsmsTransactionManager<AbstractHsmsMessage> transMgr = new HsmsTransactionManager<>();
	
	@Override
	protected HsmsTransactionManager<AbstractHsmsMessage> transactionManager() {
		return this.transMgr;
	}
	
	@Override
	protected void notifyLog(AbstractSecsLog log) throws InterruptedException {
		this.comm.notifyLog(log);
	}
	
	@Override
	protected void notifyTrySendHsmsMsgPassThrough(HsmsMessage msg) throws InterruptedException {
		this.comm.notifyTrySendHsmsMessagePassThrough(msg);
	}
	
	@Override
	protected void notifySendedHsmsMsgPassThrough(HsmsMessage msg) throws InterruptedException {
		this.comm.notifySendedHsmsMessagePassThrough(msg);
	}
	
	@Override
	protected void notifyReceiveHsmsMessagePassThrough(HsmsMessage msg) throws InterruptedException {
		this.comm.notifyReceiveHsmsMessagePassThrough(msg);
	}
	

	@Override
	protected ReadOnlyTimeProperty timeoutT3() {
		return this.comm.config().timeout().t3();
	}
	
	@Override
	protected ReadOnlyTimeProperty timeoutT6() {
		return this.comm.config().timeout().t6();
	}
	
	@Override
	protected ReadOnlyTimeProperty timeoutT8() {
		return this.comm.config().timeout().t8();
	}
	
	@Override
	protected void resetLinktestTimer() {
		this.linktest.resetTimer();
	}
	
}

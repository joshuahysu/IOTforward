package com.secs;

/**
 * Setter, super interface of WritableValue.
 * 

 *
 * @param <T>
 */
public interface WritableValue<T> {
	
	/**
	 * value setter.
	 * 
	 * @param v
	 */
	public void set(T v);
	
}

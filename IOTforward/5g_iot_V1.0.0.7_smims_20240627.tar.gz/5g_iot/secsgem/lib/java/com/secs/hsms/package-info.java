/**
 * Implementation package providing HSMS (SEMI-E37) Communicator, Message.
 * 

 *
 */
package com.secs.hsms;

package com.secs;

/**
 * String setter.
 * 

 *
 */
public interface WritableStringValue extends WritableValue<String> {
	
	/**
	 * setter.
	 * 
	 * @param cs
	 */
	public void set(CharSequence cs);
	
}

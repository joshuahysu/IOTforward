package com.secs;

import java.net.SocketAddress;

/**
 * SocketAddress Getter.
 * 

 *
 */
public interface ReadOnlySocketAddressProperty extends ReadOnlyProperty<SocketAddress> {
	
	/**
	 * SocketAddress getter.
	 * 
	 * <p>
	 * if set {@code null}, throw IllegalStateException.<br />
	 * </p>
	 * 
	 * @return SocketAddress
	 * @throws IllegalStateException
	 */
	public SocketAddress getSocketAddress();
	
}

package com.secs.hsmsss;

import java.io.IOException;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.Optional;

import com.secs.SecsException;
import com.secs.SecsMessage;
import com.secs.SecsSendMessageException;
import com.secs.SecsWaitReplyMessageException;
import com.secs.hsms.AbstractHsmsAsyncSocketChannel;
import com.secs.hsms.AbstractHsmsCommunicator;
import com.secs.hsms.AbstractHsmsSession;
import com.secs.hsms.HsmsException;
import com.secs.hsms.HsmsMessage;
import com.secs.hsms.HsmsMessageBuilder;
import com.secs.hsms.HsmsSendMessageException;
import com.secs.hsms.HsmsWaitReplyMessageException;
import com.secs.secs2.Secs2;

/**
 * This abstract class is implementation of HSMS-SS (SEMI-E37.1).
 * 

 *
 */
public abstract class AbstractHsmsSsCommunicator extends AbstractHsmsCommunicator
		implements HsmsSsCommunicator {
	
	private final HsmsSsCommunicatorConfig config;
	private final AbstractHsmsSsSession session;
	
	public AbstractHsmsSsCommunicator(HsmsSsCommunicatorConfig config) {
		super(config);
		
		this.config = config;
		
		this.session = new AbstractHsmsSsSession(
				config,
				config.sessionId().intValue()
				) {};
	}
	
	@Override
	public int deviceId() {
		return this.getSession().deviceId();
	}
	
	@Override
	public int sessionId() {
		return this.getSession().sessionId();
	}
	
	@Override
	public void open() throws IOException {
		super.open();
		this.getSession().open();
	}
	
	public HsmsSsCommunicatorConfig config() {
		return this.config;
	}
	
	private final HsmsMessageBuilder msgBuilder = new AbstractHsmsSsMessageBuilder() {};
	
	public HsmsMessageBuilder msgBuilder() {
		return this.msgBuilder;
	}
	
	private final Object syncClosed = new Object();
	
	@Override
	public void close() throws IOException {
		
		synchronized ( this.syncClosed ) {
			
			if ( this.isClosed() ) {
				return;
			}
			
			try {
				this.getSession().separate();
			}
			catch ( InterruptedException giveup ) {
			}
			
			IOException ioExcept = null;
			try {
				super.close();
			}
			catch ( IOException e ) {
				ioExcept = e;
			}
			
			try {
				this.getSession().close();
			}
			catch ( IOException e ) {
				ioExcept = e;
			}
			
			if ( ioExcept != null ) {
				throw ioExcept;
			}
		}
	}
	
	@Override
	public boolean linktest() throws InterruptedException {
		return this.getSession().linktest();
	}
	
	@Override
	public Optional<SecsMessage> templateSend(int strm, int func, boolean wbit, Secs2 secs2)
			throws SecsSendMessageException, SecsWaitReplyMessageException, SecsException, InterruptedException {
		
		return this.getSession().templateSend(strm, func, wbit, secs2);
	}
	
	@Override
	public Optional<SecsMessage> templateSend(SecsMessage primaryMsg, int strm, int func, boolean wbit, Secs2 secs2)
			throws SecsSendMessageException, SecsWaitReplyMessageException, SecsException, InterruptedException {
		
		return this.getSession().templateSend(primaryMsg, strm, func, wbit, secs2);
	}
	
	@Override
	public Optional<HsmsMessage> send(HsmsMessage msg)
			throws HsmsSendMessageException,
			HsmsWaitReplyMessageException,
			HsmsException,
			InterruptedException {
		
		return this.getSession().send(msg);
	}
	
	protected AbstractHsmsSession getSession() {
		return this.session;
	}
	
	protected AbstractHsmsAsyncSocketChannel buildAsyncSocketChannel(AsynchronousSocketChannel channel) {
		return new AbstractHsmsSsAsyncSocketChannel(channel, this) {};
	}
	
}

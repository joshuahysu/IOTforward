package com.secs.hsms;

import com.secs.SecsMessage;

public interface HsmsMessage extends SecsMessage {
	
	public HsmsMessageType messageType();
	
	public boolean isDataMessage();
	
	public byte pType();
	
	public byte sType();
	
}

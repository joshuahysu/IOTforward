package com.secs.hsmsgs;

import com.secs.hsms.HsmsException;

public class HsmsGsUnknownSessionIdException extends HsmsException {
	
	private static final long serialVersionUID = -3532958513890338098L;
	
	public HsmsGsUnknownSessionIdException(int id) {
		super("Unknown Session-ID: " + id);
	}
	
}

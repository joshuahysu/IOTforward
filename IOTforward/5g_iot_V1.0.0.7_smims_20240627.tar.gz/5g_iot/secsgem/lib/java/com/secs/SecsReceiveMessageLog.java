package com.secs;

/**
 * This interface is implements of Receive SECS-Message Log.
 * 

 *
 */
public interface SecsReceiveMessageLog extends SecsLog {
	/* Nothing */
}

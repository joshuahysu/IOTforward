package com.secs;

public interface PropertyChangeListener<T> {
	public void changed(T v);
}

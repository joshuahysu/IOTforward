package com.secs.hsms;

public class HsmsDetectTerminateException extends HsmsException {
	
	private static final long serialVersionUID = -3363838905023886189L;
	
	public HsmsDetectTerminateException() {
		super();
	}

	public HsmsDetectTerminateException(Throwable cause) {
		super(cause);
	}
	
}
